"""
frontend/components.py

Reusable UI presentation blocks supporting dynamic Light (Mint-Sage) and Dark themes.
Includes exact light-themed Table Cards for Hospitals, Cooling Centres, and Water Points.
"""

from __future__ import annotations
import pandas as pd
import streamlit as st
from utils.constants import DEMO_MODE_NOTICE, HTSS_DISCLAIMER, LANGUAGES
from utils.helpers import format_ist_timestamp
from utils.translations import get_text
from frontend.styles import THEMES, get_current_theme


def _current_lang_code() -> str:
    return LANGUAGES.get(st.session_state.get("selected_language_label", "English"), "en")


def t(key: str) -> str:
    return get_text(key, _current_lang_code())


def _current_tokens() -> dict:
    mode = get_current_theme()
    return THEMES.get(mode, THEMES["dark"])


def page_header(title: str, subtitle: str = "", show_role_selector: bool = True) -> None:
    tokens = _current_tokens()
    col_title, col_role = st.columns([4, 1.3], vertical_alignment="bottom")
    with col_title:
        st.markdown(
            f"""
            <div class="hs-fade-in" style="margin-bottom: 1.2rem;">
                <div style="font-size:1.9rem; font-weight:800; letter-spacing:-0.02em; color:{tokens['text_primary']};">{title}</div>
                {f'<div style="color:{tokens["text_muted"]}; font-size:0.95rem; margin-top:4px;">{subtitle}</div>' if subtitle else ''}
            </div>
            """,
            unsafe_allow_html=True,
        )
    if show_role_selector:
        with col_role:
            from frontend.ui_helpers import render_role_selector
            render_role_selector()


def status_bar(location_label: str = "") -> None:
    tokens = _current_tokens()
    st.markdown(
        f"""
        <div class="hs-card hs-fade-in" style="display:flex; justify-content:space-between; align-items:center; padding:14px 22px; margin-bottom:1.2rem;">
            <div style="display:flex; align-items:center; gap:10px;">
                <span style="width:9px; height:9px; border-radius:50%; background:#10B981; display:inline-block;" class="hs-pulse"></span>
                <span style="font-weight:700; letter-spacing:0.06em; font-size:0.82rem; color:{tokens['text_primary']};">{t("live_forecast_status")}</span>
            </div>
            <div style="color:{tokens['text_muted']}; font-size:0.85rem;">Updated: {format_ist_timestamp()} {f"| {location_label}" if location_label else ""}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def demo_mode_badge() -> None:
    from frontend.ui_helpers import current_lang_code
    from utils.translations import get_text

    is_light = get_current_theme() == "light"
    bg = "#E6F4EA" if is_light else "rgba(51, 198, 244, 0.10)"
    border = "#34A853" if is_light else "rgba(51, 198, 244, 0.35)"
    text_color = "#0D532B" if is_light else "#B9E8FA"
    notice_text = get_text("demo_mode_banner", current_lang_code())

    st.markdown(
        f"""
        <div style="background:{bg}; border:1.5px solid {border};
                    border-radius: 12px; padding: 12px 18px; font-size:0.85rem; color:{text_color} !important;
                    font-weight: 600; margin-bottom: 1rem; box-shadow:0 2px 6px rgba(0,0,0,0.02);">
            <span style="font-size:1.05rem; margin-right:6px;">ⓘ</span> {notice_text}
        </div>
        """,
        unsafe_allow_html=True,
    )


def htss_disclaimer() -> None:
    st.caption(f"ⓘ {HTSS_DISCLAIMER}")


def risk_badge(label: str, color: str, icon: str = "") -> str:
    return (
        f'<span class="hs-badge" style="background:{color}22; color:{color}; border:1px solid {color}55;">'
        f"{icon} {label}</span>"
    )


def kpi_card_static(label: str, value: str, sub: str = "", color: str | None = None) -> None:
    tokens = _current_tokens()
    val_color = color if color is not None else tokens["text_primary"]
    st.markdown(
        f"""
        <div class="hs-card">
            <div class="hs-kpi-label">{label}</div>
            <div class="hs-kpi-value" style="color:{val_color};">{value}</div>
            <div class="hs-kpi-sub">{sub}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def hero_risk_panel(score: float, level: dict) -> None:
    tokens = _current_tokens()
    st.markdown(
        f"""
        <div class="hs-card hs-fade-in" style="text-align:center; padding:34px;">
            <div class="hs-section-title">HEAT HEALTH RISK</div>
            <div style="font-size:4rem; font-weight:800; color:{level['color']}; line-height:1;">
                {score:.0f}<span style="font-size:1.6rem; color:{tokens['text_muted']};"> / 100</span>
            </div>
            <div style="margin-top:10px;">{risk_badge(level['label'], level['color'], level['icon'])}</div>
            <hr class="hs-divider"/>
            <div style="color:{tokens['text_muted']}; font-size:0.92rem;">
                Temperature + Humidity + Wind + Solar Radiation + Vulnerability
            </div>
            <div style="margin-top:10px; font-style:italic; color:{tokens['text_muted']}; font-size:0.86rem; opacity:0.85;">
                {t("temperature_alone_not_enough")}
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def driver_chips(drivers: list[str]) -> None:
    chips = "".join(f'<div class="hs-driver-chip">🔎 {d}</div>' for d in drivers)
    st.markdown(f'<div class="hs-pill-row">{chips}</div>', unsafe_allow_html=True)


def risk_driver_explainer(temp, humidity, wind, radiation, worker_exposure_label: str) -> None:
    tokens = _current_tokens()
    cols = st.columns(5)
    items = [
        (f"{temp:.1f}°C", "High air temperature"),
        (f"{humidity:.0f}%", "Relative humidity"),
        (f"{wind:.1f} m/s", "Wind speed"),
        (f"{radiation:.0f} W/m²", "Solar radiation"),
        (worker_exposure_label, "Outdoor-worker exposure"),
    ]
    for col, (val, label) in zip(cols, items):
        with col:
            st.markdown(
                f"""
                <div class="hs-card" style="text-align:center; padding:16px 8px;">
                    <div style="font-size:1.3rem; font-weight:800; color:{tokens['text_primary']};">{val}</div>
                    <div style="font-size:0.75rem; color:{tokens['text_muted']}; margin-top:4px;">{label}</div>
                </div>
                """,
                unsafe_allow_html=True,
            )


def alert_card(alert) -> None:
    tokens = _current_tokens()
    pulse_class = "hs-pulse" if alert.level_key in ("red", "extreme") else ""
    peak_html = ""
    if alert.peak_start and alert.peak_end:
        peak_html = f'<div style="margin-top:10px; color:{tokens["text_primary"]};"><b>Peak:</b> {alert.peak_start} – {alert.peak_end}</div>'

    drivers_html = "".join(f"<li>{d}</li>" for d in alert.drivers)

    st.markdown(
        f"""
        <div class="hs-card {pulse_class}" style="border-left: 5px solid {alert.color}; margin-bottom: 1rem;">
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <div style="font-weight:800; font-size:1.1rem; color:{alert.color};">{alert.headline}</div>
            </div>
            <div style="color:{tokens['text_muted']}; margin-top:4px; font-size:0.85rem;">
                {alert.location_name}{f' — {alert.ward_name}' if alert.ward_name else ''}
            </div>
            <div style="margin-top:12px; color:{tokens['text_primary']};">{alert.description}</div>
            {peak_html}
            <div style="margin-top:12px; color:{tokens['text_primary']};"><b>DRIVERS</b><ul style="margin-top:6px; color:{tokens['text_primary']};">{drivers_html}</ul></div>
            <div style="margin-top:10px; padding:12px 14px; background:{tokens['chip_bg']}; border:1px solid {tokens['border_color']}; border-radius:10px; color:{tokens['text_primary']};">
                <b>ACTION REQUIRED</b><br/>{alert.action}
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def confidence_meter(confidence: int) -> None:
    tokens = _current_tokens()
    st.markdown(
        f"""
        <div class="hs-card" style="text-align:center;">
            <div class="hs-kpi-label">{t("forecast_confidence")}</div>
            <div class="hs-kpi-value" style="color:{tokens['accent']};">{confidence}%</div>
            <div class="hs-kpi-sub" title="Prototype heuristic — not a statistically validated probability">
                Data completeness · forecast horizon · consistency
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def section_title(text: str) -> None:
    st.markdown(f'<div class="hs-section-title">{text}</div>', unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# 1. EXACT HOSPITALS TABLE CARD COMPONENT
# ---------------------------------------------------------------------------
def render_hospitals_table_card(city_name: str, hospitals_df: pd.DataFrame) -> None:
    """Renders the hospitals table card matching the light theme styling."""
    city_upper = str(city_name).upper()

    header_html = (
        f'<div style="margin-top: 1.8rem; margin-bottom: 0.8rem;">'
        f'<div style="display: flex; align-items: center; gap: 8px; font-size: 0.85rem; font-weight: 800; color: #3A6357; letter-spacing: 0.08em; text-transform: uppercase;">'
        f'<span>🏥</span> HOSPITALS IN {city_upper}'
        f'</div>'
        f'<div style="font-size: 0.82rem; color: #52796F; margin-top: 4px; font-weight: 500;">'
        f'Distances are calculated from your GPS coordinates when available. Facility names are from the bundled directory and should be verified before use.'
        f'</div>'
        f'</div>'
    )
    st.markdown(header_html, unsafe_allow_html=True)

    if hospitals_df is None or hospitals_df.empty:
        st.info(f"No hospital records found for {city_name}.")
        return

    col_map = {str(c).lower().strip(): c for c in hospitals_df.columns}
    name_c = col_map.get("hospital name", col_map.get("hospital_name", col_map.get("name", "hospital")))
    beds_c = col_map.get("beds", col_map.get("dedicated heat ward", col_map.get("capacity", "beds")))
    lat_c = col_map.get("latitude", col_map.get("lat", "latitude"))
    lon_c = col_map.get("longitude", col_map.get("lon", col_map.get("lng", "longitude")))

    rows_html = ""
    for _, row in hospitals_df.iterrows():
        h_name = str(row[name_c]) if name_c and name_c in row else "Hospital Facility"
        beds = str(row[beds_c]) if beds_c and beds_c in row else "N/A"

        try:
            lat = f"{float(row[lat_c]):.5f}" if lat_c and lat_c in row and pd.notna(row[lat_c]) else "-"
        except (ValueError, TypeError):
            lat = str(row.get(lat_c, "-"))

        try:
            lon = f"{float(row[lon_c]):.5f}" if lon_c and lon_c in row and pd.notna(row[lon_c]) else "-"
        except (ValueError, TypeError):
            lon = str(row.get(lon_c, "-"))

        rows_html += (
            f'<tr style="border-bottom: 1px solid rgba(226, 232, 240, 0.8);">'
            f'<td style="padding: 16px 20px; font-weight: 600; color: #1E293B; font-size: 0.92rem;">{h_name}</td>'
            f'<td style="padding: 16px 20px; font-weight: 500; color: #1E293B; font-size: 0.92rem;">{beds}</td>'
            f'<td style="padding: 16px 20px; font-weight: 500; color: #1E293B; font-size: 0.92rem;">{lat}</td>'
            f'<td style="padding: 16px 20px; font-weight: 500; color: #1E293B; font-size: 0.92rem;">{lon}</td>'
            f'</tr>'
        )

    table_card_html = (
        f'<div style="background: #FFFFFF; border-radius: 18px; box-shadow: 0 10px 30px rgba(0,0,0,0.04); '
        f'overflow: hidden; border: 1.5px solid rgba(13, 148, 136, 0.15); margin-top: 10px; margin-bottom: 2rem;">'
        f'<table style="width: 100%; border-collapse: collapse; text-align: left; font-family: \'Inter\', sans-serif;">'
        f'<thead>'
        f'<tr style="background-color: #F7EFE3; border-bottom: 1px solid #EADBCE;">'
        f'<th style="padding: 18px 20px; font-size: 0.78rem; font-weight: 800; color: #0F172A; letter-spacing: 0.06em; text-transform: uppercase;">HOSPITAL NAME</th>'
        f'<th style="padding: 18px 20px; font-size: 0.78rem; font-weight: 800; color: #0F172A; letter-spacing: 0.06em; text-transform: uppercase;">BEDS</th>'
        f'<th style="padding: 18px 20px; font-size: 0.78rem; font-weight: 800; color: #0F172A; letter-spacing: 0.06em; text-transform: uppercase;">LATITUDE</th>'
        f'<th style="padding: 18px 20px; font-size: 0.78rem; font-weight: 800; color: #0F172A; letter-spacing: 0.06em; text-transform: uppercase;">LONGITUDE</th>'
        f'</tr>'
        f'</thead>'
        f'<tbody>{rows_html}</tbody>'
        f'</table>'
        f'</div>'
    )
    st.markdown(table_card_html, unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# 2. EXACT COOLING CENTRES TABLE CARD COMPONENT (LIGHT THEME MATCHING)
# ---------------------------------------------------------------------------
def render_cooling_centres_table_card(city_name: str, cooling_df: pd.DataFrame) -> None:
    """Renders the cooling centres table card in matching light cream/white styling."""
    city_upper = str(city_name).upper()

    header_html = (
        f'<div style="margin-top: 1.8rem; margin-bottom: 0.8rem;">'
        f'<div style="display: flex; align-items: center; gap: 8px; font-size: 0.85rem; font-weight: 800; color: #0284C7; letter-spacing: 0.08em; text-transform: uppercase;">'
        f'<span>❄️</span> DESIGNATED COOLING CENTRES & PUBLIC AC SHELTERS IN {city_upper}'
        f'</div>'
        f'<div style="font-size: 0.82rem; color: #52796F; margin-top: 4px; font-weight: 500;">'
        f'Public air-conditioned relief shelters and community cool zones with emergency hydration.'
        f'</div>'
        f'</div>'
    )
    st.markdown(header_html, unsafe_allow_html=True)

    if cooling_df is None or cooling_df.empty:
        st.info(f"No designated cooling shelters found for {city_name}.")
        return

    col_map = {str(c).lower().strip(): c for c in cooling_df.columns}
    name_c = col_map.get("name", col_map.get("centre", col_map.get("center", "name")))
    type_c = col_map.get("type", col_map.get("facility type", col_map.get("category", "type")))
    cap_c = col_map.get("capacity", col_map.get("persons", "capacity"))
    lat_c = col_map.get("latitude", col_map.get("lat", "latitude"))
    lon_c = col_map.get("longitude", col_map.get("lon", col_map.get("lng", "longitude")))

    rows_html = ""
    for _, row in cooling_df.iterrows():
        name = str(row[name_c]) if name_c and name_c in row else "Cooling Shelter"
        shelter_type = str(row[type_c]) if type_c and type_c in row else "Public AC Zone"
        cap = str(row[cap_c]) if cap_c and cap_c in row else "Available"

        try:
            lat = f"{float(row[lat_c]):.5f}" if lat_c and lat_c in row and pd.notna(row[lat_c]) else "-"
        except (ValueError, TypeError):
            lat = str(row.get(lat_c, "-"))

        try:
            lon = f"{float(row[lon_c]):.5f}" if lon_c and lon_c in row and pd.notna(row[lon_c]) else "-"
        except (ValueError, TypeError):
            lon = str(row.get(lon_c, "-"))

        rows_html += (
            f'<tr style="border-bottom: 1px solid rgba(226, 232, 240, 0.8);">'
            f'<td style="padding: 16px 20px; font-weight: 600; color: #1E293B; font-size: 0.92rem;">{name}</td>'
            f'<td style="padding: 16px 20px; font-weight: 600; color: #0284C7; font-size: 0.92rem;">{shelter_type}</td>'
            f'<td style="padding: 16px 20px; font-weight: 600; color: #1E293B; font-size: 0.92rem;">{cap}</td>'
            f'<td style="padding: 16px 20px; font-weight: 500; color: #1E293B; font-size: 0.92rem;">{lat}</td>'
            f'<td style="padding: 16px 20px; font-weight: 500; color: #1E293B; font-size: 0.92rem;">{lon}</td>'
            f'</tr>'
        )

    table_card_html = (
        f'<div style="background: #FFFFFF; border-radius: 18px; box-shadow: 0 10px 30px rgba(0,0,0,0.04); '
        f'overflow: hidden; border: 1.5px solid rgba(2, 132, 199, 0.18); margin-top: 10px; margin-bottom: 2rem;">'
        f'<table style="width: 100%; border-collapse: collapse; text-align: left; font-family: \'Inter\', sans-serif;">'
        f'<thead>'
        f'<tr style="background-color: #F7EFE3; border-bottom: 1px solid #EADBCE;">'
        f'<th style="padding: 18px 20px; font-size: 0.78rem; font-weight: 800; color: #0F172A; letter-spacing: 0.06em; text-transform: uppercase;">SHELTER NAME</th>'
        f'<th style="padding: 18px 20px; font-size: 0.78rem; font-weight: 800; color: #0F172A; letter-spacing: 0.06em; text-transform: uppercase;">TYPE</th>'
        f'<th style="padding: 18px 20px; font-size: 0.78rem; font-weight: 800; color: #0F172A; letter-spacing: 0.06em; text-transform: uppercase;">CAPACITY</th>'
        f'<th style="padding: 18px 20px; font-size: 0.78rem; font-weight: 800; color: #0F172A; letter-spacing: 0.06em; text-transform: uppercase;">LATITUDE</th>'
        f'<th style="padding: 18px 20px; font-size: 0.78rem; font-weight: 800; color: #0F172A; letter-spacing: 0.06em; text-transform: uppercase;">LONGITUDE</th>'
        f'</tr>'
        f'</thead>'
        f'<tbody>{rows_html}</tbody>'
        f'</table>'
        f'</div>'
    )
    st.markdown(table_card_html, unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# 3. EXACT WATER POINTS TABLE CARD COMPONENT (LIGHT THEME MATCHING)
# ---------------------------------------------------------------------------
def render_water_points_table_card(city_name: str, water_df: pd.DataFrame) -> None:
    """Renders the water points table card in matching light cream/white styling."""
    city_upper = str(city_name).upper()

    header_html = (
        f'<div style="margin-top: 1.8rem; margin-bottom: 0.8rem;">'
        f'<div style="display: flex; align-items: center; gap: 8px; font-size: 0.85rem; font-weight: 800; color: #0D9488; letter-spacing: 0.08em; text-transform: uppercase;">'
        f'<span>💧</span> PUBLIC DRINKING WATER POINTS IN {city_upper}'
        f'</div>'
        f'<div style="font-size: 0.82rem; color: #52796F; margin-top: 4px; font-weight: 500;">'
        f'Clean drinking water kiosks, RO plants, and municipal water points.'
        f'</div>'
        f'</div>'
    )
    st.markdown(header_html, unsafe_allow_html=True)

    if water_df is None or water_df.empty:
        st.info(f"No public water points found for {city_name}.")
        return

    col_map = {str(c).lower().strip(): c for c in water_df.columns}
    name_c = col_map.get("name", col_map.get("water_point", col_map.get("location", "name")))
    type_c = col_map.get("type", col_map.get("status", col_map.get("facility type", "type")))
    lat_c = col_map.get("latitude", col_map.get("lat", "latitude"))
    lon_c = col_map.get("longitude", col_map.get("lon", col_map.get("lng", "longitude")))

    rows_html = ""
    for _, row in water_df.iterrows():
        name = str(row[name_c]) if name_c and name_c in row else "Water Point"
        facility_type = str(row[type_c]) if type_c and type_c in row else "Free Drinking Water"

        try:
            lat = f"{float(row[lat_c]):.5f}" if lat_c and lat_c in row and pd.notna(row[lat_c]) else "-"
        except (ValueError, TypeError):
            lat = str(row.get(lat_c, "-"))

        try:
            lon = f"{float(row[lon_c]):.5f}" if lon_c and lon_c in row and pd.notna(row[lon_c]) else "-"
        except (ValueError, TypeError):
            lon = str(row.get(lon_c, "-"))

        rows_html += (
            f'<tr style="border-bottom: 1px solid rgba(226, 232, 240, 0.8);">'
            f'<td style="padding: 16px 20px; font-weight: 600; color: #1E293B; font-size: 0.92rem;">{name}</td>'
            f'<td style="padding: 16px 20px; font-weight: 600; color: #0D9488; font-size: 0.92rem;">{facility_type}</td>'
            f'<td style="padding: 16px 20px; font-weight: 500; color: #1E293B; font-size: 0.92rem;">{lat}</td>'
            f'<td style="padding: 16px 20px; font-weight: 500; color: #1E293B; font-size: 0.92rem;">{lon}</td>'
            f'</tr>'
        )

    table_card_html = (
        f'<div style="background: #FFFFFF; border-radius: 18px; box-shadow: 0 10px 30px rgba(0,0,0,0.04); '
        f'overflow: hidden; border: 1.5px solid rgba(13, 148, 136, 0.18); margin-top: 10px; margin-bottom: 2rem;">'
        f'<table style="width: 100%; border-collapse: collapse; text-align: left; font-family: \'Inter\', sans-serif;">'
        f'<thead>'
        f'<tr style="background-color: #F7EFE3; border-bottom: 1px solid #EADBCE;">'
        f'<th style="padding: 18px 20px; font-size: 0.78rem; font-weight: 800; color: #0F172A; letter-spacing: 0.06em; text-transform: uppercase;">WATER POINT NAME</th>'
        f'<th style="padding: 18px 20px; font-size: 0.78rem; font-weight: 800; color: #0F172A; letter-spacing: 0.06em; text-transform: uppercase;">TYPE / STATUS</th>'
        f'<th style="padding: 18px 20px; font-size: 0.78rem; font-weight: 800; color: #0F172A; letter-spacing: 0.06em; text-transform: uppercase;">LATITUDE</th>'
        f'<th style="padding: 18px 20px; font-size: 0.78rem; font-weight: 800; color: #0F172A; letter-spacing: 0.06em; text-transform: uppercase;">LONGITUDE</th>'
        f'</tr>'
        f'</thead>'
        f'<tbody>{rows_html}</tbody>'
        f'</table>'
        f'</div>'
    )
    st.markdown(table_card_html, unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# FORECAST CARDS & RISK PEAK HIGHLIGHT BANNER
# ---------------------------------------------------------------------------
def render_forecast_cards(forecast_days: list[dict], range_label: str = "5-DAY") -> None:
    st.markdown(
        f"""
        <div style="font-size: 0.82rem; font-weight: 800; color: #3A6357; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 12px; margin-top: 14px;">
            🗓️ {range_label} WEATHER FORECAST
        </div>
        """,
        unsafe_allow_html=True,
    )

    if not forecast_days:
        st.info("No forecast cards available for the selected range.")
        return

    cols = st.columns(len(forecast_days))
    for col, day in zip(cols, forecast_days):
        border_top_color = "#E11D48" if day.get("risk", 0) >= 70 else "#F97316"
        risk_color = "#E11D48" if day.get("risk", 0) >= 70 else "#EA580C"

        with col:
            st.markdown(
                f"""
                <div style="background: #FFFFFF; border-radius: 16px; padding: 18px 16px;
                            border: 1px solid rgba(226, 232, 240, 0.8);
                            border-top: 4px solid {border_top_color};
                            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.04);
                            display: flex; flex-direction: column; justify-content: space-between;
                            min-height: 185px;">
                    <div>
                        <div style="font-size: 0.75rem; font-weight: 800; color: #334155; text-transform: uppercase; letter-spacing: 0.05em;">
                            {day.get('day_label', 'DAY')}
                        </div>
                        <div style="font-size: 0.80rem; color: #64748B; margin-top: 2px; font-weight: 600;">
                            {day.get('date_str', '')}
                        </div>
                        <div style="font-size: 1.55rem; font-weight: 800; color: #0F172A; margin-top: 14px; line-height: 1.1;">
                            {day.get('temp_max', 0.0):.1f}° <span style="font-size: 0.95rem; font-weight: 700; color: #475569;">/ {day.get('temp_min', 0.0):.1f}°</span>
                        </div>
                        <div style="font-size: 0.78rem; color: #475569; margin-top: 8px; display: flex; align-items: center; gap: 4px; font-weight: 600;">
                            <span>💧</span> {day.get('humidity', 50):.0f}% humidity
                        </div>
                    </div>
                    <div style="font-size: 0.80rem; font-weight: 800; color: {risk_color}; margin-top: 14px;">
                        Peak risk {int(day.get('risk', 0))}/100
                    </div>
                </div>
                """,
                unsafe_allow_html=True,
            )

    st.markdown(
        """
        <div style="font-size: 0.82rem; color: #4A6B62; margin-top: 10px; font-weight: 500; margin-bottom: 12px;">
            Forecast synced with selected location coordinates.
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_risk_peak_card(peak_time: str = "08:00 – 17:00", peak_score: int = 67) -> None:
    st.markdown(
        f"""
        <div style="margin-top: 1.8rem; margin-bottom: 0.6rem;">
            <div style="font-size: 0.80rem; font-weight: 800; color: #3A6357; letter-spacing: 0.08em; text-transform: uppercase;">
                WHEN WILL THE RISK PEAK?
            </div>
        </div>
        <div style="background: #FFFFFF; border-radius: 20px; border: 1.5px solid rgba(13, 148, 136, 0.22);
                    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.03); padding: 26px; text-align: center; margin-bottom: 2rem;">
            <div style="font-size: 2.1rem; font-weight: 900; color: #7E22CE; letter-spacing: -0.02em;">
                {peak_time}
            </div>
            <div style="font-size: 0.95rem; font-weight: 600; color: #475569; margin-top: 6px;">
                Peak health-risk score: {peak_score}/100
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )
