"""
utils/constants.py

Centralized constants for HeatShield India.
All thresholds, colors, weights, and static labels live here so that
no "magic numbers" are scattered through the application.
"""

from __future__ import annotations

# --------------------------------------------------------------------------
# APP META
# --------------------------------------------------------------------------
APP_NAME = "HeatShield India"
APP_TAGLINE = "Localized Human Thermal Stress & Heat Health Early Warning System"
APP_VERSION = "1.0.0-prototype"

# --------------------------------------------------------------------------
# DEMO / DATA TRANSPARENCY
# --------------------------------------------------------------------------
DEMO_MODE_NOTICE = (
    "DEMO MODE — Using simulated forecast and vulnerability data for "
    "demonstration purposes. Live weather integration is optional and "
    "falls back automatically to this dataset if unavailable."
)

HTSS_DISCLAIMER = (
    "Human Thermal Stress Score (HTSS) is a transparent PROTOTYPE index "
    "based on temperature, humidity, solar radiation, wind and heat "
    "duration. It is inspired by concepts used in indices such as the "
    "Universal Thermal Climate Index (UTCI) but is NOT an official "
    "government index and has not been clinically validated."
)

MODEL_DISCLAIMER = (
    "This prototype estimates vulnerability-adjusted heat-health risk "
    "using weather conditions and established thermal-stress concepts. "
    "It does not predict individual health outcomes or mortality."
)

# --------------------------------------------------------------------------
# HTSS (Human Thermal Stress Score) WEIGHTS  -- 0-100 scale
# HTSS = 0.40(Tn) + 0.25(Hn) + 0.15(Rn) + 0.10(Ln) + 0.10(Dn)
# --------------------------------------------------------------------------
HTSS_WEIGHTS = {
    "temperature": 0.40,   # Tn - normalized temperature risk
    "humidity": 0.25,      # Hn - normalized humidity risk
    "radiation": 0.15,     # Rn - normalized solar radiation risk
    "wind": 0.10,          # Ln - low-wind risk
    "duration": 0.10,      # Dn - consecutive hot days / night recovery risk
}

# Normalization reference ranges used by thermal_engine.py
TEMP_MIN_C, TEMP_MAX_C = 20.0, 48.0          # air temperature range
HUMIDITY_MIN, HUMIDITY_MAX = 10.0, 95.0       # relative humidity %
RADIATION_MIN, RADIATION_MAX = 100.0, 1000.0  # W/m^2 solar radiation
WIND_LOW_THRESHOLD = 3.0                      # m/s - below this, risk rises
WIND_MAX_FOR_RISK = 0.2                       # m/s floor used in low-wind calc
MAX_CONSECUTIVE_HOT_DAYS = 7                   # cap for duration normalization

# --------------------------------------------------------------------------
# HTSS CATEGORY THRESHOLDS
# --------------------------------------------------------------------------
HTSS_CATEGORIES = [
    {"min": 0, "max": 25, "key": "low", "label": "LOW"},
    {"min": 26, "max": 50, "key": "moderate", "label": "MODERATE"},
    {"min": 51, "max": 70, "key": "high", "label": "HIGH"},
    {"min": 71, "max": 85, "key": "very_high", "label": "VERY HIGH"},
    {"min": 86, "max": 100, "key": "extreme", "label": "EXTREME"},
]

# --------------------------------------------------------------------------
# VULNERABILITY ENGINE WEIGHTS
# --------------------------------------------------------------------------
VULNERABILITY_WEIGHTS = {
    "elderly_population": 0.30,
    "population_density": 0.25,
    "outdoor_worker_exposure": 0.20,
    "low_green_cover": 0.15,
    "healthcare_access": 0.10,   # NOTE: lower healthcare access => higher risk contribution
}

# Normalization reference ranges for vulnerability inputs
ELDERLY_PCT_MAX = 20.0             # % population above 60
POP_DENSITY_MAX = 30000.0          # people / sq km (urban India range)
OUTDOOR_WORKER_PCT_MAX = 60.0      # % of workforce in outdoor occupations
GREEN_COVER_MAX_PCT = 40.0         # % green cover considered "good"
HEALTHCARE_ACCESS_MAX_SCORE = 100.0  # 0-100 accessibility score (higher = better)

# --------------------------------------------------------------------------
# HEALTH RISK ENGINE — PRIMARY PROTOTYPE MODEL
# Heat Health Risk = 0.65 * Thermal Stress + 0.35 * Vulnerability
# --------------------------------------------------------------------------
RISK_MODEL_PRIMARY = {
    "thermal_stress": 0.65,
    "vulnerability": 0.35,
}

# Optional extended model (documented, not mixed with primary at runtime)
RISK_MODEL_EXTENDED = {
    "thermal_stress": 0.50,
    "population_vulnerability": 0.20,
    "exposure": 0.15,
    "urban_heat_island": 0.10,
    "healthcare_accessibility_risk": 0.05,
}

ACTIVE_RISK_MODEL = "primary"  # "primary" or "extended"

# --------------------------------------------------------------------------
# HEALTH RISK LEVELS
# --------------------------------------------------------------------------
RISK_LEVELS = [
    {
        "min": 0, "max": 25, "key": "green", "label": "LOW",
        "color": "#2ECC71", "bg": "rgba(46, 204, 113, 0.14)", "icon": "🟢",
        "description": "Minimal heat-health risk under current conditions.",
        "action": "No special heat-health action required.",
    },
    {
        "min": 26, "max": 50, "key": "yellow", "label": "MODERATE",
        "color": "#F1C40F", "bg": "rgba(241, 196, 15, 0.14)", "icon": "🟡",
        "description": "Mild heat stress possible for sensitive groups.",
        "action": "Vulnerable residents should reduce prolonged heat exposure.",
    },
    {
        "min": 51, "max": 70, "key": "orange", "label": "HIGH",
        "color": "#E67E22", "bg": "rgba(230, 126, 34, 0.16)", "icon": "🟠",
        "description": "Elevated risk of heat-related illness during peak hours.",
        "action": "Restrict unnecessary outdoor exposure during peak hours.",
    },
    {
        "min": 71, "max": 85, "key": "red", "label": "VERY HIGH",
        "color": "#E74C3C", "bg": "rgba(231, 76, 60, 0.18)", "icon": "🔴",
        "description": "Significant danger of heat illness for large population groups.",
        "action": "Protective action required. Modify outdoor work and activate preparedness measures.",
    },
    {
        "min": 86, "max": 100, "key": "extreme", "label": "EXTREME",
        "color": "#8E44AD", "bg": "rgba(142, 68, 173, 0.20)", "icon": "🟣",
        "description": "Severe, potentially life-threatening heat-health emergency.",
        "action": "Activate emergency heat-health response.",
    },
]

# --------------------------------------------------------------------------
# USER ROLES / AUDIENCES
# --------------------------------------------------------------------------
USER_ROLES = [
    "Citizen",
    "Outdoor Worker",
    "Hospital",
    "School",
    "Authority",
    "Employer",
]

# --------------------------------------------------------------------------
# LANGUAGES
# --------------------------------------------------------------------------
LANGUAGES = {
    "English": "en",
    "हिन्दी": "hi",
    "मराठी": "mr",
    "தமிழ்": "ta",
    "తెలుగు": "te",
    "বাংলা": "bn",
    "ગુજરાતી": "gu",
    "ಕನ್ನಡ": "kn",
}
FULLY_SUPPORTED_LANGUAGES = ("en", "hi")

# --------------------------------------------------------------------------
# LOCATIONS
# --------------------------------------------------------------------------
DEFAULT_LOCATION = "Nagpur"
DEMO_LOCATIONS = ["Nagpur", "Delhi", "Ahmedabad", "Chennai", "Hyderabad", "Jaipur"]

# --------------------------------------------------------------------------
# NAVIGATION
# --------------------------------------------------------------------------
NAV_PAGES = [
    ("🏠", "Dashboard"),
    ("🗺️", "Risk Map"),
    ("📍", "Location Analysis"),
    ("📈", "Forecast"),
    ("🧭", "Vulnerability"),
    ("🚨", "Alerts"),
    ("🛡️", "Precautions"),
    ("🏛️", "Authority Dashboard"),
    ("📖", "Methodology"),
    ("ℹ️", "About"),
]

# --------------------------------------------------------------------------
# MISC
# --------------------------------------------------------------------------
RANDOM_SEED = 42
FORECAST_HORIZON_DAYS = 5
