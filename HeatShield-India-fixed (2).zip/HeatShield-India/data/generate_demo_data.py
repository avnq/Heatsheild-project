"""
data/generate_demo_data.py

One-time (re-runnable) generator for realistic OFFLINE DEMO datasets
used by HeatShield India.

The generated demographic data is simulated for prototype/demo use.
Pregnant-women and infant percentages are included so the application
can show role-specific vulnerability instead of using one identical
vulnerability input for every audience.

Usage:
    python data/generate_demo_data.py
"""

from __future__ import annotations

import os
import random

import numpy as np
import pandas as pd

random.seed(42)
np.random.seed(42)

HERE = os.path.dirname(os.path.abspath(__file__))

# --------------------------------------------------------------------
# CITY BASE PROFILES
# --------------------------------------------------------------------

CITIES = {
    "Nagpur": {
        "state": "Maharashtra",
        "lat": 21.1458,
        "lon": 79.0882,
        "base_temp": 42.4,
        "base_humidity": 61,
        "base_wind": 1.8,
        "base_radiation": 820,
        "population": 2497777,
        "hot_days": 6,
    },
    "Delhi": {
        "state": "Delhi",
        "lat": 28.7041,
        "lon": 77.1025,
        "base_temp": 44.1,
        "base_humidity": 38,
        "base_wind": 2.4,
        "base_radiation": 880,
        "population": 16787941,
        "hot_days": 7,
    },
    "Ahmedabad": {
        "state": "Gujarat",
        "lat": 23.0225,
        "lon": 72.5714,
        "base_temp": 43.0,
        "base_humidity": 45,
        "base_wind": 2.1,
        "base_radiation": 850,
        "population": 5570585,
        "hot_days": 5,
    },
    "Chennai": {
        "state": "Tamil Nadu",
        "lat": 13.0827,
        "lon": 80.2707,
        "base_temp": 38.2,
        "base_humidity": 74,
        "base_wind": 3.4,
        "base_radiation": 760,
        "population": 4646732,
        "hot_days": 3,
    },
    "Hyderabad": {
        "state": "Telangana",
        "lat": 17.3850,
        "lon": 78.4867,
        "base_temp": 40.5,
        "base_humidity": 48,
        "base_wind": 2.6,
        "base_radiation": 800,
        "population": 6809970,
        "hot_days": 4,
    },
    "Jaipur": {
        "state": "Rajasthan",
        "lat": 26.9124,
        "lon": 75.7873,
        "base_temp": 43.8,
        "base_humidity": 33,
        "base_wind": 2.9,
        "base_radiation": 870,
        "population": 3073350,
        "hot_days": 6,
    },
}

WARDS_PER_CITY = 6

# --------------------------------------------------------------------
# NAMED-LOCALITY OVERRIDES (real coordinates, real names)
# --------------------------------------------------------------------
# The generic "Ward 1..6" points above are placed at RANDOM offsets
# around each city's centre -- fine for a coarse city-level demo, but
# too sparse for the live-GPS "nearest location" match: someone
# standing in a real West/North-West Delhi colony could easily be
# 6-8 km from the closest random "Ward N" point and get matched to
# totally the wrong locality.
#
# For Delhi we instead use a curated list of REAL, named localities at
# their approximate real-world coordinates, so GPS users get matched
# to somewhere they actually recognise instead of "Ward 3".
# Coordinates below are approximate locality-centre points (a few
# hundred metres of tolerance), good enough for nearest-match demo
# purposes -- not survey-grade.
CITY_WARD_OVERRIDES = {
    "Delhi": [
        ("Mahavir Enclave Part 1", 28.6112, 77.0692),
        ("Dashrath Puri", 28.6168, 77.0724),
        ("Shalimar Bagh", 28.7169, 77.1642),
        ("Dwarka Sector 4", 28.5916, 77.0473),
        ("Paschim Vihar East", 28.6733, 77.1032),
        ("Paschim Vihar West", 28.6765, 77.0933),
        ("Peeragarhi", 28.6733, 77.0906),
        ("Punjabi Bagh", 28.6692, 77.1312),
        ("Mayur Vihar Phase 1", 28.6096, 77.2955),
    ],
}


def jitter(value: float, pct: float = 0.06) -> float:
    return value * (1 + np.random.uniform(-pct, pct))


def generate_locations() -> pd.DataFrame:
    """Generate ward-level simulated demographic/environmental data."""

    rows = []

    for city, profile in CITIES.items():
        overrides = CITY_WARD_OVERRIDES.get(city)
        # Named real localities (if defined for this city), else the
        # generic random "Ward N" points used for every other city.
        ward_specs = (
            [(name, lat, lon) for name, lat, lon in overrides]
            if overrides
            else [
                (
                    f"Ward {w}",
                    profile["lat"] + np.random.uniform(-0.06, 0.06),
                    profile["lon"] + np.random.uniform(-0.06, 0.06),
                )
                for w in range(1, WARDS_PER_CITY + 1)
            ]
        )

        for w, (ward_name, lat, lon) in enumerate(ward_specs, start=1):
            location_id = f"{city.upper()}-W{w}"

            # Existing vulnerability inputs.
            elderly_pct = round(
                np.clip(np.random.normal(9, 3), 3, 19), 1
            )
            density = int(
                np.clip(np.random.normal(14000, 6000), 2000, 29500)
            )
            outdoor_worker_pct = round(
                np.clip(np.random.normal(28, 12), 4, 58), 1
            )
            green_cover_pct = round(
                np.clip(np.random.normal(14, 8), 1, 38), 1
            )
            healthcare_access = round(
                np.clip(np.random.normal(58, 18), 10, 98), 1
            )

            # ---------------------------------------------------------
            # NEW: simulated role-specific demographic indicators.
            #
            # These are prototype/demo percentages, not real census
            # or clinical statistics.
            #
            # Different random values are generated for every ward so
            # Pregnant Women and Infants do not receive identical data.
            # ---------------------------------------------------------
            pregnant_women_pct = round(
                np.clip(np.random.normal(4.2, 1.0), 2.0, 6.5), 1
            )
            infants_pct = round(
                np.clip(np.random.normal(2.8, 0.7), 1.2, 4.5), 1
            )

            ward_population = int(
                profile["population"]
                / len(ward_specs)
                * np.random.uniform(0.8, 1.2)
            )

            rows.append(
                {
                    "location_id": location_id,
                    "city": city,
                    "ward_name": ward_name,
                    "state": profile["state"],
                    "lat": round(lat, 5),
                    "lon": round(lon, 5),
                    "population": ward_population,
                    "population_density": density,
                    "elderly_pct": elderly_pct,
                    "outdoor_worker_pct": outdoor_worker_pct,
                    "green_cover_pct": green_cover_pct,
                    "healthcare_access_score": healthcare_access,
                    "pregnant_women_pct": pregnant_women_pct,
                    "infants_pct": infants_pct,
                }
            )

    return pd.DataFrame(rows)


def generate_weather(locations_df: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for _, loc in locations_df.iterrows():
        profile = CITIES[loc["city"]]

        temp = round(jitter(profile["base_temp"]), 1)
        humidity = round(
            np.clip(jitter(profile["base_humidity"]), 10, 95), 1
        )
        wind = round(
            np.clip(jitter(profile["base_wind"]), 0.2, 12), 1
        )
        radiation = round(
            np.clip(jitter(profile["base_radiation"]), 100, 1000), 0
        )
        hot_days = int(
            np.clip(
                profile["hot_days"] + np.random.randint(-1, 2),
                1,
                7,
            )
        )
        night_temp = round(
            np.clip(temp - np.random.uniform(6, 11), 20, 34), 1
        )

        rows.append(
            {
                "location_id": loc["location_id"],
                "temperature_c": temp,
                "humidity_pct": humidity,
                "wind_ms": wind,
                "solar_radiation_wm2": radiation,
                "consecutive_hot_days": hot_days,
                "night_recovery_temp_c": night_temp,
            }
        )

    return pd.DataFrame(rows)


def generate_forecast(
    locations_df: pd.DataFrame,
    days: int = 5,
) -> pd.DataFrame:
    """Generate an hourly forecast for each location."""

    rows = []
    hours = days * 24

    for _, loc in locations_df.iterrows():
        profile = CITIES[loc["city"]]

        base_temp = profile["base_temp"]
        base_hum = profile["base_humidity"]
        base_wind = profile["base_wind"]
        base_rad = profile["base_radiation"]

        for h in range(hours):
            day_idx = h // 24
            hour_of_day = h % 24

            temp_swing = 7.5 * np.sin(
                (hour_of_day - 8) / 24 * 2 * np.pi
            )
            day_drift = (
                np.random.uniform(-0.6, 0.9) * day_idx * 0.3
            )

            temp = round(
                np.clip(
                    base_temp
                    - 2
                    + temp_swing
                    + day_drift
                    + np.random.normal(0, 0.4),
                    22,
                    49,
                ),
                1,
            )

            humidity = round(
                np.clip(
                    base_hum
                    + 12
                    * np.cos(
                        (hour_of_day - 4) / 24 * 2 * np.pi
                    )
                    + np.random.normal(0, 2),
                    10,
                    96,
                ),
                1,
            )

            wind = round(
                np.clip(
                    base_wind
                    + np.random.normal(0, 0.5)
                    - 0.5
                    * np.sin(
                        (hour_of_day - 15) / 24 * 2 * np.pi
                    ),
                    0.2,
                    12,
                ),
                1,
            )

            if 6 <= hour_of_day <= 18:
                rad = base_rad * max(
                    0.0,
                    np.sin(
                        (hour_of_day - 6) / 12 * np.pi
                    ),
                )
            else:
                rad = 0.0

            rad = round(
                np.clip(
                    rad + np.random.normal(0, 20),
                    0,
                    1050,
                ),
                0,
            )

            rows.append(
                {
                    "location_id": loc["location_id"],
                    "hour_index": h,
                    "day_index": day_idx,
                    "hour_of_day": hour_of_day,
                    "temperature_c": temp,
                    "humidity_pct": humidity,
                    "wind_ms": wind,
                    "solar_radiation_wm2": rad,
                    "consecutive_hot_days": min(
                        7,
                        day_idx + int(profile["hot_days"] / 2) + 1,
                    ),
                }
            )

    return pd.DataFrame(rows)


def generate_support_points(
    locations_df: pd.DataFrame,
):
    hospitals, cooling, water = [], [], []

    hospital_names = [
        "General Hospital",
        "Civil Hospital",
        "Community Health Centre",
        "District Hospital",
    ]
    cooling_names = [
        "Community Cooling Centre",
        "Municipal Cooling Hall",
        "School Cooling Shelter",
    ]
    water_names = [
        "Municipal Water Point",
        "Public Water Tanker Stop",
        "RO Water Kiosk",
    ]

    for _, loc in locations_df.iterrows():
        for i in range(np.random.randint(1, 3)):
            hospitals.append(
                {
                    "location_id": loc["location_id"],
                    "city": loc["city"],
                    "name": (
                        f"{loc['ward_name']} "
                        f"{random.choice(hospital_names)} {i + 1}"
                    ),
                    "lat": round(
                        loc["lat"]
                        + np.random.uniform(-0.01, 0.01),
                        5,
                    ),
                    "lon": round(
                        loc["lon"]
                        + np.random.uniform(-0.01, 0.01),
                        5,
                    ),
                    "beds": int(np.random.randint(20, 250)),
                }
            )

        for i in range(np.random.randint(1, 3)):
            cooling.append(
                {
                    "location_id": loc["location_id"],
                    "city": loc["city"],
                    "name": (
                        f"{loc['ward_name']} "
                        f"{random.choice(cooling_names)} {i + 1}"
                    ),
                    "lat": round(
                        loc["lat"]
                        + np.random.uniform(-0.012, 0.012),
                        5,
                    ),
                    "lon": round(
                        loc["lon"]
                        + np.random.uniform(-0.012, 0.012),
                        5,
                    ),
                    "capacity": int(np.random.randint(30, 300)),
                }
            )

        for i in range(np.random.randint(1, 4)):
            water.append(
                {
                    "location_id": loc["location_id"],
                    "city": loc["city"],
                    "name": (
                        f"{loc['ward_name']} "
                        f"{random.choice(water_names)} {i + 1}"
                    ),
                    "lat": round(
                        loc["lat"]
                        + np.random.uniform(-0.012, 0.012),
                        5,
                    ),
                    "lon": round(
                        loc["lon"]
                        + np.random.uniform(-0.012, 0.012),
                        5,
                    ),
                }
            )

    return (
        pd.DataFrame(hospitals),
        pd.DataFrame(cooling),
        pd.DataFrame(water),
    )


def main():
    locations_df = generate_locations()
    weather_df = generate_weather(locations_df)
    forecast_df = generate_forecast(locations_df, days=5)
    hospitals_df, cooling_df, water_df = generate_support_points(
        locations_df
    )

    locations_df.to_csv(
        os.path.join(HERE, "locations.csv"),
        index=False,
    )
    weather_df.to_csv(
        os.path.join(HERE, "weather.csv"),
        index=False,
    )
    forecast_df.to_csv(
        os.path.join(HERE, "forecast.csv"),
        index=False,
    )
    hospitals_df.to_csv(
        os.path.join(HERE, "hospitals.csv"),
        index=False,
    )
    cooling_df.to_csv(
        os.path.join(HERE, "cooling_centres.csv"),
        index=False,
    )
    water_df.to_csv(
        os.path.join(HERE, "water_points.csv"),
        index=False,
    )

    # vulnerability.csv mirrors the relevant columns of locations.csv.
    vuln_cols = [
        "location_id",
        "city",
        "ward_name",
        "elderly_pct",
        "population_density",
        "outdoor_worker_pct",
        "green_cover_pct",
        "healthcare_access_score",
        "pregnant_women_pct",
        "infants_pct",
    ]

    locations_df[vuln_cols].to_csv(
        os.path.join(HERE, "vulnerability.csv"),
        index=False,
    )

    print("Demo data generated:")
    for filename in [
        "locations.csv",
        "weather.csv",
        "forecast.csv",
        "hospitals.csv",
        "cooling_centres.csv",
        "water_points.csv",
        "vulnerability.csv",
    ]:
        print(" -", filename)

    print(
        "\nNOTE: pregnant_women_pct and infants_pct are "
        "SIMULATED DEMO indicators."
    )


if __name__ == "__main__":
    main()
