"""
app.py

HEATSHIELD INDIA — Localized Human Thermal Stress & Heat Health
Early Warning System.
"""

from __future__ import annotations
import uuid
import folium
import pandas as pd
import streamlit as st
from streamlit_folium import st_folium

from utils.constants import (
    APP_NAME, APP_TAGLINE, DEMO_LOCATIONS, RISK_LEVELS, HTSS_CATEGORIES,
    HTSS_WEIGHTS, VULNERABILITY_WEIGHTS, RISK_MODEL_PRIMARY, MODEL_DISCLAIMER,
    HTSS_DISCLAIMER,
)
from utils.helpers import format_ist_timestamp, heat_index_c, sky_condition_from_solar, heat_feel_label
from frontend.styles import inject_global_css, get_current_theme, THEMES
from frontend.animations import (
    run_startup_sequence, animated_counter, animated_gauge, animated_pipeline,
    pulsing_alert_banner,
)
from frontend.components import (
    page_header, status_bar, demo_mode_badge, hero_risk_panel, driver_chips,
    risk_driver_explainer, alert_card, confidence_meter, section_title,
    htss_disclaimer, kpi_card_static, render_hospitals_table_card,
    render_cooling_centres_table_card, render_water_points_table_card,
    render_forecast_cards, render_risk_peak_card,
)
from frontend.charts import (
    risk_timeline_chart, thermal_stress_timeline_chart, multi_variable_chart,
    wind_radiation_chart, risk_component_breakdown_chart, five_day_forecast_chart,
    vulnerability_comparison_chart,
)
from frontend.maps import (
    build_risk_map,
    DEFAULT_CITY_HOSPITALS,
    DEFAULT_COOLING_CENTRES,
    DEFAULT_WATER_POINTS,
)
from frontend.ui_helpers import (
    init_session_state, render_sidebar, get_selected_location_id, scenario_boost, t,
    current_lang_code, render_role_selector,
)
from frontend.login import render_login_page
from backend.sms_service import send_heat_alert_sms

from backend.api_service import (
    get_locations, get_current_risk, get_map_risk, get_vulnerability_ranking,
    generate_alerts, generate_alerts_for_all, get_recommendations, get_dashboard_kpis,
    get_hospitals, get_cooling_centres, get_water_points, compute_location_bundle,
)
from backend.forecast_service import get_forecast, get_peak_risk_summary, get_forecast_confidence
from backend.vulnerability_engine import calculate_role_vulnerability, vulnerability_label_and_color


st.set_page_config(
    page_title=f"{APP_NAME} | Dhristi",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)

init_session_state()

if "theme" not in st.session_state:
    st.session_state["theme"] = "light"

inject_global_css()

# --------------------------------------------------------------------------
# AUTHENTICATION GATEKEEPER
# --------------------------------------------------------------------------
if "authenticated" not in st.session_state:
    st.session_state["authenticated"] = False

if not st.session_state["authenticated"]:
    render_login_page()
    st.stop()

# Theme toggle & User Profile block on top of the sidebar
with st.sidebar:
    user = st.session_state.get("user_profile")
    if user:
        _profile_name_color = "#F4F6FB" if get_current_theme() == "dark" else "#0A352C"
        st.markdown(
            f"""
            <div style="background: rgba(13, 148, 136, 0.12); border: 1.5px solid #0D9488;
                        border-radius: 12px; padding: 10px 14px; margin-bottom: 12px;">
                <div style="font-weight:800; font-size:0.86rem; color:{_profile_name_color};">👤 {user.get('name', 'User')}</div>
                <div style="font-size:0.75rem; color:#0D9488; font-weight:700; margin-top:2px;">
                    Role: {user.get('role', 'Citizen')} | Gender: {user.get('gender', 'Female')}
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        if st.button("🚪 Sign Out", key="btn_logout_user", use_container_width=True):
            st.session_state["authenticated"] = False
            st.session_state["user_profile"] = None
            st.rerun()

    st.markdown(
        f"<div class='hs-section-title' style='margin-bottom:6px;'>APPEARANCE THEME</div>",
        unsafe_allow_html=True,
    )
    current_mode = st.session_state.get("theme", "light")
    theme_selection = st.selectbox(
        "Display Mode",
        options=["Mint / Light Mode", "Dark Mode"],
        index=0 if current_mode == "light" else 1,
        key="app_theme_toggle_select",
        label_visibility="collapsed",
    )
    mapped_theme = "light" if "Light" in theme_selection else "dark"
    if mapped_theme != st.session_state["theme"]:
        st.session_state["theme"] = mapped_theme
        st.rerun()

    st.markdown("<hr class='hs-divider' style='margin: 0.8rem 0 1.2rem 0;'/>", unsafe_allow_html=True)

# Data Saver Check: Disables heavy animations on boot
is_data_saver = st.session_state.get("data_saver", False)

if not is_data_saver and not st.session_state.get("booted", False):
    run_startup_sequence()
    st.session_state["booted"] = True
else:
    st.session_state["booted"] = True

locations_df = get_locations()
render_sidebar(locations_df)

location_id = get_selected_location_id(locations_df)
boost = scenario_boost()
page = st.session_state["page"]


def trigger_system_notification(headline: str, message: str):
    notify_script = f"""
    <script>
    if (Notification.permission === 'granted') {{
        navigator.serviceWorker.ready.then(function(reg) {{
            reg.showNotification("{headline}", {{
                body: "{message}",
                icon: "https://img.icons8.com/fluency/192/fire-element.png"
            }});
        }});
    }}
    </script>
    """
    st.components.v1.html(notify_script, height=0, width=0)


def render_styled_table(df, max_rows: int = 10) -> None:
    is_light = st.session_state.get("theme", "light") == "light"
    if is_light:
        bg_card = "#FCFBF7"
        header_bg = "#F3EDE1"
        row_even = "#FCFBF7"
        row_odd = "#F8F7F2"
        text_color = "#0A352C"
        border_color = "rgba(13, 148, 136, 0.25)"
    else:
        bg_card = "#131A2A"
        header_bg = "#161F33"
        row_even = "#131A2A"
        row_odd = "#161F33"
        text_color = "#F4F6FB"
        border_color = "rgba(255, 255, 255, 0.08)"

    display_df = df.head(max_rows)
    headers_html = "".join([f"<th style='padding:12px 16px; text-align:left; font-size:0.82rem; font-weight:700; text-transform:uppercase; letter-spacing:0.04em;'>{col}</th>" for col in display_df.columns])
    
    rows_html = ""
    for idx, row in display_df.iterrows():
        bg = row_even if idx % 2 == 0 else row_odd
        cells = "".join([f"<td style='padding:10px 16px; font-size:0.88rem;'>{row[col]}</td>" for col in display_df.columns])
        rows_html += f"<tr style='background:{bg}; border-bottom:1px solid {border_color};'>{cells}</tr>"

    table_html = f"""
    <div style="background:{bg_card}; border:1.5px solid {border_color}; border-radius:14px; overflow:hidden; box-shadow:0 4px 18px rgba(0,0,0,0.05); margin-bottom:1rem;">
        <table style="width:100%; border-collapse:collapse; color:{text_color}; font-family:'Inter',sans-serif;">
            <thead>
                <tr style="background:{header_bg}; color:{text_color}; border-bottom:1.5px solid {border_color};">
                    {headers_html}
                </tr>
            </thead>
            <tbody>
                {rows_html}
            </tbody>
        </table>
    </div>
    """
    st.markdown(table_html, unsafe_allow_html=True)


REAL_LOCALITY_MAP = {
    "delhi": ["Connaught Place", "Rohini Sector 10", "Karol Bagh", "Dwarka Sector 6", "Lajpat Nagar", "Chandni Chowk", "Pitampura", "Saket"],
    "nagpur": ["Sitabuldi", "Dharampeth", "Sadar", "Ramdaspeth", "Wardhaman Nagar", "Manish Nagar", "Civil Lines", "Gandhibagh"],
    "ahmedabad": ["Navrangpura", "Maninagar", "Vastrapur", "Satellite", "Bopal", "Paldi", "Ghatlodia", "Ellisbridge"],
    "mumbai": ["Dharavi", "Bandra West", "Andheri East", "Colaba", "Dadra Parel", "Borivali West", "Kurla", "Ghatkopar"],
    "kolkata": ["Park Street", "Salt Lake Sector 5", "Howrah Station", "Gariahat", "New Town", "Shyambazar", "Ballygunge", "Alipore"],
    "chennai": ["T. Nagar", "Adyar", "Mylapore", "Anna Nagar", "Velachery", "George Town", "Guindy", "Royapettah"],
    "hyderabad": ["Banjara Hills", "Secunderabad", "Gachibowli", "Charminar", "Kukatpally", "Madhapur", "Ameerpet", "Begumpet"],
    "jaipur": ["Malviya Nagar", "Vaishali Nagar", "C-Scheme", "Mansarovar", "Sanganer", "Jhotwara", "Bani Park", "Amer"],
}


def get_clean_area_name(city: str, ward_raw_name: str, index: int = 0) -> str:
    """Map generic 'Ward X' labels to real landmark/area names cleanly."""
    c_key = str(city).strip().lower()
    raw = str(ward_raw_name).strip()

    if "ward" in raw.lower() and c_key in REAL_LOCALITY_MAP:
        names = REAL_LOCALITY_MAP[c_key]
        num_part = "".join(filter(str.isdigit, raw))
        if num_part:
            idx = (int(num_part) - 1) % len(names)
            return names[idx]  # Sirf real area/landmark name return karega bina (Ward X) ke
        return names[index % len(names)]
    return raw


def _clean_water_point_name(city: str, raw_name: str) -> str:
    """
    Turn 'Ward 2 RO Water Kiosk 1' into 'Dharampeth RO Water Kiosk 1' —
    swap the generic 'Ward N' prefix for a real locality name, keep the
    rest of the place description as-is.
    """
    import re
    raw = str(raw_name).strip()
    match = re.match(r"^Ward\s*(\d+)\s*(.*)$", raw, flags=re.IGNORECASE)
    if not match:
        return raw
    ward_num, remainder = match.group(1), match.group(2).strip()
    area_name = get_clean_area_name(city, f"Ward {ward_num}")
    return f"{area_name} {remainder}".strip()


def get_role_specific_vulnerability(risk_data: dict):
    loc = risk_data["location"]
    selected_role = st.session_state.get("selected_role", "Student")

    return calculate_role_vulnerability(
        elderly_pct=float(loc.get("elderly_pct", 10.0)),
        population_density=float(loc.get("population_density", 5000.0)),
        outdoor_worker_pct=float(loc.get("outdoor_worker_pct", 20.0)),
        green_cover_pct=float(loc.get("green_cover_pct", 15.0)),
        healthcare_access_score=float(loc.get("healthcare_access_score", 6.0)),
        audience=selected_role,
        pregnant_women_pct=float(loc.get("pregnant_women_pct", 4.5)),
        infants_pct=float(loc.get("infants_pct", 3.0)),
    )


# ==========================================================================
# DASHBOARD — RESTYLED KEY INDICATOR / HERO / RISK-DRIVER CARD HELPERS
# (Self-contained: does not depend on frontend/components.py so it can be
# safely restyled without touching that file. Animated where useful.)
# ==========================================================================
def render_key_indicator_cards(cards: list[dict], animate: bool = True) -> None:
    """5-across KPI card row styled with icon chip, colored value, badge pill."""
    tk = THEMES.get(get_current_theme(), THEMES["light"])
    is_dark = get_current_theme() == "dark"
    card_bg = tk["panel_bg"]
    card_border = tk["border_color"]
    title_color = tk["text_secondary"] if is_dark else "#334155"
    desc_color = tk["text_muted"]

    cards_html = ""
    scripts_html = ""
    for i, c in enumerate(cards):
        uid = f"hs_kpi_{i}_{uuid.uuid4().hex[:6]}"
        if c.get("is_number", True) and animate:
            value_inner = f'<span id="{uid}">0</span>{c.get("suffix", "")}'
            scripts_html += f"""
            (function() {{
                const el = document.getElementById("{uid}");
                if (!el) return;
                const target = {c['target']};
                const decimals = {c.get('decimals', 0)};
                const duration = 900;
                const start = performance.now();
                function step(now) {{
                    const progress = Math.min(1, (now - start) / duration);
                    const eased = 1 - Math.pow(1 - progress, 3);
                    el.textContent = (target * eased).toFixed(decimals);
                    if (progress < 1) requestAnimationFrame(step);
                }}
                requestAnimationFrame(step);
            }})();
            """
        else:
            value_inner = f'{c["display_value"]}{c.get("suffix", "")}'

        icon_bg = f'{c["icon_color"]}26' if is_dark else c["icon_bg"]
        badge_bg = f'{c["badge_color"]}26' if is_dark else c["badge_bg"]

        cards_html += f"""
        <div style="flex:1; min-width:0; min-height:200px; box-sizing:border-box; background:{card_bg}; border:1.3px solid {card_border}; border-radius:14px;
                    padding:16px 16px; box-shadow:0 3px 10px rgba(0,0,0,0.03); display:flex; flex-direction:column; gap:6px;">
            <div style="width:38px; height:38px; border-radius:50%; background:{icon_bg}; color:{c['icon_color']};
                        display:flex; align-items:center; justify-content:center; font-size:1.1rem; margin-bottom:2px;">{c['icon']}</div>
            <div style="font-size:0.68rem; font-weight:800; letter-spacing:0.04em; color:{title_color}; text-transform:uppercase;">{c['title']}</div>
            <div style="font-size:1.7rem; font-weight:900; color:{c['value_color']}; line-height:1.1; font-variant-numeric:tabular-nums;">
                {value_inner}
            </div>
            <div style="display:inline-block; align-self:flex-start; background:{badge_bg}; color:{c['badge_color']};
                        font-size:0.65rem; font-weight:800; letter-spacing:0.03em; padding:3px 10px; border-radius:999px;">{c['badge']}</div>
            <div style="font-size:0.72rem; color:{desc_color}; font-weight:500; line-height:1.35; margin-top:2px;">{c['desc']}</div>
        </div>
        """

    st.components.v1.html(
        f"""
        <style>body {{ margin:0; padding:0; }}</style>
        <div style="display:flex; gap:12px; font-family:'Inter',sans-serif; align-items:stretch;">
            {cards_html}
        </div>
        <script>{scripts_html}</script>
        """,
        height=235,
    )


_HEAT_RISK_EXPLAINERS = {
    "extreme": "Heat conditions pose a severe threat to health. Vulnerable groups face serious risk of heat-related illness. Follow emergency advisories and avoid outdoor exposure.",
    "very high": "Heat conditions are very likely to cause discomfort and heat-related illness, especially for vulnerable groups. Strong preventive action is advised.",
    "high": "Heat conditions are likely to cause discomfort and may lead to heat-related illness, especially for vulnerable groups. Take preventive actions and follow local advisories.",
    "moderate": "Heat conditions may cause mild discomfort for sensitive groups. Stay aware and take basic precautions such as hydration and shade.",
    "low": "Heat conditions are within a comfortable range for most people. Standard precautions are sufficient at this time.",
}


def render_heat_health_hero(score: float, level: dict) -> None:
    """Left 'HEAT HEALTH RISK' donut card + right explanation, styled like the reference design."""
    tk = THEMES.get(get_current_theme(), THEMES["light"])
    is_dark = get_current_theme() == "dark"
    uid = f"hs_hero_{uuid.uuid4().hex[:6]}"
    radius = 74
    circumference = 2 * 3.14159265 * radius
    pct = max(0.0, min(1.0, score / 100))
    offset_target = circumference * (1 - pct)
    color = level["color"]
    explainer = _HEAT_RISK_EXPLAINERS.get(level["key"], _HEAT_RISK_EXPLAINERS["high"])

    card_bg = tk["panel_bg"]
    card_border = tk["border_color"]
    ring_track = "rgba(255,255,255,0.10)" if is_dark else "#EEF2F1"
    num_color = tk["text_primary"]
    sub_color = tk["text_muted"]
    heading_color = tk["text_primary"]
    body_color = tk["text_secondary"] if is_dark else "#475569"
    quote_bg = "rgba(16, 185, 129, 0.12)" if is_dark else "#F0FDF4"
    quote_border = "rgba(16, 185, 129, 0.45)" if is_dark else "#86EFAC"
    quote_text = "#6EE7B7" if is_dark else "#166534"

    st.components.v1.html(
        f"""
        <div id="{uid}_wrap" style="font-family:'Inter',sans-serif; display:flex; flex-wrap:wrap; gap:22px; align-items:stretch;
                    background:{card_bg}; border:1.3px solid {card_border}; border-radius:16px; padding:22px; box-shadow:0 3px 12px rgba(0,0,0,0.03); box-sizing:border-box;">
            <div style="flex:0 0 auto; display:flex; flex-direction:column; align-items:center; justify-content:center; min-width:200px;">
                <svg width="180" height="180" viewBox="0 0 180 180">
                    <circle cx="90" cy="90" r="{radius}" stroke="{ring_track}" stroke-width="16" fill="none"/>
                    <circle id="{uid}_ring" cx="90" cy="90" r="{radius}" stroke="{color}" stroke-width="16" fill="none"
                            stroke-linecap="round" stroke-dasharray="{circumference}" stroke-dashoffset="{circumference}"
                            transform="rotate(-90 90 90)" style="transition: stroke-dashoffset 1.1s cubic-bezier(.22,.9,.33,1);"/>
                    <text id="{uid}_num" x="90" y="86" text-anchor="middle" font-size="34" font-weight="900" fill="{num_color}" font-family="Inter,sans-serif">0</text>
                    <text x="90" y="110" text-anchor="middle" font-size="13" fill="{sub_color}" font-family="Inter,sans-serif">/ 100</text>
                </svg>
                <div style="margin-top:6px; background:{color}22; color:{color}; font-weight:800; font-size:0.78rem;
                            padding:5px 14px; border-radius:999px; display:flex; align-items:center; gap:6px;">
                    ⚠️ {level['label']} RISK
                </div>
            </div>
            <div style="flex:1 1 260px; min-width:220px; display:flex; flex-direction:column; justify-content:center; gap:10px;">
                <div style="font-weight:800; font-size:0.95rem; color:{heading_color};">What does this mean?</div>
                <div style="font-size:0.84rem; color:{body_color}; line-height:1.55;">{explainer}</div>
                <div style="background:{quote_bg}; border:1px solid {quote_border}; border-radius:10px; padding:10px 14px;
                            display:flex; align-items:center; gap:8px; margin-top:4px;">
                    <span style="font-size:1rem;">🌿</span>
                    <span style="font-size:0.82rem; font-style:italic; color:{quote_text}; font-weight:600;">
                        "Awareness today, a healthier tomorrow."
                    </span>
                </div>
            </div>
        </div>
        <script>
            (function() {{
                function hsResizeFrame() {{
                    try {{
                        var wrap = document.getElementById("{uid}_wrap");
                        var h = wrap ? wrap.getBoundingClientRect().height : document.body.scrollHeight;
                        if (window.frameElement) {{
                            window.frameElement.style.height = Math.ceil(h + 4) + "px";
                        }}
                    }} catch (e) {{}}
                }}
                hsResizeFrame();
                window.addEventListener("load", hsResizeFrame);
                setTimeout(hsResizeFrame, 60);
                setTimeout(hsResizeFrame, 350);
                window.addEventListener("resize", hsResizeFrame);
            }})();
            requestAnimationFrame(function() {{
                const ring = document.getElementById("{uid}_ring");
                if (ring) ring.style.strokeDashoffset = "{offset_target}";
            }});
            (function() {{
                const el = document.getElementById("{uid}_num");
                if (!el) return;
                const target = {score};
                const duration = 1100;
                const start = performance.now();
                function step(now) {{
                    const progress = Math.min(1, (now - start) / duration);
                    const eased = 1 - Math.pow(1 - progress, 3);
                    el.textContent = Math.round(target * eased);
                    if (progress < 1) requestAnimationFrame(step);
                }}
                requestAnimationFrame(step);
            }})();
        </script>
        """,
        height=340,
    )


def render_gauge_trio_card(subtitle: str, gauges: list[dict]) -> None:
    """Wraps the Thermal Stress / Vulnerability / Health Risk gauges in one
    attractive bordered card (matching the Heat Health Risk panel style),
    with animated rings and colored pill status badges."""
    tk = THEMES.get(get_current_theme(), THEMES["light"])
    is_dark = get_current_theme() == "dark"
    card_bg = tk["panel_bg"]
    card_border = tk["border_color"]
    label_color = tk["text_secondary"] if is_dark else "#334155"
    num_color = tk["text_primary"]
    sub_color = tk["text_muted"]
    ring_track = "rgba(255,255,255,0.10)" if is_dark else "#EEF2F1"
    subtitle_color = tk["text_muted"]

    radius = 54
    circumference = 2 * 3.14159265 * radius

    blocks_html = ""
    scripts_html = ""
    for g in gauges:
        uid = f"hs_g_{uuid.uuid4().hex[:6]}"
        pct = max(0.0, min(1.0, g["value"] / 100))
        offset_target = circumference * (1 - pct)
        color = g["color"]
        badge_bg = f'{color}26' if is_dark else f'{color}22'

        blocks_html += (
            f'<div style="flex:1; min-width:0; text-align:center;">'
            f'<div style="font-size:0.72rem; font-weight:800; letter-spacing:0.06em; text-transform:uppercase; color:{label_color}; margin-bottom:10px;">{g["label"]}</div>'
            f'<svg width="140" height="140" viewBox="0 0 140 140">'
            f'<circle cx="70" cy="70" r="{radius}" stroke="{ring_track}" stroke-width="12" fill="none"/>'
            f'<circle id="{uid}_ring" cx="70" cy="70" r="{radius}" stroke="{color}" stroke-width="12" fill="none" stroke-linecap="round" '
            f'stroke-dasharray="{circumference}" stroke-dashoffset="{circumference}" transform="rotate(-90 70 70)" '
            f'style="transition: stroke-dashoffset 1s cubic-bezier(.22,.9,.33,1);"/>'
            f'<text id="{uid}_num" x="70" y="66" text-anchor="middle" font-size="26" font-weight="900" fill="{num_color}" font-family="Inter,sans-serif">0</text>'
            f'<text x="70" y="88" text-anchor="middle" font-size="11" fill="{sub_color}" font-family="Inter,sans-serif">/ 100</text>'
            f'</svg>'
            f'<div style="margin-top:4px;"><span style="display:inline-block; background:{badge_bg}; color:{color}; font-weight:800; font-size:0.72rem; letter-spacing:0.03em; padding:4px 14px; border-radius:999px;">{g["status_label"].upper()}</span></div>'
            f'</div>'
        )

        scripts_html += f"""
        requestAnimationFrame(function() {{
            const ring = document.getElementById("{uid}_ring");
            if (ring) ring.style.strokeDashoffset = "{offset_target}";
        }});
        (function() {{
            const el = document.getElementById("{uid}_num");
            if (!el) return;
            const target = {g['value']};
            const duration = 1000;
            const start = performance.now();
            function step(now) {{
                const progress = Math.min(1, (now - start) / duration);
                const eased = 1 - Math.pow(1 - progress, 3);
                el.textContent = Math.round(target * eased);
                if (progress < 1) requestAnimationFrame(step);
            }}
            requestAnimationFrame(step);
        }})();
        """

    st.components.v1.html(
        f"""
        <style>body {{ margin:0; padding:0; }}</style>
        <div style="font-family:'Inter',sans-serif; background:{card_bg}; border:1.3px solid {card_border}; border-radius:16px;
                    padding:22px; box-shadow:0 3px 12px rgba(0,0,0,0.03); box-sizing:border-box;">
            <div style="font-size:0.78rem; color:{subtitle_color}; font-weight:500; margin-bottom:18px;">{subtitle}</div>
            <div style="display:flex; gap:16px; align-items:flex-start;">{blocks_html}</div>
        </div>
        <script>{scripts_html}</script>
        """,
        height=320,
    )


def render_risk_driver_cards(temperature_c: float, humidity_pct: float, wind_ms: float, solar_wm2: float, exposure_label: str) -> None:
    """5-across 'why is this risk high' driver cards with icon + value + description."""
    tk = THEMES.get(get_current_theme(), THEMES["light"])
    is_dark = get_current_theme() == "dark"
    card_bg = tk["panel_bg"]
    card_border = tk["border_color"]
    desc_color = tk["text_muted"]
    neutral_value_color = tk["text_primary"]

    drivers = [
        {"icon": "🌡️", "icon_color": "#DC2626", "icon_bg": "#FEE2E2", "value": f"{temperature_c:.1f}°C", "value_color": "#DC2626", "desc": "High air temperature"},
        {"icon": "💧", "icon_color": "#2563EB", "icon_bg": "#DBEAFE", "value": f"{humidity_pct:.0f}%", "value_color": neutral_value_color, "desc": "Relative humidity"},
        {"icon": "🌬️", "icon_color": "#0D9488", "icon_bg": "#CCFBF1", "value": f"{wind_ms:.1f} m/s", "value_color": neutral_value_color, "desc": "Wind speed"},
        {"icon": "☀️", "icon_color": "#D97706", "icon_bg": "#FEF3C7", "value": f"{solar_wm2:.0f} W/m²", "value_color": neutral_value_color, "desc": "Solar radiation"},
        {"icon": "👥", "icon_color": "#7C3AED", "icon_bg": "#EDE9FE", "value": exposure_label.upper(), "value_color": "#7C3AED", "desc": "Outdoor-worker exposure"},
    ]
    cards_html = "".join(
        f'<div style="flex:1; min-width:0; background:{card_bg}; border:1.3px solid {card_border}; border-radius:14px; padding:16px; box-shadow:0 3px 10px rgba(0,0,0,0.03); text-align:center;">'
        f'<div style="width:36px; height:36px; border-radius:50%; background:{d["icon_color"]+"26" if is_dark else d["icon_bg"]}; color:{d["icon_color"]}; display:flex; align-items:center; justify-content:center; font-size:1rem; margin:0 auto 10px auto;">{d["icon"]}</div>'
        f'<div style="font-size:1.15rem; font-weight:900; color:{d["value_color"]};">{d["value"]}</div>'
        f'<div style="font-size:0.74rem; color:{desc_color}; font-weight:600; margin-top:2px;">{d["desc"]}</div>'
        f'</div>'
        for d in drivers
    )
    st.markdown(
        f'<div style="display:flex; gap:12px; font-family:\'Inter\',sans-serif;">{cards_html}</div>',
        unsafe_allow_html=True,
    )


def render_stay_safe_tip(message: str) -> None:
    tk = THEMES.get(get_current_theme(), THEMES["light"])
    is_dark = get_current_theme() == "dark"
    card_bg = tk["panel_bg"]
    card_border = tk["border_color"]
    heading_color = tk["text_primary"]
    body_color = tk["text_secondary"] if is_dark else "#475569"
    accent_color = tk["accent"]

    st.markdown(
        f"""
        <div style="background:{card_bg}; border:1.3px solid {card_border}; border-radius:14px; padding:14px 20px; margin-top:14px;
                    display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:10px; box-shadow:0 3px 10px rgba(0,0,0,0.02);">
            <div style="display:flex; align-items:center; gap:10px;">
                <span style="font-size:1.1rem;">💡</span>
                <span style="font-weight:800; font-size:0.8rem; color:{heading_color}; letter-spacing:0.03em;">STAY SAFE</span>
                <span style="font-size:0.82rem; color:{body_color}; font-weight:500;">{message}</span>
            </div>
            <div style="font-style:italic; font-size:0.82rem; color:{accent_color}; font-weight:700; display:flex; align-items:center; gap:6px;">
                🌿 A Healthier Tomorrow
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


# ==========================================================================
# DASHBOARD (WITH FRONTEND/ASSETS/GH.PNG HERO BANNER)
# ==========================================================================
def render_dashboard():
    tk = THEMES.get(get_current_theme(), THEMES["light"])
    is_dark = get_current_theme() == "dark"

    title_color = tk["text_primary"] if is_dark else "#0A352C"
    subtitle_color = tk["text_secondary"] if is_dark else "#3A6357"
    brand_accent = tk["accent"] if is_dark else "#0D9488"

    header_col, role_col = st.columns([3.2, 1.2])

    with header_col:
        st.markdown(
            f"""<div style="display: flex; align-items: center; gap: 14px; margin-bottom: 0.4rem;">
<div style="font-size: 2.2rem;">🌿</div>
<div>
<div style="font-size: 1.8rem; font-weight: 800; color: {title_color}; letter-spacing: -0.02em; display:flex; align-items:center; gap:8px;">
    HeatShield <span style="color: {brand_accent};">India</span>
</div>
<div style="font-size: 0.82rem; color: {subtitle_color}; font-weight: 600;">
    Localized Human Thermal Stress & Heat Health Early Warning System
</div>
</div>
</div>""",
            unsafe_allow_html=True,
        )

    with role_col:
        render_role_selector()

    status_bg = tk["panel_bg"] if is_dark else "#FFFFFF"
    status_border = tk["border_color"] if is_dark else "rgba(13, 148, 136, 0.25)"
    status_shadow = "0 2px 10px rgba(0,0,0,0.28)" if is_dark else "0 2px 10px rgba(0,0,0,0.02)"
    status_title_color = tk["text_primary"] if is_dark else "#0A352C"
    status_body_color = tk["text_secondary"] if is_dark else "#3A6357"

    st.markdown(
        f"""<div style="background: {status_bg}; border: 1.5px solid {status_border}; border-radius: 12px; padding: 12px 18px; margin-bottom: 12px; display: flex; align-items: center; justify-content: space-between; box-shadow: {status_shadow};">
<div style="display: flex; align-items: center; gap: 10px;">
<span style="width: 10px; height: 10px; border-radius: 50%; background: #10B981; display: inline-block;"></span>
<span style="font-weight: 800; font-size: 0.82rem; color: {status_title_color}; letter-spacing: 0.04em;">LIVE FORECAST STATUS</span>
<span style="font-size: 0.84rem; color: {status_body_color}; margin-left: 8px;">Weather and heat-health data are being processed in real-time.</span>
</div>
<div style="display: flex; align-items: center; gap: 8px; font-size: 0.82rem; color: {status_body_color}; font-weight: 600;">
<span>📅</span> Updated: {format_ist_timestamp()} | {st.session_state.get('selected_city', 'Nagpur')} — {get_clean_area_name(st.session_state.get('selected_city', 'Nagpur'), st.session_state.get('selected_ward') or 'Ward 1')}
</div>
</div>""",
        unsafe_allow_html=True,
    )

    if is_dark:
        demo_bg = "rgba(37, 99, 235, 0.12)"
        demo_border = f"1.5px solid {tk['border_color']}"
        demo_border_left = "4px solid #3B82F6"
        demo_heading_color = "#93C5FD"
        demo_body_color = "#60A5FA"
    else:
        demo_bg = "#EFF6FF"
        demo_border = "none"
        demo_border_left = "4px solid #2563EB"
        demo_heading_color = "#1E40AF"
        demo_body_color = "#3B82F6"

    st.markdown(
        f"""<div style="background: {demo_bg}; border: {demo_border}; border-left: {demo_border_left}; border-radius: 8px; padding: 12px 18px; margin-bottom: 1.4rem; display: flex; align-items: flex-start; gap: 12px;">
<div style="background: #2563EB; color: #FFFFFF; border-radius: 50%; width: 20px; height: 20px; display: flex; align-items: center; justify-content: center; font-size: 0.75rem; font-weight: 800; flex-shrink: 0; margin-top: 1px;">i</div>
<div style="font-size: 0.82rem; color: {demo_body_color}; line-height: 1.45;">
<b style="color: {demo_heading_color};">DEMO MODE — Using simulated forecast and vulnerability data for demonstration purposes.</b><br/>
<span style="color: {demo_body_color};">Live weather integration is optional and falls back automatically to this dataset if unavailable.</span>
</div>
</div>""",
        unsafe_allow_html=True,
    )

    demo_mode_badge()

    if is_data_saver:
        st.info("⚡ **Data Saver Active:** High-load animations and charts are paused for smooth performance.")

    if boost > 0:
        pulsing_alert_banner("EXTREME HEAT SCENARIO ACTIVE — risk values intensified across all locations", "#E74C3C", "🔥")
        st.write("")

    # Hero banner: use the dark-mode artwork when the dark theme is active,
    # otherwise fall back to the light-mode artwork. Falls back to gh.png if
    # ghdark.png hasn't been added yet, so the dashboard never breaks.
    import os as _os
    _hero_dark_path = "frontend/assets/ghdark.png"
    _hero_light_path = "frontend/assets/gh.png"
    _hero_path = _hero_dark_path if (get_current_theme() == "dark" and _os.path.exists(_hero_dark_path)) else _hero_light_path
    st.image(_hero_path, use_container_width=True)

    st.write("")
    if not is_data_saver:
        animated_pipeline(active_stage=5)
    st.markdown("<hr class='hs-divider'/>", unsafe_allow_html=True)

    kpis = get_dashboard_kpis(scenario_boost=boost)
    risk_data = get_current_risk(location_id, scenario_boost=boost)
    selected_role = st.session_state.get("selected_role", "Student")
    role_vulnerability = get_role_specific_vulnerability(risk_data)

    dynamic_health_risk = round(
        0.65 * risk_data["thermal"].htss + 0.35 * role_vulnerability.score, 1
    )
    lvl_label, lvl_color = vulnerability_label_and_color(dynamic_health_risk)

    icon_map = {
        "EXTREME": "🚨",
        "VERY HIGH": "🔥",
        "HIGH": "⚠️",
        "MODERATE": "⚡",
        "LOW": "✅",
    }

    level = {
        "label": lvl_label,
        "color": lvl_color,
        "key": lvl_label.lower(),
        "icon": icon_map.get(lvl_label, "⚠️"),
    }

    section_title("KEY INDICATORS")
    peak = risk_data["peak_window"]
    peak_label = f"{peak['start']}–{peak['end']}" if peak.get("start") else "N/A"
    pop_millions = kpis["vulnerable_population"] / 1_000_000

    if is_data_saver:
        c1, c2, c3, c4, c5 = st.columns(5)
        with c1:
            kpi_card_static(t("current_heat_risk"), f"{dynamic_health_risk:.0f}", sub=level["label"], color=level["color"])
        with c2:
            kpi_card_static(t("thermal_stress"), f"{risk_data['thermal'].htss:.0f}", sub=risk_data["thermal"].category["label"], color="#FF6B4A")
        with c3:
            kpi_card_static(t("high_risk_areas"), str(kpis["high_risk_areas"]), sub=t("districts"), color="#E74C3C")
        with c4:
            kpi_card_static(t("peak_risk"), peak_label, sub=t("today"), color="#2563EB")
        with c5:
            kpi_card_static(t("vulnerable_population"), f"{pop_millions:.2f}M", sub=t("people"), color="#0D9488")
    else:
        render_key_indicator_cards([
            {
                "icon": "🌡️", "icon_bg": "#FFF1E8", "icon_color": "#F97316",
                "title": t("current_heat_risk"), "is_number": True, "target": dynamic_health_risk, "decimals": 0,
                "suffix": " /100", "value_color": level["color"], "badge": level["label"], "badge_bg": f"{level['color']}22",
                "badge_color": level["color"], "desc": "Elevated risk of heat-related health impacts.",
            },
            {
                "icon": "🔥", "icon_bg": "#FEE2E2", "icon_color": "#DC2626",
                "title": t("thermal_stress"), "is_number": True, "target": risk_data["thermal"].htss, "decimals": 0,
                "suffix": " /100", "value_color": "#DC2626", "badge": risk_data["thermal"].category["label"], "badge_bg": "#FEE2E2",
                "badge_color": "#DC2626", "desc": "Feels significantly hotter than actual temperature.",
            },
            {
                "icon": "📍", "icon_bg": "#F3E8FF", "icon_color": "#7C3AED",
                "title": t("high_risk_areas"), "is_number": True, "target": kpis["high_risk_areas"], "decimals": 0,
                "suffix": "", "value_color": "#7C3AED", "badge": t("districts").upper(), "badge_bg": "#F3E8FF",
                "badge_color": "#7C3AED", "desc": "Areas with elevated heat-health risk.",
            },
            {
                "icon": "⏰", "icon_bg": "#DBEAFE", "icon_color": "#2563EB",
                "title": t("peak_risk"), "is_number": False, "display_value": peak_label,
                "suffix": "", "value_color": "#0F172A", "badge": t("today").upper(), "badge_bg": "#DBEAFE",
                "badge_color": "#2563EB", "desc": "Highest heat-health risk expected during this period.",
            },
            {
                "icon": "👥", "icon_bg": "#CCFBF1", "icon_color": "#0D9488",
                "title": t("vulnerable_population"), "is_number": True, "target": round(pop_millions, 2), "decimals": 2,
                "suffix": "M", "value_color": "#0D9488", "badge": t("people").upper(), "badge_bg": "#CCFBF1",
                "badge_color": "#0D9488", "desc": "Population at higher risk due to age, occupation or health conditions.",
            },
        ])

    st.write("")
    col_left, col_right = st.columns([1.1, 1.4])
    with col_left:
        if is_data_saver:
            hero_risk_panel(dynamic_health_risk, level)
        else:
            section_title("HEAT HEALTH RISK")
            render_heat_health_hero(dynamic_health_risk, level)
    with col_right:
        section_title("THERMAL STRESS / VULNERABILITY / HEALTH RISK")
        if is_data_saver:
            g1, g2, g3 = st.columns(3)
            with g1:
                kpi_card_static("THERMAL STRESS", f"{risk_data['thermal'].htss:.0f}", sub=risk_data["thermal"].category["label"], color="#FF6B4A")
            with g2:
                kpi_card_static(f"VULNERABILITY — {selected_role.upper()}", f"{role_vulnerability.score:.0f}", sub=role_vulnerability.label, color=role_vulnerability.color)
            with g3:
                kpi_card_static("HEALTH RISK", f"{dynamic_health_risk:.0f}", sub=level["label"], color=level["color"])
        else:
            render_gauge_trio_card(
                f"Component-wise risk assessment ({selected_role})",
                [
                    {"label": "THERMAL STRESS", "value": risk_data["thermal"].htss, "status_label": risk_data["thermal"].category["label"], "color": "#FF6B4A"},
                    {"label": f"VULNERABILITY — {selected_role.upper()}", "value": role_vulnerability.score, "status_label": role_vulnerability.label, "color": role_vulnerability.color},
                    {"label": "HEALTH RISK", "value": dynamic_health_risk, "status_label": level["label"], "color": level["color"]},
                ],
            )
        st.caption(
            f"Displaying assessment tailored for: **{selected_role}**. "
            "Vulnerability dynamically reflects personal sensitivity and occupational exposure."
        )

    st.markdown("<hr class='hs-divider'/>", unsafe_allow_html=True)
    section_title(t("why_is_this_risk_high"))
    weather_temp = risk_data["weather"].temperature_c
    exposure_label = "HIGH" if risk_data["location"]["outdoor_worker_pct"] > 30 else "MODERATE"

    if is_data_saver:
        risk_driver_explainer(
            weather_temp,
            risk_data["weather"].humidity_pct,
            risk_data["weather"].wind_ms,
            risk_data["weather"].solar_radiation_wm2,
            exposure_label,
        )
    else:
        render_risk_driver_cards(
            weather_temp,
            risk_data["weather"].humidity_pct,
            risk_data["weather"].wind_ms,
            risk_data["weather"].solar_radiation_wm2,
            exposure_label,
        )

    render_stay_safe_tip("Stay hydrated, avoid direct sun exposure, wear light clothing, and follow local heat advisories.")
    htss_disclaimer()


# ==========================================================================
# RISK MAP
# ==========================================================================
def render_risk_map():
    page_header(t("risk_map"), "Interactive ward-level heat-health risk map")
    demo_mode_badge()

    map_df = get_map_risk(scenario_boost=boost)
    curr_city = st.session_state.get("selected_city", "Delhi")
    city_key = str(curr_city).strip().lower()

    map_df_clean = map_df.copy()
    if "ward_name" in map_df_clean.columns and "city" in map_df_clean.columns:
        map_df_clean["ward_name"] = [
            get_clean_area_name(r["city"], r["ward_name"], idx)
            for idx, r in map_df_clean.iterrows()
        ]

    hosp_records = DEFAULT_CITY_HOSPITALS.get(city_key, DEFAULT_CITY_HOSPITALS.get("delhi", []))
    hospitals_df = pd.DataFrame(hosp_records)

    cooling_records = DEFAULT_COOLING_CENTRES.get(city_key, DEFAULT_COOLING_CENTRES.get("delhi", []))
    cooling_df = pd.DataFrame(cooling_records)

    water_records = DEFAULT_WATER_POINTS.get(city_key, DEFAULT_WATER_POINTS.get("delhi", []))
    water_df = pd.DataFrame(water_records)

    layer_cols = st.columns(3)
    with layer_cols[0]:
        show_hospitals = st.checkbox("🏥 Hospitals", value=True, key="chk_risk_hospitals")
    with layer_cols[1]:
        show_cooling = st.checkbox("❄️ Cooling Centres", value=True, key="chk_risk_cooling")
    with layer_cols[2]:
        show_water = st.checkbox("💧 Water Points", value=False, key="chk_risk_water")

    if is_data_saver:
        st.info("⚡ **Data Saver Active:** Interactive GIS tiles replaced with lightweight area risk directory.")
        ward_summary = map_df_clean[map_df_clean["city"] == curr_city][["ward_name", "health_risk", "risk_level", "population"]].rename(
            columns={"ward_name": "Locality / Area", "health_risk": "Risk Score", "risk_level": "Level", "population": "Population"}
        )
        render_styled_table(ward_summary, max_rows=15)
    else:
        fmap = build_risk_map(
            map_df_clean,
            center_city=curr_city,
            show_hospitals=show_hospitals,
            hospitals_df=hospitals_df if show_hospitals else None,
            show_cooling=show_cooling,
            cooling_df=cooling_df if show_cooling else None,
            show_water=show_water,
            water_df=water_df if show_water else None,
        )
        st_folium(fmap, use_container_width=True, height=560, key="risk_map_widget")

    if show_hospitals:
        render_hospitals_table_card(curr_city, hospitals_df)

    if show_cooling:
        render_cooling_centres_table_card(curr_city, cooling_df)

    if show_water:
        render_water_points_table_card(curr_city, water_df)

    st.markdown("<hr class='hs-divider'/>", unsafe_allow_html=True)
    section_title("RISK LEGEND")
    legend_cols = st.columns(len(RISK_LEVELS))
    active_theme = THEMES.get(get_current_theme(), THEMES["dark"])
    muted_color = active_theme["text_muted"]

    for col, lvl in zip(legend_cols, RISK_LEVELS):
        with col:
            st.markdown(
                f"""<div class="hs-card" style="text-align:center; border-top:4px solid {lvl['color']};">
                <div style="font-size:1.3rem;">{lvl['icon']}</div>
                <div style="font-weight:700; margin-top:4px;">{lvl['label']}</div>
                <div style="font-size:0.75rem; color:{muted_color}; margin-top:4px;">{lvl['min']}–{lvl['max']}</div>
                </div>""",
                unsafe_allow_html=True,
            )


# ==========================================================================
# LOCATION ANALYSIS
# ==========================================================================
def render_location_analysis():
    bundle = compute_location_bundle(location_id, scenario_boost=boost)
    loc = bundle["location"]
    page_header(f"{loc['city'].upper()}", f"{loc['state']} — {get_clean_area_name(loc['city'], loc['ward_name'])}")
    demo_mode_badge()

    selected_role = st.session_state.get("selected_role", "Student")
    role_vulnerability = get_role_specific_vulnerability(bundle)

    dynamic_health_risk = round(
        0.65 * bundle["thermal"].htss + 0.35 * role_vulnerability.score, 1
    )
    lvl_label, lvl_color = vulnerability_label_and_color(dynamic_health_risk)

    c1, c2, c3 = st.columns(3)
    with c1:
        animated_gauge("CURRENT RISK", dynamic_health_risk, status_label=lvl_label, color=lvl_color)
    with c2:
        animated_gauge("THERMAL STRESS", bundle["thermal"].htss, status_label=bundle["thermal"].category["label"], color="#FF6B4A")
    with c3:
        animated_gauge(
            f"VULNERABILITY — {selected_role.upper()}",
            role_vulnerability.score,
            status_label=role_vulnerability.label,
            color=role_vulnerability.color,
        )

    st.markdown("<hr class='hs-divider'/>", unsafe_allow_html=True)
    section_title(t("why_is_this_risk_high"))
    risk_driver_explainer(
        bundle["weather"].temperature_c, bundle["weather"].humidity_pct,
        bundle["weather"].wind_ms, bundle["weather"].solar_radiation_wm2,
        "HIGH" if loc["outdoor_worker_pct"] > 30 else "MODERATE",
    )
    st.write("")

    col_a, col_b = st.columns(2)
    with col_a:
        section_title("THERMAL STRESS BREAKDOWN")
        if is_data_saver:
            breakdown_df = pd.DataFrame(list(bundle["thermal"].components.items()), columns=["Component", "Weight"])
            render_styled_table(breakdown_df)
        else:
            st.plotly_chart(risk_component_breakdown_chart(bundle["thermal"].components), use_container_width=True)
    with col_b:
        section_title("VULNERABILITY CONTRIBUTORS")
        vuln = role_vulnerability
        for k, v in vuln.contributors.items():
            st.markdown(f"**{k.replace('_', ' ').title()}**")
            st.progress(max(0.0, min(1.0, v / 30.0)))
    htss_disclaimer()


# ==========================================================================
# COMPLETE render_forecast() FUNCTION (WITH EXACT REFERENCE BUTTON STYLING)
# ==========================================================================
def render_forecast():
    # ----------------------------------------------------------------------
    # 1. TOP HEADER & ROLE SELECTOR ROW
    # ----------------------------------------------------------------------
    header_col, role_col = st.columns([3.2, 1.2])

    with header_col:
        st.markdown(
            """<div style="display: flex; align-items: center; gap: 14px; margin-bottom: 0.4rem;">
<div style="font-size: 2.2rem;">🌿</div>
<div>
<div style="font-size: 1.8rem; font-weight: 800; color: #0A352C; letter-spacing: -0.02em; display:flex; align-items:center; gap:8px;">
    HeatShield <span style="color: #0D9488;">India</span>
</div>
<div style="font-size: 0.82rem; color: #3A6357; font-weight: 600;">
    Localized heat-health forecast & thermal risk trajectory
</div>
</div>
</div>""",
            unsafe_allow_html=True,
        )

    with role_col:
        render_role_selector()

    # ----------------------------------------------------------------------
    # 2. SYNCHRONIZED LOCATION HEADER & STATUS BAR
    # ----------------------------------------------------------------------
    curr_city = st.session_state.get("selected_city", "Delhi")
    ward = st.session_state.get("selected_ward", "Ward 1")
    clean_locality = get_clean_area_name(curr_city, ward or "Ward 1")
    location_str = f"{curr_city.title()} — {clean_locality}"
    active_loc_id = get_selected_location_id(locations_df)

    st.markdown(
        f"""<div style="background: #FFFFFF; border: 1.5px solid rgba(13, 148, 136, 0.25); border-radius: 12px; padding: 12px 18px; margin-bottom: 1.4rem; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 2px 10px rgba(0,0,0,0.02);">
<div style="display: flex; align-items: center; gap: 10px;">
<span style="width: 10px; height: 10px; border-radius: 50%; background: #10B981; display: inline-block;"></span>
<span style="font-weight: 800; font-size: 0.82rem; color: #0A352C; letter-spacing: 0.04em;">{location_str}</span>
<span style="font-size: 0.84rem; color: #3A6357; margin-left: 8px;">Forecast synchronized with selected sidebar location</span>
</div>
<div style="display: flex; align-items: center; gap: 8px; font-size: 0.82rem; color: #3A6357; font-weight: 600;">
<span>📅</span> Updated: {format_ist_timestamp()}
</div>
</div>""",
        unsafe_allow_html=True,
    )

    demo_mode_badge()

    horizon_map = {"24 HOURS": 24, "48 HOURS": 48, "3 DAYS": 72, "5 DAYS": 120}

    if "forecast_range" not in st.session_state or st.session_state["forecast_range"] not in horizon_map:
        st.session_state["forecast_range"] = "5 DAYS"

    # ----------------------------------------------------------------------
    # 3. FORECAST RANGE BOX & FORECAST.PNG BANNER SIDE-BY-SIDE
    # ----------------------------------------------------------------------
    top_c1, top_c2 = st.columns([1.5, 2.2], vertical_alignment="center")

    with top_c1:
        st.markdown(
            """
            <div style="background: #FFFFFF; border: 1.5px solid #CBD5E1; border-radius: 14px; padding: 18px 20px; box-shadow: 0 4px 12px rgba(0,0,0,0.03); margin-bottom: 12px;">
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 4px;">
                    <span style="font-size: 1.4rem; color: #065F46;">📅</span>
                    <span style="font-weight: 800; font-size: 1.05rem; color: #0A352C;">Forecast Range</span>
                </div>
                <div style="font-size: 0.8rem; color: #64748B;">Select the time range to view forecast</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        # Soft neumorphic pill styling for the range buttons (scoped to this
        # container only, via the container's key -> .st-key-forecast_range_btns)
        st.markdown(
            """
            <style>
            .st-key-forecast_range_btns div[data-testid="stButton"] > button {
                background: #EEF2F1 !important;
                border: none !important;
                border-radius: 999px !important;
                padding: 0.55rem 0.75rem !important;
                font-weight: 700 !important;
                font-size: 0.82rem !important;
                letter-spacing: 0.01em;
                color: #64748B !important;
                box-shadow: 4px 4px 9px rgba(163, 177, 198, 0.45),
                            -4px -4px 9px rgba(255, 255, 255, 0.85) !important;
                transition: all 0.15s ease-in-out;
            }
            .st-key-forecast_range_btns div[data-testid="stButton"] > button:hover {
                color: #0D9488 !important;
                box-shadow: 2px 2px 5px rgba(163, 177, 198, 0.45),
                            -2px -2px 5px rgba(255, 255, 255, 0.85) !important;
            }
            .st-key-forecast_range_btns div[data-testid="stButton"]:nth-of-type(2) > button {
                color: #0D9488 !important;
            }
            .st-key-forecast_range_btns div[data-testid="stButton"]:nth-of-type(3) > button,
            .st-key-forecast_range_btns div[data-testid="stButton"]:nth-of-type(4) > button {
                color: #1E3A5F !important;
            }
            .st-key-forecast_range_btns div[data-testid="stButton"] > button[kind="primary"] {
                background: #EEF2F1 !important;
                color: #1E3A5F !important;
                box-shadow: inset 2px 2px 5px rgba(163, 177, 198, 0.4),
                            inset -2px -2px 5px rgba(255, 255, 255, 0.8) !important;
            }
            </style>
            """,
            unsafe_allow_html=True,
        )

        with st.container(key="forecast_range_btns"):
            rc_cols = st.columns(4)
            ranges = list(horizon_map.keys())
            for i, (col, r_key) in enumerate(zip(rc_cols, ranges)):
                with col:
                    is_selected = st.session_state["forecast_range"] == r_key
                    btn_type = "primary" if is_selected else "secondary"
                    btn_label = f"📅  {r_key}" if is_selected else r_key
                    if st.button(btn_label, key=f"f_range_btn_{i}", use_container_width=True, type=btn_type):
                        st.session_state["forecast_range"] = r_key
                        st.rerun()

    with top_c2:
        import os
        banner_paths = [
            "frontend/assets/forecast.png", "assets/forecast.png",
            "frontend/assets/forecast.jpg", "assets/forecast.jpg"
        ]
        loaded = False
        for path in banner_paths:
            if os.path.exists(path):
                st.image(path, use_container_width=True)
                loaded = True
                break
        if not loaded:
            st.markdown(
                """
                <div style="background: linear-gradient(135deg, #F0FDF4 0%, #DCFCE7 100%); border: 1.5px solid #86EFAC; border-radius: 14px; padding: 24px; text-align: right;">
                    <div style="font-size: 1.1rem; font-weight: 900; color: #065F46;">CLEANER · COOLER · HEALTHIER · INDIA</div>
                    <div style="font-size: 0.78rem; color: #047857; margin-top: 4px;">Localized Heat-Health Early Warning System</div>
                </div>
                """,
                unsafe_allow_html=True,
            )

    st.markdown("<hr class='hs-divider' style='margin: 1.8rem 0;'/>", unsafe_allow_html=True)

    hours = horizon_map[st.session_state["forecast_range"]]

    df = get_forecast(active_loc_id, hours=hours)
    if df.empty and curr_city:
        df = get_forecast(curr_city.lower(), hours=hours)

    peak = get_peak_risk_summary(active_loc_id, hours=hours)

    # ----------------------------------------------------------------------
    # 4. 5 DAYS WEATHER FORECAST CARDS
    # ----------------------------------------------------------------------
    num_days = max(1, hours // 24)
    st.markdown(
        f"""
        <div style="background: #FFFFFF; border: 1.5px solid #E2E8F0; border-radius: 16px; padding: 20px; box-shadow: 0 4px 16px rgba(0,0,0,0.02); margin-bottom: 1.5rem;">
            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 4px;">
                <span style="font-size: 1.4rem;">📊</span>
                <span style="font-size: 1.25rem; font-weight: 800; color: #0A352C;">{num_days} DAYS WEATHER FORECAST</span>
            </div>
            <div style="font-size: 0.82rem; color: #3A6357; font-weight: 600; margin-bottom: 16px;">Temperature, humidity and heat-health risk for {location_str}</div>
        """,
        unsafe_allow_html=True,
    )

    risk_color_by_label = {lvl["label"]: lvl["color"] for lvl in RISK_LEVELS}
    n_cards = min(num_days, 5)
    is_live_top = (not df.empty) and (df["data_source"].iloc[0] == "live")

    if df.empty:
        st.info("No forecast data available for this location yet.")
    else:
        card_cols = st.columns(n_cards)
        for i in range(n_cards):
            day_df = df[df["day_index"] == i]
            if day_df.empty:
                continue

            if is_live_top and "timestamp" in day_df.columns:
                dt_future = pd.Timestamp(day_df["timestamp"].iloc[0])
            else:
                dt_future = pd.Timestamp.now() + pd.Timedelta(days=i)
            day_label = "TODAY" if i == 0 else ("TOMORROW" if i == 1 else dt_future.strftime("%A").upper())

            t_max = round(day_df["temperature_c"].max(), 1)
            t_min = round(day_df["temperature_c"].min(), 1)
            hum = round(day_df["humidity_pct"].mean())

            hot_row = day_df.loc[day_df["temperature_c"].idxmax()]
            feels = heat_index_c(hot_row["temperature_c"], hot_row["humidity_pct"], hot_row["wind_ms"])

            if is_live_top and "weather_code" in day_df.columns and day_df["weather_code"].notna().any():
                from backend.weather_service import weather_code_to_condition
                # Use the most frequent daytime weather code as the day's headline condition.
                daytime_codes = day_df[(day_df["hour_of_day"] >= 8) & (day_df["hour_of_day"] <= 17)]["weather_code"]
                codes_to_use = daytime_codes if not daytime_codes.empty else day_df["weather_code"]
                mode_code = codes_to_use.mode().iloc[0]
                condition, icon = weather_code_to_condition(mode_code)
            else:
                daytime_df = day_df[(day_df["hour_of_day"] >= 8) & (day_df["hour_of_day"] <= 17)]
                avg_solar = daytime_df["solar_radiation_wm2"].mean() if not daytime_df.empty else 0.0
                condition, icon = sky_condition_from_solar(avg_solar)

            if is_live_top and "rainfall_mm" in day_df.columns and day_df["rainfall_mm"].notna().any():
                rain_total = round(day_df["rainfall_mm"].sum(), 1)
                rain_chance = int(day_df["precip_probability"].max()) if "precip_probability" in day_df.columns and day_df["precip_probability"].notna().any() else None
                rain_line = f'🌧️ <b style="color:#0F172A;">{rain_total} mm</b>' + (f' · {rain_chance}% chance' if rain_chance is not None else "") + "<br/>"
            else:
                rain_line = ""

            peak_row = day_df.loc[day_df["health_risk"].idxmax()]
            r_val = int(round(peak_row["health_risk"]))
            lvl = peak_row["risk_level"]
            col_hex = risk_color_by_label.get(lvl, "#DC2626")
            heat_label = heat_feel_label(t_max)

            with card_cols[i]:
                st.markdown(
                    f"""
                    <div style="background: #FFFFFF; border: 1.5px solid #CBD5E1; border-radius: 14px; padding: 16px 14px; box-shadow: 0 4px 12px rgba(0,0,0,0.03); height: 100%;">
                        <div style="font-weight: 800; font-size: 0.85rem; color: #0F172A;">{day_label}</div>
                        <div style="font-size: 0.72rem; color: #64748B; font-weight: 600; margin-bottom: 6px;">{dt_future.strftime('%d %b %Y')}</div>
                        <div style="text-align: center; margin: 10px 0; font-size: 2.2rem;">{icon}</div>
                        <div style="font-size: 1.25rem; font-weight: 900; color: #0F172A; text-align: center;">{t_max}°C <span style="font-size: 0.72rem; color: #64748B; font-weight: 600;">/ {t_min}°C</span></div>
                        <div style="font-size: 0.75rem; font-weight: 700; color: #D97706; text-align: center; margin-top: 2px;">{condition}</div>
                        <div style="font-size: 0.72rem; color: #64748B; font-weight: 600; text-align: center;">{heat_label}</div>
                        <div style="font-size: 0.74rem; color: #334155; margin-top: 10px; border-top: 1px solid #F1F5F9; padding-top: 8px; line-height: 1.4;">
                            {rain_line}💧 <b style="color:#0F172A;">{hum}%</b> Humidity<br/>
                            🌡️ Feels like <b style="color:#0F172A;">{feels}°C</b>
                        </div>
                        <div style="background: #FFF5F5; border: 1px solid #FCA5A5; border-radius: 8px; padding: 6px 8px; margin-top: 10px; text-align: center;">
                            <div style="font-size: 0.72rem; font-weight: 800; color: #DC2626;">⚠️ Peak risk {r_val}/100</div>
                            <div style="background: {col_hex}; color: #FFF; font-size: 0.65rem; font-weight: 900; padding: 2px 8px; border-radius: 4px; display: inline-block; margin-top: 4px;">{lvl}</div>
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )

    st.markdown("</div>", unsafe_allow_html=True)
    st.markdown("<hr class='hs-divider' style='margin: 1.8rem 0;'/>", unsafe_allow_html=True)

    # ----------------------------------------------------------------------
    # 5. HOURLY MATRIX WITH PARAMETER FILTERS (LIGHT / FLAT STYLE, LOCATION-AWARE)
    # ----------------------------------------------------------------------
    st.markdown(
        f"""
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 2px;">
            <span style="font-size: 1.1rem;">⏱️</span>
            <span style="font-size: 1.05rem; font-weight: 800; color: #0A352C;">HOURLY FORECAST MATRIX</span>
        </div>
        <div style="font-size: 0.78rem; color: #64748B; font-weight: 500; margin-bottom: 12px;">
            Detailed hour-wise weather conditions and heat-health risk for {location_str}
        </div>
        """,
        unsafe_allow_html=True,
    )

    if "active_param" not in st.session_state:
        st.session_state["active_param"] = "All Parameters"

    # Plain, flat pill buttons (scoped to this container only)
    st.markdown(
        """
        <style>
        .st-key-hourly_matrix_param_btns div[data-testid="stButton"] > button {
            background: #FFFFFF !important;
            border: 1.3px solid #E2E8F0 !important;
            border-radius: 999px !important;
            color: #475569 !important;
            font-weight: 600 !important;
            font-size: 0.82rem !important;
            box-shadow: none !important;
        }
        .st-key-hourly_matrix_param_btns div[data-testid="stButton"] > button:hover {
            border-color: #0D9488 !important;
            color: #0D9488 !important;
        }
        .st-key-hourly_matrix_param_btns div[data-testid="stButton"] > button[kind="primary"] {
            background: #FFFFFF !important;
            border: 1.3px solid #0D9488 !important;
            color: #0D9488 !important;
            font-weight: 800 !important;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )

    with st.container(key="hourly_matrix_param_btns"):
        p_col1, p_col2, p_col3, p_col4, p_col5, p_col6 = st.columns(6)
        with p_col1:
            if st.button("All Parameters", key="btn_p_all", use_container_width=True, type="primary" if st.session_state["active_param"]=="All Parameters" else "secondary"):
                st.session_state["active_param"] = "All Parameters"
                st.rerun()
        with p_col2:
            if st.button("Temperature", key="btn_p_temp", use_container_width=True, type="primary" if st.session_state["active_param"]=="Temperature" else "secondary"):
                st.session_state["active_param"] = "Temperature"
                st.rerun()
        with p_col3:
            if st.button("Humidity", key="btn_p_hum", use_container_width=True, type="primary" if st.session_state["active_param"]=="Humidity" else "secondary"):
                st.session_state["active_param"] = "Humidity"
                st.rerun()
        with p_col4:
            if st.button("Rainfall", key="btn_p_rain", use_container_width=True, type="primary" if st.session_state["active_param"]=="Rainfall" else "secondary"):
                st.session_state["active_param"] = "Rainfall"
                st.rerun()
        with p_col5:
            if st.button("Thermal Stress", key="btn_p_therm", use_container_width=True, type="primary" if st.session_state["active_param"]=="Thermal Stress" else "secondary"):
                st.session_state["active_param"] = "Thermal Stress"
                st.rerun()
        with p_col6:
            if st.button("Heat Risk", key="btn_p_risk", use_container_width=True, type="primary" if st.session_state["active_param"]=="Heat Risk" else "secondary"):
                st.session_state["active_param"] = "Heat Risk"
                st.rerun()

    hours_list = ["6 AM", "7 AM", "8 AM", "9 AM", "10 AM", "11 AM", "12 PM", "1 PM", "2 PM", "3 PM", "4 PM", "5 PM", "6 PM", "7 PM", "8 PM", "9 PM", "10 PM", "11 PM"]

    # Pull TODAY's real hourly data (already computed with genuine HTSS /
    # health-risk from the actual forecast dataset) instead of a fabricated
    # per-city formula.
    day0_df = df[df["day_index"] == 0].set_index("hour_of_day") if not df.empty else pd.DataFrame()
    target_hours = list(range(6, 24))  # 6 AM .. 11 PM, matches hours_list
    is_live = (not df.empty) and (df["data_source"].iloc[0] == "live")

    def _sky_icon(row) -> str:
        # Live data has a real Open-Meteo weather code -> use it directly.
        if is_live and row.get("weather_code") is not None:
            from backend.weather_service import weather_code_to_condition
            _, icon = weather_code_to_condition(row["weather_code"])
            return icon
        if row["solar_radiation_wm2"] <= 5:
            return "🌙"
        _, icon = sky_condition_from_solar(row["solar_radiation_wm2"])
        return icon

    if day0_df.empty or not all(h in day0_df.index for h in target_hours):
        w_icons = ["—"] * 18
        temps = [None] * 18
        hums = [None] * 18
        stress = [None] * 18
        risks = [None] * 18
        rains = [None] * 18
        rain_probs = [None] * 18
    else:
        rows = [day0_df.loc[h] for h in target_hours]
        w_icons = [_sky_icon(r) for r in rows]
        temps = [round(r["temperature_c"], 1) for r in rows]
        hums = [int(round(r["humidity_pct"])) for r in rows]
        stress = [round(r["htss"], 1) for r in rows]
        risks = [int(round(r["health_risk"])) for r in rows]
        if is_live:
            rains = [None if pd.isna(r.get("rainfall_mm")) else round(float(r["rainfall_mm"]), 1) for r in rows]
            rain_probs = [None if pd.isna(r.get("precip_probability")) else int(r["precip_probability"]) for r in rows]
        else:
            rains = [None] * 18
            rain_probs = [None] * 18

    def get_risk_badge(r):
        if r is None: return "—", "#94A3B8"
        if r >= 80: return "VERY HIGH", "#DC2626"
        elif r >= 60: return "HIGH", "#F97316"
        elif r >= 35: return "MODERATE", "#EAB308"
        else: return "LOW", "#10B981"

    table_headers = "".join([f"<th style='padding:8px 8px; text-align:center; font-size:0.74rem; font-weight:700; background:#FAFBFC; border-bottom:1px solid #EDF1F5; color:#64748B;'>{h}</th>" for h in hours_list])

    icon_cells = "".join([f"<td style='padding:8px 8px; text-align:center; font-size:1.05rem; border-bottom:1px solid #F1F5F9;'>{ic}</td>" for ic in w_icons])
    t_cells = "".join([f"<td style='padding:8px 8px; text-align:center; font-size:0.8rem; border-bottom:1px solid #F1F5F9; color:#0F172A;'>{'—' if t is None else t}</td>" for t in temps])
    h_cells = "".join([f"<td style='padding:8px 8px; text-align:center; font-size:0.8rem; border-bottom:1px solid #F1F5F9; color:#0F172A;'>{'—' if h is None else h}</td>" for h in hums])
    s_cells = "".join([f"<td style='padding:8px 8px; text-align:center; font-size:0.8rem; border-bottom:1px solid #F1F5F9; color:#0F172A;'>{'—' if s is None else s}</td>" for s in stress])
    k_cells = "".join([f"<td style='padding:8px 8px; text-align:center; font-size:0.8rem; font-weight:800; border-bottom:1px solid #F1F5F9; color:#0F172A;'>{'—' if k is None else k}</td>" for k in risks])

    # When running on the demo dataset, precipitation isn't modeled at all,
    # so rainfall is shown as N/A rather than an invented value. When live
    # Open-Meteo data is available, show real mm + chance-of-rain instead.
    def _rain_cell(mm, prob):
        if mm is None or prob is None:
            return (
                "<td style='padding:8px 6px; text-align:center; border-bottom:1px solid #F1F5F9;'>"
                "<span style='display:inline-flex; align-items:center; gap:4px; background:#F1F5F9; color:#94A3B8; "
                "font-size:0.66rem; font-weight:800; padding:4px 9px; border-radius:999px; white-space:nowrap;'>"
                "— N/A</span></td>"
            )
        bg, fg = ("#DBEAFE", "#1D4ED8") if mm > 0 else ("#F1F5F9", "#64748B")
        label = f"{mm} mm · {prob}%"
        return (
            "<td style='padding:8px 6px; text-align:center; border-bottom:1px solid #F1F5F9;'>"
            f"<span style='display:inline-flex; align-items:center; gap:4px; background:{bg}; color:{fg}; "
            f"font-size:0.66rem; font-weight:800; padding:4px 9px; border-radius:999px; white-space:nowrap;'>"
            f"{label}</span></td>"
        )

    rain_cells = "".join(_rain_cell(mm, prob) for mm, prob in zip(rains, rain_probs))

    badge_cells = ""
    for r in risks:
        lbl, col_hex = get_risk_badge(r)
        badge_cells += f"<td style='padding:8px 6px; text-align:center; border-bottom:1px solid #F1F5F9;'><span style='background:{col_hex}; color:#FFF; font-size:0.62rem; font-weight:900; padding:3px 8px; border-radius:999px;'>{lbl}</span></td>"

    active_param = st.session_state["active_param"]

    def row_style(param_name):
        return "" if active_param == "All Parameters" or active_param == param_name else "display:none;"

    hourly_table_html = f"""
    <style>
    #hourly-matrix-tbl tbody tr:nth-child(even) td {{ background: #FBFDFC; }}
    #hourly-matrix-tbl tbody tr:hover td {{ background: #F0FDFA; }}
    #hourly-matrix-tbl td, #hourly-matrix-tbl th {{ transition: background 0.15s ease-in-out; }}
    </style>
    <div style="background:#FFFFFF; border:1px solid #EDF1F5; border-radius:12px; overflow-x:auto; padding:14px; margin-top:0.6rem; box-shadow:0 2px 8px rgba(0,0,0,0.03);">
        <table id="hourly-matrix-tbl" style="width:100%; border-collapse:collapse; font-family:'Inter',sans-serif; white-space:nowrap;">
            <thead>
                <tr>
                    <th style='padding:8px 12px; text-align:left; font-size:0.74rem; font-weight:700; background:#FAFBFC; border-bottom:1px solid #EDF1F5; color:#64748B;'>Time</th>
                    {table_headers}
                </tr>
            </thead>
            <tbody>
                <tr style="{row_style('Weather')}">
                    <td style="font-weight:600; font-size:0.78rem; padding:8px 12px; border-bottom:1px solid #F1F5F9; color:#334155;">🌤️ Weather</td>
                    {icon_cells}
                </tr>
                <tr style="{row_style('Temperature')}">
                    <td style="font-weight:600; font-size:0.78rem; padding:8px 12px; border-bottom:1px solid #F1F5F9; color:#334155;">🌡️ Temperature (°C)</td>
                    {t_cells}
                </tr>
                <tr style="{row_style('Humidity')}">
                    <td style="font-weight:600; font-size:0.78rem; padding:8px 12px; border-bottom:1px solid #F1F5F9; color:#334155;">💧 Humidity (%)</td>
                    {h_cells}
                </tr>
                <tr style="{row_style('Rainfall')}">
                    <td style="font-weight:600; font-size:0.78rem; padding:8px 12px; border-bottom:1px solid #F1F5F9; color:#334155;">🌧️ Rainfall / Condition</td>
                    {rain_cells}
                </tr>
                <tr style="{row_style('Thermal Stress')}">
                    <td style="font-weight:600; font-size:0.78rem; padding:8px 12px; border-bottom:1px solid #F1F5F9; color:#334155;">🔥 Thermal Stress (HTSS score, 0–100)</td>
                    {s_cells}
                </tr>
                <tr style="{row_style('Heat Risk')}">
                    <td style="font-weight:600; font-size:0.78rem; padding:8px 12px; border-bottom:1px solid #F1F5F9; color:#334155;">⚠️ Heat Risk (0–100)</td>
                    {k_cells}
                </tr>
                <tr style="{row_style('Heat Risk')}">
                    <td style="font-weight:600; font-size:0.78rem; padding:8px 12px; border-bottom:1px solid #F1F5F9; color:#334155;">Risk Level</td>
                    {badge_cells}
                </tr>
            </tbody>
        </table>
    </div>
    """
    st.markdown(hourly_table_html, unsafe_allow_html=True)

    _footnote_text = (
        "Live forecast from Open-Meteo — temperature, humidity and rainfall reflect real current data for this location."
        if is_live else
        "Live weather is unavailable right now, so this is the offline demo dataset — rainfall isn't modeled here, so it's shown as N/A rather than an invented value."
    )
    st.markdown(
        f"""
        <div style="display:flex; align-items:center; gap:8px; margin-top:10px; font-size:0.76rem; color:#64748B; font-weight:500;">
            <span style="font-size:0.95rem;">💡</span>
            {_footnote_text}
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.markdown("<hr class='hs-divider' style='margin: 2rem 0;'/>", unsafe_allow_html=True)

    # ----------------------------------------------------------------------
    # 6. PEAK RISK WINDOW & ADVISORY CARDS (SINGLE-LINE ALIGNMENT)
    # ----------------------------------------------------------------------
    peak_start = peak.get('start', '09:00')
    peak_end = peak.get('end', '16:00')
    peak_score = int(round(peak.get('peak_score', 86)))

    st.markdown(
        f"""
        <div style="display: grid; grid-template-columns: 1fr 1.2fr 1.5fr; gap: 16px; align-items: stretch;">
            <div style="background: #F0FDF4; border: 1.5px solid #86EFAC; border-radius: 14px; padding: 20px; text-align: center; display: flex; flex-direction: column; justify-content: center;">
                <div style="font-size: 1.8rem;">📊</div>
                <div style="font-weight: 800; font-size: 0.88rem; color: #166534; margin-top: 4px;">WHEN WILL THE RISK PEAK?</div>
                <div style="font-size: 0.75rem; color: #475569; margin-top: 2px;">This is the time window when heat-health risk is expected to be highest today.</div>
            </div>
            <div style="background: #FFFFFF; border: 1.5px solid #E2E8F0; border-radius: 14px; padding: 20px; text-align: center; display: flex; flex-direction: column; justify-content: center;">
                <div style="font-size: 1.4rem; color: #DC2626;">⏰</div>
                <div style="font-size: 1.45rem; font-weight: 900; color: #0F172A; margin-top: 2px;">{peak_start} – {peak_end}</div>
                <div style="font-size: 0.78rem; color: #64748B; font-weight: 700; margin-top: 2px;">Peak health-risk score: <span style="color:#DC2626;">{peak_score}/100</span></div>
            </div>
            <div style="background: #FEF2F2; border: 1.5px solid #FCA5A5; border-radius: 14px; padding: 20px; display: flex; flex-direction: column; justify-content: center;">
                <div style="display: flex; align-items: center; gap: 8px; font-weight: 800; color: #991B1B; font-size: 0.9rem;">
                    <span>☀️</span> Take extra care during this period
                </div>
                <div style="font-size: 0.80rem; color: #7F1D1D; font-weight: 600; margin-top: 4px;">
                    Stay hydrated, avoid direct sun exposure, and limit outdoor activities.
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # ----------------------------------------------------------------------
    # 7. AUTHORITY-ONLY ANALYTICAL GRAPHS
    # ----------------------------------------------------------------------
    user_type = st.session_state.get("user_profile", {}).get("user_type", "Citizen")

    if user_type == "Authority" and not df.empty:
        st.markdown("<hr class='hs-divider' style='margin: 2.5rem 0;'/>", unsafe_allow_html=True)
        section_title("DETAILED ANALYTICAL TRAJECTORY CHARTS")
        st.plotly_chart(risk_timeline_chart(df, peak.get("start", "09:00"), peak.get("end", "16:00")), use_container_width=True)
        
        ca1, ca2 = st.columns(2)
        with ca1:
            st.plotly_chart(thermal_stress_timeline_chart(df), use_container_width=True)
            st.plotly_chart(wind_radiation_chart(df), use_container_width=True)
        with ca2:
            st.plotly_chart(multi_variable_chart(df), use_container_width=True)
            st.plotly_chart(five_day_forecast_chart(df), use_container_width=True)

    confidence_meter(get_forecast_confidence(active_loc_id))
    htss_disclaimer()
# ==========================================================================
# VULNERABILITY
# ==========================================================================
def render_vulnerability():
    page_header(t("vulnerability"), "Ward-level socio-environmental vulnerability")
    demo_mode_badge()

    ranking = get_vulnerability_ranking(scenario_boost=boost)

    if "ward_name" in ranking.columns and "city" in ranking.columns:
        ranking["ward_name"] = [
            get_clean_area_name(r["city"], r["ward_name"], idx)
            for idx, r in ranking.iterrows()
        ]

    if not is_data_saver:
        st.plotly_chart(vulnerability_comparison_chart(ranking), use_container_width=True)
        st.markdown("<hr class='hs-divider'/>", unsafe_allow_html=True)

    section_title("TOP PRIORITY AREAS")
    top10 = ranking.head(10).reset_index(drop=True)
    for i, row in top10.iterrows():
        st.markdown(
            f"""
            <div class="hs-card" style="display:flex; justify-content:space-between; align-items:center; padding:14px 20px; margin-bottom:8px;">
                <div><b>{i+1}. {row['city']} — {row['ward_name']}</b></div>
                <div style="color:{row['risk_color']}; font-weight:800;">{row['health_risk']:.0f}</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    st.markdown("<hr class='hs-divider'/>", unsafe_allow_html=True)
    section_title("VULNERABILITY WEIGHT MODEL")
    for k, v in VULNERABILITY_WEIGHTS.items():
        st.markdown(f"**{k.replace('_', ' ').title()}** — {int(v*100)}%")
        st.progress(max(0.0, min(1.0, float(v))))


# ==========================================================================
# ALERTS
# ==========================================================================
def render_alerts():
    header_col, role_col = st.columns([3.2, 1.2])

    with header_col:
        st.markdown(
            """<div style="display: flex; align-items: center; gap: 16px; margin-bottom: 0.4rem;">
<div style="background: #FEE2E2; border-radius: 50%; width: 56px; height: 56px; display: flex; align-items: center; justify-content: center; font-size: 1.8rem; flex-shrink: 0;">🌡️</div>
<div>
<div style="font-size: 2.1rem; font-weight: 800; color: #0F172A; letter-spacing: -0.03em; line-height: 1.1;">Heat Health Alerts</div>
<div style="font-size: 0.92rem; color: #475569; font-weight: 500; margin-top: 4px;">Role-specific, actionable heat-health alerts & SMS Broadcast</div>
</div>
</div>""",
            unsafe_allow_html=True,
        )

    with role_col:
        render_role_selector()

    active_loc_id = get_selected_location_id(locations_df)
    risk_data = get_current_risk(active_loc_id, scenario_boost=boost)
    _is_live_weather = risk_data["weather"].source == "live"
    _banner_text = (
        "<b style=\"color: #1E40AF;\">LIVE WEATHER — Ambient temp/humidity/wind reflect Open-Meteo's real current data for this location.</b>"
        if _is_live_weather else
        "<b style=\"color: #1E40AF;\">DEMO MODE — Live weather unavailable right now, using simulated data.</b><br/>"
        "<span style=\"color: #3B82F6;\">Live weather integration falls back automatically to this dataset if unavailable.</span>"
    )
    st.markdown(
        f"""<div style="background: #EFF6FF; border-left: 4px solid #2563EB; border-radius: 8px; padding: 12px 18px; margin-bottom: 1.2rem; display: flex; align-items: flex-start; gap: 12px;">
<div style="background: #2563EB; color: #FFFFFF; border-radius: 50%; width: 20px; height: 20px; display: flex; align-items: center; justify-content: center; font-size: 0.75rem; font-weight: 800; flex-shrink: 0; margin-top: 1px;">i</div>
<div style="font-size: 0.82rem; color: #1E3A8A; line-height: 1.45;">
{_banner_text}
</div>
</div>""",
        unsafe_allow_html=True,
    )

    city = st.session_state.get("selected_city", "Delhi")
    ward = st.session_state.get("selected_ward")

    role_vulnerability = get_role_specific_vulnerability(risk_data)
    dynamic_health_risk = round(
        0.65 * risk_data["thermal"].htss + 0.35 * role_vulnerability.score, 1
    )
    lvl_label, _ = vulnerability_label_and_color(dynamic_health_risk)

    temp_val = risk_data["weather"].temperature_c
    humidity_val = risk_data["weather"].humidity_pct
    wind_val = risk_data["weather"].wind_ms
    htss_val = risk_data["thermal"].htss

    user_info = st.session_state.get("user_profile", {})
    user_phone = user_info.get("phone") or user_info.get("mobile") or "+911234567898"
    clean_phone = "".join(filter(str.isdigit, str(user_phone)))[-10:]
    formatted_phone = f"+91{clean_phone}"

    if ward:
        clean_locality = get_clean_area_name(city, ward)
        location_str = f"{city} – {clean_locality}"
    else:
        clean_locality = get_clean_area_name(city, "Ward 1")
        location_str = f"{city} – {clean_locality}"

    # The "Extreme Heat Scenario" demo control is an explicit simulation
    # request from the user — when it's active, always show the dispatched
    # SMS view so the demo reliably illustrates the feature, even if this
    # particular ward/role's combined score doesn't cross the genuine
    # EXTREME threshold on top of today's real (possibly mild) weather.
    is_extreme = (lvl_label == "EXTREME") or bool(st.session_state.get("scenario_active"))

    if is_extreme:
        _trigger_reason = (
            f"Auto-broadcast triggered for <b>{city}</b> because heat-health risk reached <b>EXTREME</b> level (score ≥ 80)."
            if lvl_label == "EXTREME" else
            f"Auto-broadcast triggered for <b>{city}</b> by the <b>Extreme Heat Scenario</b> demo control (current real score: {dynamic_health_risk:.0f}/100, {lvl_label})."
        )
        card_html = f"""<div style="background: #FFF5F5; border: 1.5px solid #FCA5A5; border-left: 5px solid #EF4444; border-radius: 14px; padding: 18px 22px; margin-bottom: 1.2rem; box-shadow: 0 4px 14px rgba(239, 68, 68, 0.05);">
<div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px;">
<div style="display: flex; align-items: center; gap: 14px;">
<div style="background: #FEE2E2; border-radius: 50%; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center; font-size: 1.3rem;">🔔</div>
<div>
<div style="font-weight: 800; color: #DC2626; font-size: 0.98rem; letter-spacing: 0.01em;">AUTOMATED SMS ALERT DISPATCHED</div>
<div style="font-size: 0.83rem; color: #64748B; font-weight: 500; margin-top: 2px;">Warning SMS automatically sent to registered mobile: <b style="color: #334155;">{formatted_phone}</b></div>
</div>
</div>
<div>
<span style="background: #FEE2E2; color: #DC2626; font-size: 0.80rem; font-weight: 800; padding: 6px 14px; border-radius: 20px; display: inline-flex; align-items: center; gap: 6px;">
<span style="background: #DC2626; color: #FFF; border-radius: 50%; width: 16px; height: 16px; display: inline-flex; align-items: center; justify-content: center; font-size: 0.65rem;">✔</span>DELIVERED</span>
</div>
</div>
<div style="background: #FFFFFF; border: 1.5px solid #FEE2E2; border-radius: 12px; padding: 16px 20px; margin-top: 14px;">
<div style="display: flex; align-items: center; gap: 8px; font-weight: 800; color: #EF4444; font-size: 0.84rem; letter-spacing: 0.04em;"><span>✉️</span> DISPATCHED SMS CONTENT</div>
<div style="margin-top: 10px;">
<div style="display: flex; align-items: center; gap: 6px; font-weight: 800; color: #B45309; font-size: 0.90rem;"><span>🔆</span> HEATSHIELD ALERT</div>
<div style="font-size: 0.88rem; color: #1E293B; font-weight: 600; margin-top: 3px;">{location_str} is under {lvl_label} Heat Stress (Risk Score: {dynamic_health_risk:.0f}/100).</div>
</div>
<div style="background: #F8FAFC; border: 1px solid #F1F5F9; border-radius: 8px; padding: 12px 16px; margin-top: 14px; display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px;">
<div style="display: flex; align-items: center; gap: 10px;"><span style="font-size: 1.6rem;">🌡️</span><div><div style="font-size: 0.72rem; color: #64748B; font-weight: 600;">Ambient Temp</div><div style="font-size: 1.05rem; font-weight: 800; color: #0F172A;">{temp_val:.1f}°C</div></div></div>
<div style="display: flex; align-items: center; gap: 10px; border-left: 1px solid #E2E8F0; padding-left: 12px;"><span style="font-size: 1.6rem;">💧</span><div><div style="font-size: 0.72rem; color: #64748B; font-weight: 600;">Humidity</div><div style="font-size: 1.05rem; font-weight: 800; color: #0F172A;">{humidity_val:.0f}% RH</div></div></div>
<div style="display: flex; align-items: center; gap: 10px; border-left: 1px solid #E2E8F0; padding-left: 12px;"><span style="font-size: 1.6rem;">💨</span><div><div style="font-size: 0.72rem; color: #64748B; font-weight: 600;">Wind Speed</div><div style="font-size: 1.05rem; font-weight: 800; color: #0F172A;">{wind_val:.1f} m/s</div></div></div>
<div style="display: flex; align-items: center; gap: 10px; border-left: 1px solid #E2E8F0; padding-left: 12px;"><span style="font-size: 1.6rem;">🌡️</span><div><div style="font-size: 0.72rem; color: #64748B; font-weight: 600;">Thermal Index (HTSS)</div><div style="font-size: 1.05rem; font-weight: 800; color: #0F172A;">{htss_val:.0f}</div></div></div>
</div>
<div style="background: #FEF2F2; border-radius: 6px; padding: 10px 14px; margin-top: 12px; display: flex; align-items: center; gap: 8px; font-size: 0.83rem; font-weight: 700; color: #991B1B;">
<span style="background: #EF4444; color: #FFF; border-radius: 50%; width: 18px; height: 18px; display: inline-flex; align-items: center; justify-content: center; font-size: 0.72rem;">!</span> It is advised to take immediate precautions, stay hydrated, seek shade, and avoid direct exposure.
</div>
</div>
<div style="font-size: 0.76rem; color: #64748B; font-weight: 500; margin-top: 12px; display: flex; align-items: center; gap: 4px;">
<span style="color: #F59E0B;">⚡</span> {_trigger_reason}
</div>
</div>"""
    else:
        card_html = f"""<div style="background: #F8FAFC; border: 1.5px solid #E2E8F0; border-left: 5px solid #94A3B8; border-radius: 14px; padding: 18px 22px; margin-bottom: 1.2rem;">
<div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px;">
<div style="display: flex; align-items: center; gap: 14px;">
<div style="background: #E2E8F0; border-radius: 50%; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center; font-size: 1.3rem;">🔕</div>
<div>
<div style="font-weight: 800; color: #475569; font-size: 0.98rem; letter-spacing: 0.01em;">NO SMS ALERT DISPATCHED</div>
<div style="font-size: 0.83rem; color: #64748B; font-weight: 500; margin-top: 2px;">Registered mobile <b style="color: #334155;">{formatted_phone}</b> is being monitored, not alerted.</div>
</div>
</div>
<div>
<span style="background: #E2E8F0; color: #475569; font-size: 0.80rem; font-weight: 800; padding: 6px 14px; border-radius: 20px;">MONITORING</span>
</div>
</div>
<div style="font-size: 0.82rem; color: #64748B; font-weight: 500; margin-top: 12px; line-height: 1.5;">
<b style="color: #334155;">{location_str}</b> is currently under <b>{lvl_label}</b> Heat Stress (Risk Score: {dynamic_health_risk:.0f}/100). Automated SMS broadcasts only fire when a ward's heat-health risk reaches the <b>EXTREME</b> level (score ≥ 80) — below that, alerts stay visible on this dashboard but no message is sent, to avoid alert fatigue on residents' phones.
</div>
</div>"""

    st.markdown(card_html, unsafe_allow_html=True)

    c_left, c_right = st.columns([1.4, 1])

    with c_left:
        st.markdown(
            f"""<div style="background: #F0FDF4; border: 1.5px solid #86EFAC; border-radius: 12px; padding: 18px 24px; display: flex; align-items: center; gap: 18px;">
<div style="background: #DCFCE7; border-radius: 50%; width: 50px; height: 50px; display: flex; align-items: center; justify-content: center; font-size: 1.5rem;">📞</div>
<div>
<div style="font-size: 0.76rem; color: #15803D; font-weight: 800; letter-spacing: 0.04em;">REGISTERED RECIPIENT</div>
<div style="font-size: 1.35rem; font-weight: 900; color: #0A352C; margin-top: 2px;">{formatted_phone}</div>
<div style="font-size: 0.80rem; color: #475569; font-weight: 600; margin-top: 2px;">Target Monitored City: <b style="color: #0F172A;">{city}</b></div>
</div>
</div>""",
            unsafe_allow_html=True,
        )

    with c_right:
        st.markdown(
            """<div style="background: #FFFFFF; border: 1.5px solid #E2E8F0; border-radius: 12px; padding: 18px 24px; display: flex; align-items: center; justify-content: center; gap: 18px;">
<div style="font-size: 2.0rem; color: #16A34A;">📶</div>
<div>
<div style="font-size: 0.76rem; color: #64748B; font-weight: 800; letter-spacing: 0.04em;">GATEWAY STATUS</div>
<div style="font-size: 1.30rem; font-weight: 900; color: #16A34A; margin-top: 2px;">READY / ACTIVE</div>
<div style="font-size: 0.78rem; color: #94A3B8; font-weight: 600; margin-top: 2px;">Zero-balance Router</div>
</div>
</div>""",
            unsafe_allow_html=True,
        )

    st.markdown("<hr class='hs-divider' style='margin: 1.5rem 0;'/>", unsafe_allow_html=True)
    section_title(f"📍 CURRENT ADVISORY FOR {city.upper()}")
    alert = generate_alerts(active_loc_id, scenario_boost=boost)
    alert_card(alert)

    st.markdown("<hr class='hs-divider' style='margin: 1.5rem 0;'/>", unsafe_allow_html=True)
    selected_role = st.session_state.get("selected_role", "Student")
    section_title(f"RECOMMENDATION FOR: {selected_role.upper()}")
    rec = get_recommendations(active_loc_id, selected_role, current_lang_code(), scenario_boost=boost)
    st.info(rec)

    # "All Active Regional Alerts" is an authority-only, city-wide monitoring
    # view — citizens only need their own location's advisory above.
    if user_type == "Authority":
        st.markdown("<hr class='hs-divider' style='margin: 1.5rem 0;'/>", unsafe_allow_html=True)
        section_title("ALL ACTIVE REGIONAL ALERTS")
        all_alerts = generate_alerts_for_all(scenario_boost=boost)
        severe = [a for a in all_alerts if a.level_key in ("red", "extreme", "orange")][:8]
        if not severe:
            st.success("No elevated alerts across monitored locations.")
        for a in severe:
            alert_card(a)


# ==========================================================================
# AUTHORITY DASHBOARD
# ==========================================================================
def render_authority_dashboard():
    page_header(t("authority_dashboard"), "Command-centre view for emergency management")
    demo_mode_badge()

    all_alerts = generate_alerts_for_all(scenario_boost=boost)
    map_df = get_map_risk(scenario_boost=boost)
    hospitals = get_hospitals()
    cooling = get_cooling_centres()
    water = get_water_points()

    c1, c2, c3, c4 = st.columns(4)
    with c1:
        animated_counter("ACTIVE ALERTS", len([a for a in all_alerts if a.level_key != "green"]), color="#E74C3C")
    with c2:
        animated_counter("HIGH-RISK LOCATIONS", int((map_df["risk_key"].isin(["red", "extreme"])).sum()), color="#8E44AD")
    with c3:
        animated_counter("HOSPITALS TRACKED", len(hospitals), color="#0D9488")
    with c4:
        animated_counter("COOLING CENTRES", len(cooling), color="#10B981")

    st.markdown("<hr class='hs-divider'/>", unsafe_allow_html=True)
    col_a, col_b = st.columns([1.3, 1])
    with col_a:
        section_title("HIGH-RISK LOCATIONS")
        high_risk = map_df.sort_values("health_risk", ascending=False).head(8)
        high_risk_display = high_risk.copy()
        high_risk_display["ward_name"] = [
            get_clean_area_name(r["city"], r["ward_name"], idx)
            for idx, r in high_risk_display.iterrows()
        ]

        render_styled_table(
            high_risk_display[["city", "ward_name", "health_risk", "risk_level", "population"]]
            .rename(columns={"city": "City", "ward_name": "Locality / Area", "health_risk": "Risk Score",
                             "risk_level": "Level", "population": "Population"})
        )
        
    with col_b:
        section_title("PRIORITY ACTIONS")
        top = high_risk.iloc[0] if not high_risk.empty else None
        actions = []
        if top is not None:
            top_locality = get_clean_area_name(top["city"], top["ward_name"])
            actions.append(f"Open cooling centre in {top_locality}, {top['city']}")
            actions.append(f"Deploy water tanker to {top_locality}")
        actions += [
            "Notify outdoor employers of elevated risk",
            "Prepare hospitals for heat-illness cases",
            "Issue Hindi + regional-language public alert",
        ]
        for i, act in enumerate(actions, 1):
            st.markdown(f"**{i}.** {act}")

    st.markdown("<hr class='hs-divider'/>", unsafe_allow_html=True)
    section_title("WATER POINTS & COOLING CENTRE COVERAGE")

    water_display = water[water["city"] == st.session_state["selected_city"]][["name", "lat", "lon"]].copy()
    water_display["name"] = [
        _clean_water_point_name(st.session_state["selected_city"], n)
        for n in water_display["name"]
    ]
    water_display = water_display.rename(columns={"name": "Name", "lat": "Latitude", "lon": "Longitude"})
    render_styled_table(water_display, max_rows=10)


# ==========================================================================
# PRECAUTIONS
# ==========================================================================
_PRECAUTION_CATEGORIES = [
    {
        "icon": "💧",
        "title": "Hydration & Fluids",
        "color": "#2563EB",
        "points": [
            "Drink water regularly through the day, even before you feel thirsty.",
            "Avoid alcohol, excess caffeine, and sugary drinks — they speed up dehydration.",
            "Carry a water bottle whenever you step outdoors, especially between 12 PM and 4 PM.",
            "On very hot days, ORS or a pinch-of-salt lemon water helps replace lost electrolytes.",
        ],
    },
    {
        "icon": "👕",
        "title": "Clothing & Sun Protection",
        "color": "#F59E0B",
        "points": [
            "Wear light-coloured, loose-fitting, breathable cotton clothing.",
            "Use a wide-brimmed hat, umbrella, or scarf whenever you're outdoors in the sun.",
            "Apply sunscreen (SPF 30+) on exposed skin before stepping out.",
            "Wear sunglasses to cut down on glare and protect your eyes.",
        ],
    },
    {
        "icon": "⏰",
        "title": "Timing Outdoor Activity",
        "color": "#DC2626",
        "points": [
            "Avoid strenuous activity or direct sun exposure between 12 PM and 4 PM.",
            "Shift outdoor work, exercise, errands, or sports to early morning or evening.",
            "Take frequent breaks in shade or a cool area if you must be outdoors.",
            "Plan travel to avoid long waits in the open sun — pick shaded routes and stops.",
        ],
    },
    {
        "icon": "🏠",
        "title": "Cooling Your Space",
        "color": "#0D9488",
        "points": [
            "Keep curtains or blinds closed during peak sun hours to keep indoors cooler.",
            "Use fans, damp cloths, or a cool shower to bring your body temperature down.",
            "Visit a cooling centre or an air-conditioned public space if your home lacks cooling.",
            "Cross-ventilate your home during the cooler night and early-morning hours.",
        ],
    },
    {
        "icon": "⚠️",
        "title": "Recognize the Warning Signs",
        "color": "#B91C1C",
        "points": [
            "Heat cramps: muscle pain or spasms — rest, hydrate, and stretch gently.",
            "Heat exhaustion: heavy sweating, weakness, nausea, headache, cool clammy skin.",
            "Heat stroke (EMERGENCY): very high body temperature, confusion, hot dry skin, rapid pulse, or loss of consciousness.",
            "Any of these signs — in yourself or someone else — need immediate attention.",
        ],
    },
    {
        "icon": "🚑",
        "title": "Emergency Response",
        "color": "#E11D48",
        "points": [
            "Move the person to a cool, shaded place immediately.",
            "Remove excess clothing and cool the body with wet cloths, fanning, or a cool (not icy) bath.",
            "Give small sips of water only if the person is fully conscious and alert.",
            "Call emergency medical services right away for confusion, unconsciousness, or very high body temperature.",
        ],
    },
    {
        "icon": "🤝",
        "title": "Looking Out for Vulnerable Groups",
        "color": "#7C3AED",
        "points": [
            "Check on elderly neighbours, infants, pregnant women, and people with chronic illness daily during a heatwave.",
            "Never leave children, elderly people, or pets alone in a parked vehicle — even briefly.",
            "Outdoor workers, homeless individuals, and daily-wage labourers often need extra community support.",
            "Share cooling-centre and water-point locations with those who may not have easy access to information.",
        ],
    },
]


def render_precaution_category_card(cat: dict) -> None:
    with st.expander(f"{cat['icon']}  {cat['title']}", expanded=False):
        for point in cat["points"]:
            st.markdown(
                f"""
                <div style="display:flex; gap:10px; padding:5px 0; align-items:flex-start;">
                    <span style="color:{cat['color']}; font-weight:900; font-size:0.95rem; margin-top:1px;">✓</span>
                    <span style="font-size:0.88rem; line-height:1.55;">{point}</span>
                </div>
                """,
                unsafe_allow_html=True,
            )


def render_precautions():
    tk = THEMES.get(get_current_theme(), THEMES["light"])
    is_dark = get_current_theme() == "dark"

    page_header(
        t("precautions"),
        "Role & risk-aware heat safety guidance, tailored to your current location and the role you've selected.",
    )

    active_loc_id = get_selected_location_id(locations_df)
    selected_role = st.session_state.get("selected_role", "Student")
    lang = current_lang_code()

    try:
        risk_data = get_current_risk(active_loc_id, scenario_boost=boost)
        role_vulnerability = get_role_specific_vulnerability(risk_data)
        dynamic_health_risk = round(
            0.65 * risk_data["thermal"].htss + 0.35 * role_vulnerability.score, 1
        )
        lvl_label, lvl_color = vulnerability_label_and_color(dynamic_health_risk)
        icon_map = {
            "EXTREME": "🚨", "VERY HIGH": "🔥", "HIGH": "⚠️",
            "MODERATE": "⚡", "LOW": "✅",
        }
        level = {
            "label": lvl_label, "color": lvl_color,
            "key": lvl_label.lower(), "icon": icon_map.get(lvl_label, "⚠️"),
        }

        section_title("CURRENT HEAT-HEALTH RISK")
        render_heat_health_hero(dynamic_health_risk, level)
        st.write("")

        # ------------------------------------------------------------
        # Role-specific detailed recommendation — highlighted card
        # ------------------------------------------------------------
        section_title(f"PRECAUTIONS FOR: {selected_role.upper()}")
        recommendation_text = get_recommendations(
            active_loc_id, selected_role, lang, scenario_boost=boost
        )
        card_bg = f"{lvl_color}14"
        st.markdown(
            f"""
            <div style="background:{card_bg}; border:1.5px solid {lvl_color}55; border-radius:16px;
                        padding:20px 24px; box-shadow:0 4px 14px rgba(0,0,0,0.05);">
                <div style="display:flex; align-items:center; gap:10px; margin-bottom:10px;">
                    <span style="font-size:1.4rem;">{level['icon']}</span>
                    <span style="font-weight:800; font-size:1rem; color:{lvl_color};">
                        {lvl_label} RISK — Guidance for {selected_role}
                    </span>
                </div>
                <div style="font-size:0.92rem; line-height:1.7; color:{tk['text_primary']}; white-space:pre-line;">
                    {recommendation_text}
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    except Exception:
        st.warning("Couldn't load location-specific risk right now — showing general precautions below.")

    st.write("")
    st.markdown("<hr class='hs-divider'/>", unsafe_allow_html=True)
    section_title("GENERAL HEAT-SAFETY GUIDE")
    st.caption("Tap any category below to open detailed, step-by-step precautions.")
    st.write("")

    col1, col2 = st.columns(2)
    for i, cat in enumerate(_PRECAUTION_CATEGORIES):
        target_col = col1 if i % 2 == 0 else col2
        with target_col:
            render_precaution_category_card(cat)

    st.markdown("<hr class='hs-divider'/>", unsafe_allow_html=True)
    demo_mode_badge()


# ==========================================================================
# ABOUT
# ==========================================================================
def render_about():
    page_header(t("about"), "")
    st.markdown(
        f"""
        HeatShield India is a **prototype heat-health early warning decision-support
        platform** built for hackathon demonstration. It converts weather forecasts into
        localized, vulnerability-aware health-risk scores and actionable alerts for
        citizens, outdoor workers, hospitals, schools, employers, and authorities.

        **Tech stack:** Python, Streamlit, Plotly, Folium, Pandas, NumPy, scikit-learn.

        **Status:** {format_ist_timestamp()}

        This is a decision-support prototype, not an official government alert system.
        """
    )
    demo_mode_badge()


# ==========================================================================
# STRICT ROUTER & ROLE ACCESS GATEKEEPER
# ==========================================================================
user_type = st.session_state.get("user_profile", {}).get("user_type", "Citizen")

if user_type == "Authority":
    PAGE_RENDERERS = {
        "Authority Dashboard": render_authority_dashboard,
        "Dashboard": render_dashboard,
        "Risk Map": render_risk_map,
        "Forecast": render_forecast,
        "Vulnerability": render_vulnerability,
        "Alerts": render_alerts,
        "About": render_about,
    }
    if page not in ("Authority Dashboard", "Dashboard", "Risk Map", "Forecast", "Vulnerability", "Alerts", "About"):
        st.session_state["page"] = "Authority Dashboard"
        page = "Authority Dashboard"
else:
    PAGE_RENDERERS = {
        "Dashboard": render_dashboard,
        "Risk Map": render_risk_map,
        "Location Analysis": render_location_analysis,
        "Forecast": render_forecast,
        "Vulnerability": render_vulnerability,
        "Alerts": render_alerts,
        "Precautions": render_precautions,
        "About": render_about,
    }
    if page == "Authority Dashboard" or page not in PAGE_RENDERERS:
        st.session_state["page"] = "Dashboard"
        page = "Dashboard"

try:
    PAGE_RENDER_FUNC = PAGE_RENDERERS.get(page, render_dashboard)
    PAGE_RENDER_FUNC()
except Exception as exc:
    st.error("Something went wrong while rendering this page.")
    st.caption(f"Technical details: {type(exc).__name__}: {exc}")