"""
backend/api_service.py

API-STYLE SERVICE LAYER
========================
This module is the single entry point the Streamlit frontend calls.
Every function here corresponds 1:1 to a documented REST endpoint
(see docs at bottom of file / README "API Architecture" section),
so migrating to FastAPI later is a matter of wrapping each function
in a route decorator — no business-logic changes required.

    GET  /api/locations                          -> get_locations()
    GET  /api/locations/{id}/current-risk         -> get_current_risk(location_id)
    GET  /api/locations/{id}/forecast?days=5      -> get_forecast_view(location_id, days)
    GET  /api/map/risk?time=...                   -> get_map_risk()
    GET  /api/alerts?district=...                 -> generate_alerts(location_id)
    GET  /api/vulnerability?district=...           -> get_vulnerability(location_id)
    POST /api/admin/weather-ingestion              -> ingest_weather(...)   [utils.validators]
    POST /api/admin/generate-alerts                -> generate_alerts_for_all()
"""

from __future__ import annotations

import dataclasses
import os

import pandas as pd
import streamlit as st

from backend.weather_service import get_weather, get_all_current_weather, get_weather_at_coords
from backend.thermal_engine import calculate_htss, top_drivers, ThermalStressResult
from backend.vulnerability_engine import (
    calculate_vulnerability,
    calculate_role_vulnerability,
    VulnerabilityResult,
)
from backend.risk_engine import calculate_health_risk, HealthRiskResult
from backend.alert_engine import generate_alert, generate_alerts_for_locations, Alert
from backend.forecast_service import get_forecast, get_peak_risk_summary, get_forecast_confidence
from backend.recommendation_engine import get_recommendation
from utils.constants import DEMO_LOCATIONS
from utils.helpers import idw_interpolate

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")

# Demographic/vulnerability fields that get a location-sensitive
# inverse-distance-weighted estimate when exact live GPS coordinates are
# available, instead of copying whichever single demo ward is nearest.
VULN_FIELDS = [
    "elderly_pct",
    "population_density",
    "outdoor_worker_pct",
    "green_cover_pct",
    "healthcare_access_score",
    "pregnant_women_pct",
    "infants_pct",
]


def _live_gps_coords() -> tuple[float, float] | None:
    """Return the user's exact (lat, lon) from live GPS tracking, if active."""
    if not st.session_state.get("use_live_gps"):
        return None
    gps = st.session_state.get("user_gps")
    if not gps:
        return None
    lat, lon = gps.get("latitude"), gps.get("longitude")
    if lat is None or lon is None:
        return None
    return float(lat), float(lon)


# --------------------------------------------------------------------
# GET /api/locations
# --------------------------------------------------------------------
@st.cache_data(show_spinner=False)
def get_locations() -> pd.DataFrame:
    return pd.read_csv(os.path.join(DATA_DIR, "locations.csv"))


def get_cities() -> list[str]:
    return DEMO_LOCATIONS


def get_wards_for_city(city: str) -> pd.DataFrame:
    locations = get_locations()
    return locations[locations["city"] == city].reset_index(drop=True)


# --------------------------------------------------------------------
# Core computation bundle for one location
# --------------------------------------------------------------------
def compute_location_bundle(location_id: str, scenario_boost: float = 0.0, use_live: bool = True) -> dict:
    """
    Returns thermal, vulnerability and health-risk results for one
    location. `scenario_boost` (0-1) is used by the Extreme Heat Demo
    to intensify weather inputs without touching the underlying data files.

    `use_live` fetches real current weather (Open-Meteo, cached 5 min) for
    single-location detail views (Dashboard, Alerts, Forecast). Bulk views
    that loop over every ward (map, all-regional-alerts) should pass
    use_live=False — otherwise every rerun fires one network call per
    ward and the app visibly freezes.
    """
    locations = get_locations()
    loc_row = locations[locations["location_id"] == location_id]
    if loc_row.empty:
        raise ValueError(f"Unknown location_id: {location_id}")
    loc = loc_row.iloc[0].copy()

    weather = get_weather(location_id, use_live=use_live)

    # If the user has live GPS tracking on, prefer data tied to their EXACT
    # coordinates over the nearest demo ward's copy-pasted numbers:
    #   - weather: fetched live for the exact lat/lon (not the ward centroid)
    #   - demographics (elderly%, density, green cover, etc.): an inverse-
    #     distance-weighted estimate across all known reference points,
    #     so two different real locations get two different, locally
    #     appropriate numbers instead of both inheriting one shared ward's
    #     values. This is still an estimate (the prototype has only a
    #     handful of reference points per city, not per-colony census
    #     data) — see idw_interpolate()'s docstring.
    gps_coords = _live_gps_coords() if use_live else None
    if gps_coords:
        ex_lat, ex_lon = gps_coords
        exact_weather = get_weather_at_coords(ex_lat, ex_lon)
        if exact_weather is not None:
            weather = dataclasses.replace(
                weather,
                temperature_c=exact_weather.temperature_c,
                humidity_pct=exact_weather.humidity_pct,
                wind_ms=exact_weather.wind_ms,
                solar_radiation_wm2=exact_weather.solar_radiation_wm2,
                source=exact_weather.source,
            )
        interpolated = idw_interpolate(ex_lat, ex_lon, locations, VULN_FIELDS)
        for field, value in interpolated.items():
            loc[field] = value
        loc["lat"] = ex_lat
        loc["lon"] = ex_lon

    # NOTE: scenario_boost is applied as a guaranteed EXTREME *floor*, not a
    # plain additive offset. An additive-only offset (+4.5C etc.) depends on
    # the current baseline weather — outside peak heatwave season (or on a
    # cooler/rainy day) the boosted values can still land in MODERATE/HIGH,
    # so the "Run Extreme Scenario" demo button wouldn't reliably show
    # EXTREME. Using max()/min() against fixed extreme reference values
    # guarantees an EXTREME-category HTSS regardless of the real baseline,
    # while still allowing an already-extreme baseline to show its own
    # (even higher) numbers.
    if scenario_boost:
        temp = max(weather.temperature_c + scenario_boost * 4.5, 47.0)
        humidity = min(95.0, max(weather.humidity_pct + scenario_boost * 8, 78.0))
        wind = min(max(0.2, weather.wind_ms - scenario_boost * 1.2), 0.8)
        radiation = min(1050.0, max(weather.solar_radiation_wm2 + scenario_boost * 120, 980.0))
        hot_days = max(weather.consecutive_hot_days + 2, 7)
    else:
        temp = weather.temperature_c
        humidity = weather.humidity_pct
        wind = weather.wind_ms
        radiation = weather.solar_radiation_wm2
        hot_days = weather.consecutive_hot_days

    # IMPORTANT: write the boosted numbers back onto the weather object
    # itself (not just into local vars used for the HTSS calc below).
    # Every dashboard panel, alert card, and SMS message reads
    # bundle["weather"].* directly, so if we don't replace it here those
    # surfaces keep showing the un-boosted real-world numbers even while
    # the Extreme Heat Scenario is active and the risk score has spiked.
    if scenario_boost:
        weather = dataclasses.replace(
            weather,
            temperature_c=temp,
            humidity_pct=humidity,
            wind_ms=wind,
            solar_radiation_wm2=radiation,
            consecutive_hot_days=hot_days,
        )

    thermal: ThermalStressResult = calculate_htss(
        temperature_c=temp,
        humidity_pct=humidity,
        wind_ms=wind,
        solar_radiation_wm2=radiation,
        consecutive_hot_days=hot_days,
        night_recovery_temp_c=weather.night_recovery_temp_c,
    )

    vuln: VulnerabilityResult = calculate_vulnerability(
        elderly_pct=loc["elderly_pct"],
        population_density=loc["population_density"],
        outdoor_worker_pct=loc["outdoor_worker_pct"],
        green_cover_pct=loc["green_cover_pct"],
        healthcare_access_score=loc["healthcare_access_score"],
    )

    health_risk: HealthRiskResult = calculate_health_risk(thermal.htss, vuln.score)

    return {
        "location": loc.to_dict(),
        "weather": weather,
        "thermal": thermal,
        "vulnerability": vuln,
        "health_risk": health_risk,
    }


# --------------------------------------------------------------------
# GET /api/locations/{id}/current-risk
# --------------------------------------------------------------------
def get_current_risk(location_id: str, scenario_boost: float = 0.0) -> dict:
    bundle = compute_location_bundle(location_id, scenario_boost=scenario_boost)
    peak = get_peak_risk_summary(location_id)
    confidence = get_forecast_confidence(location_id)
    return {
        **bundle,
        "peak_window": peak,
        "confidence": confidence,
        "drivers": top_drivers(bundle["thermal"]),
    }


# --------------------------------------------------------------------
# GET /api/locations/{id}/forecast?days=5
# --------------------------------------------------------------------
def get_forecast_view(location_id: str, days: int = 5) -> pd.DataFrame:
    return get_forecast(location_id, hours=days * 24)


# --------------------------------------------------------------------
# GET /api/map/risk?time=...
# --------------------------------------------------------------------
def get_map_risk(scenario_boost: float = 0.0) -> pd.DataFrame:
    """Compute current risk for ALL wards, for map rendering."""
    locations = get_locations()
    records = []
    for _, loc in locations.iterrows():
        bundle = compute_location_bundle(loc["location_id"], scenario_boost=scenario_boost, use_live=False)
        records.append({
            "location_id": loc["location_id"],
            "city": loc["city"],
            "ward_name": loc["ward_name"],
            "lat": loc["lat"],
            "lon": loc["lon"],
            "temperature_c": bundle["weather"].temperature_c,
            "humidity_pct": bundle["weather"].humidity_pct,
            "wind_ms": bundle["weather"].wind_ms,
            "solar_radiation_wm2": bundle["weather"].solar_radiation_wm2,
            "htss": bundle["thermal"].htss,
            "health_risk": bundle["health_risk"].score,
            "risk_level": bundle["health_risk"].level["label"],
            "risk_color": bundle["health_risk"].level["color"],
            "risk_key": bundle["health_risk"].level["key"],
            "vulnerability": bundle["vulnerability"].score,
            "population": loc["population"],
        })
    return pd.DataFrame(records)


# --------------------------------------------------------------------
# GET /api/vulnerability?district=...
# --------------------------------------------------------------------
def get_vulnerability(location_id: str) -> VulnerabilityResult:
    return compute_location_bundle(location_id)["vulnerability"]


def get_vulnerability_ranking(scenario_boost: float = 0.0) -> pd.DataFrame:
    df = get_map_risk(scenario_boost=scenario_boost)
    return df.sort_values("health_risk", ascending=False).reset_index(drop=True)


# --------------------------------------------------------------------
# GET /api/alerts?district=...
# --------------------------------------------------------------------
def generate_alerts(location_id: str, scenario_boost: float = 0.0) -> Alert:
    bundle = compute_location_bundle(location_id, scenario_boost=scenario_boost)
    peak = get_peak_risk_summary(location_id)
    loc = bundle["location"]
    return generate_alert(
        location_name=loc["city"],
        health_risk=bundle["health_risk"],
        thermal=bundle["thermal"],
        ward_name=loc["ward_name"],
        peak_start=peak.get("start"),
        peak_end=peak.get("end"),
    )


# --------------------------------------------------------------------
# POST /api/admin/generate-alerts  (bulk, for Authority Dashboard)
# --------------------------------------------------------------------
def generate_alerts_for_all(scenario_boost: float = 0.0) -> list[Alert]:
    locations = get_locations()
    rows = []
    for _, loc in locations.iterrows():
        bundle = compute_location_bundle(loc["location_id"], scenario_boost=scenario_boost, use_live=False)
        peak = get_peak_risk_summary(loc["location_id"])
        rows.append({
            "location_name": loc["city"],
            "ward_name": loc["ward_name"],
            "health_risk": bundle["health_risk"],
            "thermal": bundle["thermal"],
            "peak_start": peak.get("start"),
            "peak_end": peak.get("end"),
        })
    return generate_alerts_for_locations(rows)


# --------------------------------------------------------------------
# Recommendations (role + language aware)
# --------------------------------------------------------------------
def get_recommendations(
    location_id: str,
    audience: str,
    language: str = "en",
    scenario_boost: float = 0.0,
) -> str:
    """Return risk-level recommendations with audience-specific guidance."""

    bundle = compute_location_bundle(
        location_id,
        scenario_boost=scenario_boost,
    )

    level_key = bundle["health_risk"].level["key"]

    recommendation = get_recommendation(
        audience,
        level_key,
        language,
    )

    # Load the location row so the role-specific vulnerability layer can
    # use the demographic indicators generated in vulnerability.csv.
    locations = get_locations()
    loc_row = locations[locations["location_id"] == location_id]
    if loc_row.empty:
        raise ValueError(f"Unknown location_id: {location_id}")
    loc = loc_row.iloc[0]

    pregnant_women_pct = float(loc.get("pregnant_women_pct", 0.0))
    infants_pct = float(loc.get("infants_pct", 0.0))

    role_vulnerability = calculate_role_vulnerability(
        elderly_pct=float(loc["elderly_pct"]),
        population_density=float(loc["population_density"]),
        outdoor_worker_pct=float(loc["outdoor_worker_pct"]),
        green_cover_pct=float(loc["green_cover_pct"]),
        healthcare_access_score=float(loc["healthcare_access_score"]),
        audience=audience,
        pregnant_women_pct=pregnant_women_pct,
        infants_pct=infants_pct,
    )

    # Return the role-specific score to the frontend without changing the
    # existing generic health-risk calculation used by the map.
    role_specific_note = (
        f"Role-specific vulnerability score: {role_vulnerability.score:.1f}"
        if str(audience or "").strip().lower()
        in {"pregnant women", "pregnant woman", "pregnancy",
            "infants", "infant", "baby", "babies"}
        else ""
    )

    audience_key = str(audience or "Citizen").strip().lower()

    # ---------------------------------------------------------------
    # Pregnant Women
    # ---------------------------------------------------------------
    if audience_key in {"pregnant women", "pregnant woman", "pregnancy"}:
        if language == "hi":
            targeted = (
                "\n\n**गर्भवती महिलाओं के लिए विशेष सावधानी:**\n"
                "• दोपहर की तेज गर्मी और सीधी धूप से बचें।\n"
                "• पर्याप्त पानी/तरल लेते रहें और शरीर को ठंडा रखें।\n"
                "• चक्कर, कमजोरी, सिरदर्द, उलझन या असामान्य थकान जैसे "
                "heat-illness संकेतों को गंभीरता से लें।\n"
                "• अस्वस्थ महसूस होने पर तुरंत ठंडी जगह जाएँ और "
                "स्वास्थ्यकर्मी से सहायता लें।"
            )
        else:
            targeted = (
                "\n\n**Pregnancy-specific heat precautions:**\n"
                "• Avoid peak afternoon heat and direct sun.\n"
                "• Drink fluids regularly and stay cool and well ventilated.\n"
                "• Take dizziness, weakness, headache, confusion, or "
                "unusual fatigue seriously.\n"
                "• If feeling unwell, move to a cool place and seek "
                "medical support when needed."
            )

        recommendation = f"{recommendation}{targeted}"

    # ---------------------------------------------------------------
    # Infants
    # ---------------------------------------------------------------
    elif audience_key in {"infants", "infant", "baby", "babies"}:
        if language == "hi":
            targeted = (
                "\n\n**शिशुओं के लिए विशेष सावधानी:**\n"
                "• शिशु को सीधी धूप और बहुत गर्म वातावरण से दूर रखें।\n"
                "• कमरा ठंडा और हवादार रखें तथा peak heat में "
                "अनावश्यक बाहर जाना कम करें।\n"
                "• स्तनपान/feeding सामान्य रूप से जारी रखें और "
                "feeding या hydration में बदलाव पर ध्यान दें।\n"
                "• असामान्य सुस्ती, चिड़चिड़ापन, बहुत कम पेशाब, "
                "बहुत गर्म त्वचा या असामान्य व्यवहार दिखे तो तुरंत "
                "स्वास्थ्यकर्मी से संपर्क करें।"
            )
        else:
            targeted = (
                "\n\n**Infant-specific heat precautions:**\n"
                "• Keep infants out of direct sun and very hot environments.\n"
                "• Keep the room cool and well ventilated and limit "
                "non-essential outdoor exposure during peak heat.\n"
                "• Continue normal breastfeeding/feeding and watch for "
                "changes in feeding or hydration.\n"
                "• Seek medical help promptly for unusual sleepiness, "
                "irritability, markedly reduced urination, very hot skin, "
                "or unusual behaviour."
            )

        recommendation = f"{recommendation}{targeted}"

    if role_specific_note:
        recommendation = f"{recommendation}\n\n_{role_specific_note}_"

    return recommendation


# --------------------------------------------------------------------
# Supporting infrastructure (hospitals / cooling centres / water points)
# --------------------------------------------------------------------
@st.cache_data(show_spinner=False)
def get_hospitals() -> pd.DataFrame:
    return pd.read_csv(os.path.join(DATA_DIR, "hospitals.csv"))


@st.cache_data(show_spinner=False)
def get_cooling_centres() -> pd.DataFrame:
    return pd.read_csv(os.path.join(DATA_DIR, "cooling_centres.csv"))


@st.cache_data(show_spinner=False)
def get_water_points() -> pd.DataFrame:
    return pd.read_csv(os.path.join(DATA_DIR, "water_points.csv"))


# --------------------------------------------------------------------
# Aggregate KPIs for main dashboard
# --------------------------------------------------------------------
def get_dashboard_kpis(scenario_boost: float = 0.0) -> dict:
    df = get_map_risk(scenario_boost=scenario_boost)
    high_risk_mask = df["risk_key"].isin(["red", "extreme"])
    high_risk_cities = df.loc[high_risk_mask, "city"].nunique()
    vulnerable_population = int(df.loc[high_risk_mask, "population"].sum())
    top_row = df.sort_values("health_risk", ascending=False).iloc[0]

    return {
        "avg_health_risk": round(df["health_risk"].mean(), 0),
        "avg_thermal_stress": round(df["htss"].mean(), 0),
        "high_risk_areas": int(high_risk_cities) if high_risk_cities else int((df["risk_key"].isin(["orange", "red", "extreme"])).sum()),
        "vulnerable_population": vulnerable_population if vulnerable_population > 0 else int(df["population"].sum() * 0.15),
        "top_location": f"{top_row['city']} — {top_row['ward_name']}",
        "top_risk_score": top_row["health_risk"],
    }
