# 🛡️ HeatShield India

### Localized Human Thermal Stress & Heat Health Early Warning System

A hackathon-grade, full-stack **Python + Streamlit** decision-support platform that
turns weather forecasts into localized, vulnerability-aware **heat-health risk**
scores and actionable alerts — for citizens, outdoor workers, hospitals, schools,
employers, and government authorities.

```text
WEATHER FORECAST → THERMAL STRESS → VULNERABILITY → HEALTH RISK → ALERT → ACTION
```

---

## 1. Problem

Public heat warnings usually communicate a single number — air temperature.
But two places at the same temperature can pose very different danger to
people, depending on humidity, wind, solar exposure, and who lives there
(elderly population, outdoor workers, green cover, healthcare access).

## 2. Solution

HeatShield India computes a transparent **Human Thermal Stress Score (HTSS)**,
combines it with a ward-level **Vulnerability Score**, and produces a single
**Heat Health Risk** score (0–100) with a clear risk level, root-cause drivers,
peak-risk window, and role-specific recommended actions — in English and Hindi.

---

## 3. Features

- ✅ Animated, hackathon-quality Streamlit UI (loading sequence, KPI counters,
  circular gauges, pulsing alerts, animated pipeline)
- ✅ Interactive Folium GIS risk map with hospitals / cooling centres / water points
- ✅ 5-day hourly forecast with peak-risk detection
- ✅ Explainable Thermal Stress + Vulnerability + Health Risk engines
- ✅ Role-specific alerts (Citizen, Outdoor Worker, Hospital, School, Authority, Employer)
- ✅ English + Hindi (architecture supports more languages)
- ✅ Authority command-centre dashboard with priority actions
- ✅ "Run Extreme Heat Scenario" animated demo mode
- ✅ Fully offline-first — works with zero internet connection
- ✅ API-ready backend service layer (easy to port to FastAPI)
- ✅ Optional explainable ML layer (RandomForest, not a black box)

---

## 4. Tech Stack

```text
Python 3.11+
Streamlit
Plotly
Folium / streamlit-folium
Pandas / NumPy
scikit-learn (optional ML layer)
```

No React/Vue/Node frontend — the UI is 100% Python + Streamlit.

---

## 5. Project Structure

```text
HeatShield-India/
├── app.py                      # Streamlit UI orchestrator (routes to pages)
├── requirements.txt
├── README.md
├── .gitignore
│
├── frontend/                   # Presentation layer only — no formulas here
│   ├── styles.py                # Global CSS / design system
│   ├── components.py            # Cards, badges, panels, driver chips
│   ├── animations.py            # Startup sequence, counters, gauges, pipeline
│   ├── charts.py                 # Plotly chart builders
│   ├── maps.py                   # Folium risk map builder
│   └── ui_helpers.py             # Session state, sidebar, selectors
│
├── backend/                    # All business logic / formulas
│   ├── weather_service.py        # Offline-first weather provider (Mock + OpenMeteo)
│   ├── thermal_engine.py          # HTSS calculation
│   ├── vulnerability_engine.py    # Vulnerability scoring
│   ├── risk_engine.py             # Health Risk scoring + peak detection
│   ├── alert_engine.py            # Risk -> Alert conversion
│   ├── recommendation_engine.py   # Role + language aware recommendations
│   ├── forecast_service.py        # Hourly forecast + confidence scoring
│   └── api_service.py             # API-style service layer (single entry point)
│
├── models/
│   └── risk_model.py             # Optional explainable ML layer (RandomForest)
│
├── utils/
│   ├── constants.py               # ALL thresholds, weights, colors, labels
│   ├── translations.py            # English + Hindi dictionary
│   ├── validators.py              # Data quality engine + confidence score
│   └── helpers.py                 # Shared small utilities
│
├── data/                        # Offline demo datasets (regeneratable)
│   ├── generate_demo_data.py
│   ├── locations.csv
│   ├── weather.csv
│   ├── forecast.csv
│   ├── vulnerability.csv
│   ├── hospitals.csv
│   ├── cooling_centres.csv
│   └── water_points.csv
│
└── .streamlit/
    └── config.toml
```

---

## 6. Installation & Running

### Windows (VS Code / PyCharm)

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

### macOS / Linux (VS Code / PyCharm)

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

### VS Code setup

1. Open the `HeatShield-India` folder in VS Code.
2. `Ctrl+Shift+P` → "Python: Select Interpreter" → choose `.venv`.
3. Open the integrated terminal and activate the environment (see above).
4. `pip install -r requirements.txt`
5. `streamlit run app.py`

### PyCharm setup

1. Open `HeatShield-India` as a PyCharm project.
2. Settings → Project → Python Interpreter → select/create `.venv`.
3. Open the PyCharm terminal.
4. `pip install -r requirements.txt`
5. `streamlit run app.py`

The app opens automatically at **http://localhost:8501**.

---

## 7. Regenerating Demo Data (optional)

The repository ships with pre-generated CSVs, but you can regenerate them:

```bash
python data/generate_demo_data.py
```

This creates realistic ward-level data for Nagpur, Delhi, Ahmedabad, Chennai,
Hyderabad, and Jaipur — weather, demographics, hospitals, cooling centres, and
water points.

---

## 8. Risk Methodology

### Human Thermal Stress Score (HTSS)

```text
HTSS = 0.40(Tn) + 0.25(Hn) + 0.15(Rn) + 0.10(Ln) + 0.10(Dn)
```

| Term | Meaning |
|------|---------|
| Tn | Normalized temperature risk |
| Hn | Normalized humidity risk (scaled by temperature) |
| Rn | Normalized solar radiation risk |
| Ln | Low-wind risk |
| Dn | Consecutive-hot-days / night-recovery risk |

Categories: LOW (0–25) · MODERATE (26–50) · HIGH (51–70) · VERY HIGH (71–85) · EXTREME (86–100)

> HTSS is a transparent **prototype index** inspired by concepts used in the
> Universal Thermal Climate Index (UTCI). It is **not** an official government
> index and has not been clinically validated.

### Vulnerability Score

```text
Vulnerability = 0.30·Elderly% + 0.25·PopDensity + 0.20·OutdoorWorker%
              + 0.15·(LowGreenCover) + 0.10·(PoorHealthcareAccess)
```

### Heat Health Risk (primary model)

```text
Heat Health Risk = 0.65 × Thermal Stress + 0.35 × Vulnerability
```

Levels: GREEN (0–25) · YELLOW (26–50) · ORANGE (51–70) · RED (71–85) · EXTREME (86–100)

An **extended model** (Thermal Stress 50% / Vulnerability 20% / Exposure 15% /
Urban Heat Island 10% / Healthcare Accessibility 5%) is documented in
`utils/constants.py` for future extension, but is not mixed with the primary
model at runtime.

---

## 9. API Architecture

`backend/api_service.py` exposes functions that map 1:1 onto a future REST API:

```text
GET  /api/locations
GET  /api/locations/{id}/current-risk
GET  /api/locations/{id}/forecast?days=5
GET  /api/map/risk?time=...
GET  /api/alerts?district=...
GET  /api/vulnerability?district=...
POST /api/admin/weather-ingestion
POST /api/admin/generate-alerts
```

Migrating to FastAPI later means wrapping each function with a route decorator
— no business-logic rewrite required.

---

## 10. Demo Scenario — "Run Extreme Heat Scenario"

The sidebar button intensifies weather inputs (higher temperature/humidity,
lower wind, higher radiation) across all locations, recalculates every engine
in real time, highlights high-risk wards on the map, regenerates alerts, and
updates the Authority Dashboard — without touching the underlying data files.

---

## 11. Limitations

- All weather, demographic, and forecast data in this build are **simulated**
  for demonstration purposes (see the in-app "DEMO MODE" banner).
- HTSS is a transparent prototype, not an official UTCI implementation.
- The optional ML layer (`models/risk_model.py`) is trained on simulated data
  with a heuristic label — it does not predict real health outcomes.
- Live weather (Open-Meteo) integration is optional and best-effort; the app
  always falls back to offline demo data if the API is unavailable.

## 12. Future Improvements

- Real weather ingestion pipeline (IMD / Open-Meteo) with historical validation
- PostgreSQL + PostGIS backend for spatial queries at scale
- FastAPI service layer for external integrations
- Validated ML model trained on real heat-illness surveillance data
- Full translation coverage for all 8 listed Indian languages
- SMS / WhatsApp alert delivery integration

---

## 13. Disclaimer

HeatShield India is a **prototype decision-support tool** built for hackathon
demonstration. It is not an official government early-warning system and
should not be used as the sole basis for emergency response decisions.
