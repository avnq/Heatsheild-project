self.addEventListener('install', (event) => {
    self.skipWaiting();
});

self.addEventListener('activate', (event) => {
    event.waitUntil(self.clients.claim());
});

self.addEventListener('push', (event) => {
    const data = event.data ? event.data.json() : {};
    const title = data.title || "🚨 Heatwave Alert!";
    const options = {
        body: data.body || "Elevated thermal stress detected near your area.",
        icon: "https://img.icons8.com/fluency/192/fire-element.png",
        badge: "https://img.icons8.com/fluency/96/shield.png",
        vibrate: [200, 100, 200],
        data: { url: "/" }
    };
    event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', (event) => {
    event.notification.close();
    event.waitUntil(
        clients.openWindow(event.notification.data.url)
    );
});