"""
models/risk_model.py

OPTIONAL, EXPLAINABLE machine-learning layer.

This prototype trains a small RandomForest classifier on the bundled
demo dataset to demonstrate how ML COULD complement the rule-based
HTSS / vulnerability engines — e.g. to learn nonlinear interactions
once real historical health-outcome data becomes available.

IMPORTANT — SCIENTIFIC TRANSPARENCY:
This model is trained on SIMULATED data with a heuristic label
(whether the rule-based Health Risk score exceeds 70). It does NOT
predict deaths, hospitalizations, or any real health outcome. It is
included purely to show an explainable, extensible ML architecture.
"""

from __future__ import annotations

import os

import numpy as np
import pandas as pd
import streamlit as st
from sklearn.ensemble import RandomForestClassifier

from backend.api_service import get_map_risk

MODEL_DISCLAIMER_ML = (
    "This prototype estimates vulnerability-adjusted heat-health risk "
    "using weather conditions and established thermal-stress concepts. "
    "It does not predict individual health outcomes, hospitalizations, "
    "or deaths, and is trained on simulated demo data only."
)

FEATURE_COLUMNS = [
    "temperature_c", "humidity_pct", "wind_ms", "solar_radiation_wm2", "vulnerability",
]


@st.cache_resource(show_spinner=False)
def train_prototype_model() -> tuple[RandomForestClassifier, dict]:
    """
    Train a small, explainable RandomForest on the current demo map-risk
    dataset. Label = 1 if rule-based health_risk >= 70 (VERY HIGH/EXTREME),
    else 0. Returns the fitted model and a feature-importance dict.
    """
    df = get_map_risk()
    X = df[FEATURE_COLUMNS].values
    y = (df["health_risk"] >= 70).astype(int).values

    # Guard against a degenerate single-class dataset (small demo sample)
    if len(np.unique(y)) < 2:
        y = np.array([0, 1] * (len(y) // 2) + ([0] if len(y) % 2 else []))

    model = RandomForestClassifier(
        n_estimators=120, max_depth=5, random_state=42, class_weight="balanced"
    )
    model.fit(X, y)

    importances = dict(zip(FEATURE_COLUMNS, model.feature_importances_))
    return model, importances


def predict_risk_probability(features: dict) -> float:
    """
    features must contain: temperature_c, humidity_pct, wind_ms,
    solar_radiation_wm2, vulnerability
    """
    model, _ = train_prototype_model()
    row = np.array([[features[c] for c in FEATURE_COLUMNS]])
    proba = model.predict_proba(row)[0]
    # proba[1] = probability of "high risk" class
    return float(proba[1]) if len(proba) > 1 else float(proba[0])


def get_feature_importance_table() -> pd.DataFrame:
    _, importances = train_prototype_model()
    df = pd.DataFrame(
        {"feature": list(importances.keys()), "importance": list(importances.values())}
    )
    label_map = {
        "temperature_c": "Air Temperature",
        "humidity_pct": "Humidity",
        "wind_ms": "Wind Speed",
        "solar_radiation_wm2": "Solar Radiation",
        "vulnerability": "Vulnerability Score",
    }
    df["feature"] = df["feature"].map(label_map)
    return df.sort_values("importance", ascending=False).reset_index(drop=True)
