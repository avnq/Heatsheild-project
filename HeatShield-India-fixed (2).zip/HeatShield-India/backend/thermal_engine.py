"""
backend/thermal_engine.py

Human Thermal Stress Score (HTSS) engine.

HTSS is a transparent, explainable PROTOTYPE index inspired by concepts
used in the Universal Thermal Climate Index (UTCI): air temperature,
humidity, mean radiant / solar exposure, wind speed, and sustained-heat
(duration) effects. It is NOT a full UTCI implementation and is never
represented as an official government index (see utils/constants.py
HTSS_DISCLAIMER).

    HTSS = 0.40(Tn) + 0.25(Hn) + 0.15(Rn) + 0.10(Ln) + 0.10(Dn)
"""

from __future__ import annotations

from dataclasses import dataclass, field

from utils.constants import (
    HTSS_WEIGHTS,
    HTSS_CATEGORIES,
    TEMP_MIN_C,
    TEMP_MAX_C,
    HUMIDITY_MIN,
    HUMIDITY_MAX,
    RADIATION_MIN,
    RADIATION_MAX,
    WIND_LOW_THRESHOLD,
    MAX_CONSECUTIVE_HOT_DAYS,
)
from utils.helpers import normalize, clamp, category_for_score


@dataclass
class ThermalStressResult:
    htss: float
    category: dict
    components: dict = field(default_factory=dict)
    inputs: dict = field(default_factory=dict)


def _temperature_risk(temp_c: float) -> float:
    """Higher temperature => higher normalized risk (0-100)."""
    return normalize(temp_c, TEMP_MIN_C, TEMP_MAX_C)


def _humidity_risk(humidity_pct: float, temp_c: float) -> float:
    """
    Humidity risk rises sharply when combined with high temperature
    (reduced evaporative cooling). We scale the normalized humidity by
    a temperature-dependent factor so that high humidity at low
    temperature contributes little risk.
    """
    base = normalize(humidity_pct, HUMIDITY_MIN, HUMIDITY_MAX)
    temp_factor = clamp(normalize(temp_c, 25.0, 42.0) / 100.0, 0.2, 1.0)
    return clamp(base * temp_factor)


def _radiation_risk(radiation_wm2: float) -> float:
    return normalize(radiation_wm2, RADIATION_MIN, RADIATION_MAX)


def _low_wind_risk(wind_ms: float) -> float:
    """
    Wind speeds below WIND_LOW_THRESHOLD reduce the body's convective
    cooling ability. Risk is 100 at ~0 m/s and decays to 0 at/above the
    threshold.
    """
    if wind_ms >= WIND_LOW_THRESHOLD:
        return 0.0
    deficit = WIND_LOW_THRESHOLD - wind_ms
    return clamp(normalize(deficit, 0.0, WIND_LOW_THRESHOLD))


def _duration_risk(consecutive_hot_days: int, night_recovery_temp_c: float | None = None) -> float:
    """
    Sustained heat (several consecutive hot days) and poor nighttime
    cooling both reduce the body's ability to recover. We combine both
    signals into a single 0-100 duration-risk score.
    """
    day_component = normalize(
        min(consecutive_hot_days, MAX_CONSECUTIVE_HOT_DAYS), 0, MAX_CONSECUTIVE_HOT_DAYS
    )
    if night_recovery_temp_c is None:
        return day_component
    # Poor recovery: night temp stays high (>28C) -> extra risk
    night_component = normalize(night_recovery_temp_c, 22.0, 32.0)
    return clamp(0.6 * day_component + 0.4 * night_component)


def calculate_htss(
    temperature_c: float,
    humidity_pct: float,
    wind_ms: float,
    solar_radiation_wm2: float,
    consecutive_hot_days: int = 1,
    night_recovery_temp_c: float | None = None,
) -> ThermalStressResult:
    """Compute the full HTSS breakdown for one weather observation."""

    tn = _temperature_risk(temperature_c)
    hn = _humidity_risk(humidity_pct, temperature_c)
    rn = _radiation_risk(solar_radiation_wm2)
    ln = _low_wind_risk(wind_ms)
    dn = _duration_risk(consecutive_hot_days, night_recovery_temp_c)

    htss = (
        HTSS_WEIGHTS["temperature"] * tn
        + HTSS_WEIGHTS["humidity"] * hn
        + HTSS_WEIGHTS["radiation"] * rn
        + HTSS_WEIGHTS["wind"] * ln
        + HTSS_WEIGHTS["duration"] * dn
    )
    htss = clamp(htss)
    category = category_for_score(htss, HTSS_CATEGORIES)

    components = {
        "temperature_contribution": round(HTSS_WEIGHTS["temperature"] * tn, 1),
        "humidity_contribution": round(HTSS_WEIGHTS["humidity"] * hn, 1),
        "radiation_contribution": round(HTSS_WEIGHTS["radiation"] * rn, 1),
        "wind_contribution": round(HTSS_WEIGHTS["wind"] * ln, 1),
        "duration_contribution": round(HTSS_WEIGHTS["duration"] * dn, 1),
        "raw_temperature_risk": round(tn, 1),
        "raw_humidity_risk": round(hn, 1),
        "raw_radiation_risk": round(rn, 1),
        "raw_wind_risk": round(ln, 1),
        "raw_duration_risk": round(dn, 1),
    }

    inputs = {
        "temperature_c": temperature_c,
        "humidity_pct": humidity_pct,
        "wind_ms": wind_ms,
        "solar_radiation_wm2": solar_radiation_wm2,
        "consecutive_hot_days": consecutive_hot_days,
        "night_recovery_temp_c": night_recovery_temp_c,
    }

    return ThermalStressResult(
        htss=round(htss, 1), category=category, components=components, inputs=inputs
    )


def top_drivers(result: ThermalStressResult, n: int = 5) -> list[str]:
    """Human-readable ranked list of what is driving the thermal stress."""
    labels = {
        "temperature_contribution": "High air temperature",
        "humidity_contribution": "High humidity",
        "radiation_contribution": "Intense solar radiation",
        "wind_contribution": "Low wind speed",
        "duration_contribution": "Prolonged heat / poor night recovery",
    }
    ranked = sorted(
        result.components.items(),
        key=lambda kv: kv[1] if kv[0] in labels else -1,
        reverse=True,
    )
    drivers = [labels[k] for k, v in ranked if k in labels and v > 0]
    return drivers[:n] if drivers else ["Moderate weather conditions"]
