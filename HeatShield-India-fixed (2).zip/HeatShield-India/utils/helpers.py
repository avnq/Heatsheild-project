"""
utils/helpers.py

Small shared utility functions used across backend and frontend layers.
"""

from __future__ import annotations

from datetime import datetime, timedelta
import math

import pandas as pd


def clamp(value: float, lo: float = 0.0, hi: float = 100.0) -> float:
    """Clamp a numeric value into [lo, hi]."""
    return max(lo, min(hi, value))


def normalize(value: float, min_val: float, max_val: float) -> float:
    """Linearly normalize `value` into 0-100 given a reference range."""
    if max_val == min_val:
        return 0.0
    ratio = (value - min_val) / (max_val - min_val)
    return clamp(ratio * 100.0, 0.0, 100.0)


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Great-circle distance between two lat/lon points, in kilometres."""
    r = 6371.0
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def idw_interpolate(
    lat: float,
    lon: float,
    reference_df: pd.DataFrame,
    value_columns: list[str],
    lat_col: str = "lat",
    lon_col: str = "lon",
    power: float = 2.0,
    exact_match_km: float = 0.05,
) -> dict:
    """
    Inverse-distance-weighted estimate of `value_columns` at (lat, lon),
    using every row of `reference_df` as a known reference point.

    Nearby reference points dominate the estimate; points in a different
    part of the city (or a different city entirely) contribute almost
    nothing, so two different exact coordinates get two different,
    location-sensitive estimates instead of both being handed an identical
    copy of whichever single reference point happens to be "nearest".

    This is still an ESTIMATE, not real per-address data — this prototype
    only ships a handful of reference points per city, so accuracy is
    bounded by how many/how well-spread those reference points are. If a
    reference point is at (or essentially at) the query coordinates, its
    own real values are returned directly instead of a blended estimate.
    """
    distances = reference_df.apply(
        lambda row: haversine_km(lat, lon, row[lat_col], row[lon_col]), axis=1
    )
    min_idx = distances.idxmin()
    if distances.loc[min_idx] <= exact_match_km:
        return {col: float(reference_df.loc[min_idx, col]) for col in value_columns}

    weights = 1.0 / (distances ** power)
    weights = weights / weights.sum()

    return {col: float((reference_df[col] * weights).sum()) for col in value_columns}


def now_ist() -> datetime:
    """Return current time shifted to IST (UTC+5:30) without external deps."""
    return datetime.utcnow() + timedelta(hours=5, minutes=30)


def format_ist_timestamp(dt: datetime | None = None) -> str:
    dt = dt or now_ist()
    return dt.strftime("%d %B %Y | %H:%M IST")


def category_for_score(score: float, categories: list[dict]) -> dict:
    """Return the matching category dict for a 0-100 score."""
    score = clamp(score)
    for cat in categories:
        if cat["min"] <= score <= cat["max"]:
            return cat
    return categories[-1]


def safe_round(value: float, ndigits: int = 0):
    try:
        return round(float(value), ndigits)
    except (TypeError, ValueError):
        return value


def sinusoidal_daily_curve(base: float, amplitude: float, hour: float, peak_hour: float = 14.0) -> float:
    """
    Generate a smooth 24h sinusoidal curve peaking at `peak_hour`
    (used to simulate temperature / radiation diurnal cycles).
    """
    radians = 2 * math.pi * (hour - (peak_hour - 6)) / 24
    return base + amplitude * math.sin(radians)


def build_hourly_index(start: datetime, hours: int) -> list[datetime]:
    return [start + timedelta(hours=i) for i in range(hours)]


def df_or_empty(df: pd.DataFrame | None) -> pd.DataFrame:
    return df if df is not None else pd.DataFrame()


def heat_index_c(temp_c: float, humidity_pct: float, wind_ms: float = 2.0) -> float:
    """
    'Feels like' apparent temperature (AT), using the Australian Bureau of
    Meteorology's outdoor apparent-temperature formula:

        AT = Ta + 0.33*e - 0.70*ws - 4.00
        e  = (RH/100) * 6.105 * exp(17.27*Ta / (237.7+Ta))   [vapour pressure, hPa]

    Chosen over the NWS Rothfusz regression because that regression is a
    curve fit only valid over a narrow band (~27-43C) and produces wildly
    unrealistic values when extrapolated to the 45C+ range this dataset
    covers. This formula stays numerically well-behaved at high heat.
    """
    t, r, ws = float(temp_c), float(humidity_pct), float(wind_ms)
    vapour_pressure = (r / 100.0) * 6.105 * math.exp((17.27 * t) / (237.7 + t))
    at = t + 0.33 * vapour_pressure - 0.70 * ws - 4.00
    return round(at, 1)


def heat_feel_label(temp_max_c: float) -> str:
    """Human-readable heat descriptor for a day's max temperature (India context)."""
    if temp_max_c >= 42:
        return "Extreme Heat"
    if temp_max_c >= 38:
        return "Very Hot"
    if temp_max_c >= 33:
        return "Hot"
    if temp_max_c >= 28:
        return "Warm"
    return "Mild"


def sky_condition_from_solar(avg_daytime_solar_wm2: float) -> tuple[str, str]:
    """
    Approximate a sky-condition label + emoji from average daytime solar
    radiation (the only cloud-cover proxy available in the demo dataset).
    Not a substitute for real satellite/cloud-cover or precipitation data.
    """
    if avg_daytime_solar_wm2 >= 650:
        return "Clear / Sunny", "☀️"
    if avg_daytime_solar_wm2 >= 400:
        return "Partly Cloudy", "⛅"
    return "Cloudy / Hazy", "☁️"
