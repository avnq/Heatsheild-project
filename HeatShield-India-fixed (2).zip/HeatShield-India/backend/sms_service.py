"""
backend/sms_service.py
Pure Demo SMS Dispatcher for HeatShield India.
"""

def send_heat_alert_sms(
    phone: str,
    user_name: str,
    city: str,
    risk_score: float,
    level_label: str,
) -> dict:
    clean_phone = "".join(filter(str.isdigit, str(phone)))[-10:]
    
    return {
        "phone": f"+91{clean_phone}",
        "status": "sent",
        "body": f"HEATSHIELD ALERT: {city} is under {level_label} Heat Stress.",
        "error": None,
    }