"""
frontend/login.py

Aesthetic Crystal Aqua & Ocean Teal Portal matching bg.png palette:
- Matches the background image's Cyan, Aquamarine, and Soft Sage-Green tones
- Seamless glassmorphic translucent panels
- Glowing Cyan & Emerald Health-Shield hero graphic
"""

from __future__ import annotations
import base64
from pathlib import Path
import re
import streamlit as st
import streamlit.components.v1 as components


def _load_bg_base64() -> str:
    base_dir = Path(__file__).resolve().parent
    project_root = base_dir.parent

    candidate_paths = [
        base_dir / "assets" / "bg.png",
        base_dir / "bg.png",
        project_root / "assets" / "bg.png",
        project_root / "frontend" / "assets" / "bg.png",
        project_root / "bg.png",
        Path.cwd() / "assets" / "bg.png",
        Path.cwd() / "bg.png",
    ]

    for p in candidate_paths:
        if p.is_file():
            with open(p, "rb") as f:
                return f"data:image/png;base64,{base64.b64encode(f.read()).decode()}"
    return ""


def _is_valid_phone(phone: str) -> bool:
    cleaned = re.sub(r"\D", "", phone)
    return len(cleaned) == 10


def _is_valid_email(email: str) -> bool:
    pattern = r"^[\w\.-]+@[\w\.-]+\.\w+$"
    return bool(re.match(pattern, email.strip()))


def render_login_page() -> bool:
    is_dark = st.session_state.get("theme", "light") == "dark"

    text_primary = "#0B2B26" if not is_dark else "#F0FDF4"
    text_secondary = "#2D6A5F" if not is_dark else "#A7F3D0"

    bg_data = _load_bg_base64()

    if bg_data:
        bg_css = f"""
        .stApp, [data-testid="stAppViewContainer"], [data-testid="stHeader"] {{
            background-image: url("{bg_data}") !important;
            background-size: cover !important;
            background-position: center center !important;
            background-repeat: no-repeat !important;
            background-attachment: fixed !important;
            background-color: transparent !important;
        }}
        """
    else:
        bg_css = """
        .stApp {{
            background: radial-gradient(circle at 10% 15%, #EBF4F6 0%, #E3F2F1 50%, #D8ECE8 100%) !important;
        }}
        """

    # Head styles injection for BaseWeb inputs & dropdowns
    components.html(
        """
        <script>
        function enforceLoginStyles() {
            try {
                const doc = window.parent.document;
                let styleTag = doc.getElementById('force-login-aqua-styles');
                if (!styleTag) {
                    styleTag = doc.createElement('style');
                    styleTag.id = 'force-login-aqua-styles';
                    styleTag.innerHTML = `
                        /* Input boxes */
                        div[data-testid="stTextInput"] div[data-baseweb="input"],
                        div[data-testid="stTextInput"] div[data-baseweb="base-input"] {
                            background-color: rgba(255, 255, 255, 0.94) !important;
                            background: rgba(255, 255, 255, 0.94) !important;
                            border: 1.6px solid #CBD5E1 !important;
                            border-radius: 16px !important;
                        }

                        div[data-testid="stTextInput"] input {
                            color: #0B2B26 !important;
                            -webkit-text-fill-color: #0B2B26 !important;
                            font-weight: 600 !important;
                        }

                        div[data-testid="stTextInput"] button svg {
                            fill: #0D9488 !important;
                            stroke: #0D9488 !important;
                        }

                        /* Dropdown Popover */
                        div[data-baseweb="popover"],
                        div[data-baseweb="popover"] > div,
                        ul[role="listbox"] {
                            background: #ffffff !important;
                            background-color: #ffffff !important;
                            border: 1.5px solid #A7F3D0 !important;
                            border-radius: 16px !important;
                            box-shadow: 0 18px 40px rgba(13, 148, 136, 0.14) !important;
                        }
                        div[data-baseweb="popover"] li,
                        div[data-baseweb="popover"] li * {
                            color: #0B2B26 !important;
                            -webkit-text-fill-color: #0B2B26 !important;
                            font-weight: 700 !important;
                        }
                    `;
                    doc.head.appendChild(styleTag);
                }
            } catch (err) {
                console.error(err);
            }
        }
        setInterval(enforceLoginStyles, 150);
        </script>
        """,
        height=0,
        width=0,
    )

    st.markdown(
        f"""
<style>
{bg_css}

.block-container {{
    max-width: 1260px !important;
    padding-top: 1.8rem !important;
    padding-bottom: 2.2rem !important;
    background: transparent !important;
}}

.exact-heading {{
    font-size: 2.6rem;
    font-weight: 900;
    color: {text_primary};
    letter-spacing: -0.03em;
    line-height: 1.05;
    margin-bottom: 4px;
}}
.exact-subheading {{
    font-size: 0.88rem;
    font-weight: 600;
    color: {text_secondary};
    margin-bottom: 24px;
}}

.step-header {{
    font-size: 0.78rem;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: #0D9488;
    margin-top: 18px;
    margin-bottom: 8px;
}}

/* Radio Pills */
div[data-testid="stRadio"] > div {{
    display: flex !important;
    flex-direction: row !important;
    gap: 14px !important;
    width: 100% !important;
}}

div[data-testid="stRadio"] label {{
    flex: 1 1 0 !important;
    display: flex !important;
    align-items: center !important;
    justify-content: flex-start !important;
    gap: 10px !important;
    background: rgba(255, 255, 255, 0.90) !important;
    border: 1.6px solid rgba(203, 213, 225, 0.85) !important;
    border-radius: 16px !important;
    padding: 12px 18px !important;
    min-height: 52px !important;
    backdrop-filter: blur(10px) !important;
    box-shadow: 0 4px 14px rgba(13, 148, 136, 0.05) !important;
    cursor: pointer !important;
    white-space: nowrap !important;
}}

div[data-testid="stRadio"] label p,
div[data-testid="stRadio"] label span,
div[data-testid="stRadio"] label div {{
    font-weight: 700 !important;
    font-size: 0.95rem !important;
    color: #0B2B26 !important;
    -webkit-text-fill-color: #0B2B26 !important;
    line-height: 1 !important;
    display: inline-flex !important;
    align-items: center !important;
    gap: 8px !important;
    white-space: nowrap !important;
}}

div[data-testid="stRadio"] label[data-checked="true"],
div[data-testid="stRadio"] label:has(input:checked) {{
    background: rgba(240, 253, 250, 0.96) !important;
    border-color: #0D9488 !important;
    box-shadow: 0 6px 20px rgba(13, 148, 136, 0.16) !important;
}}

div[data-testid="stRadio"] label:has(input:checked) p,
div[data-testid="stRadio"] label:has(input:checked) span,
div[data-testid="stRadio"] label:has(input:checked) div {{
    color: #0F766E !important;
    -webkit-text-fill-color: #0F766E !important;
}}

/* Input Box */
div[data-testid="stTextInput"],
div[data-testid="stTextInput"] > div,
div[data-testid="stTextInput"] > div > div,
div[data-testid="stTextInput"] div[data-baseweb="base-input"],
div[data-testid="stTextInput"] div[data-baseweb="input"] {{
    background-color: rgba(255, 255, 255, 0.94) !important;
    background: rgba(255, 255, 255, 0.94) !important;
    border-radius: 16px !important;
}}

div[data-testid="stTextInput"] div[data-baseweb="input"] {{
    border: 1.6px solid rgba(203, 213, 225, 0.85) !important;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.04) !important;
    backdrop-filter: blur(8px) !important;
}}

div[data-testid="stTextInput"] div[data-baseweb="input"]:focus-within {{
    border-color: #0D9488 !important;
    box-shadow: 0 0 0 4px rgba(13, 148, 136, 0.16) !important;
}}

div[data-testid="stTextInput"] input {{
    background-color: transparent !important;
    color: #0B2B26 !important;
    -webkit-text-fill-color: #0B2B26 !important;
    height: 48px !important;
    font-size: 0.96rem !important;
    font-weight: 600 !important;
    border: none !important;
    padding-left: 16px !important;
}}

div[data-testid="stTextInput"] input::placeholder {{
    color: #64748B !important;
    -webkit-text-fill-color: #64748B !important;
}}

div[data-testid="stTextInput"] button {{
    background: transparent !important;
    border: none !important;
    margin-right: 6px !important;
}}
div[data-testid="stTextInput"] button svg {{
    fill: #0D9488 !important;
    stroke: #0D9488 !important;
}}

/* Selectbox */
div[data-baseweb="select"] > div {{
    background-color: rgba(255, 255, 255, 0.94) !important;
    border-radius: 16px !important;
    border: 1.6px solid rgba(203, 213, 225, 0.85) !important;
    height: 48px !important;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.04) !important;
    backdrop-filter: blur(8px) !important;
    color: #0B2B26 !important;
}}
div[data-baseweb="select"] span,
div[data-baseweb="select"] div {{
    color: #0B2B26 !important;
    -webkit-text-fill-color: #0B2B26 !important;
    font-weight: 700 !important;
}}

/* Ocean-Teal Primary Button */
button[kind="primary"] {{
    background: linear-gradient(135deg, #0284C7 0%, #0D9488 60%, #059669 100%) !important;
    border: none !important;
    border-radius: 18px !important;
    height: 52px !important;
    font-size: 1.05rem !important;
    font-weight: 800 !important;
    letter-spacing: -0.01em !important;
    color: #FFFFFF !important;
    box-shadow: 0 10px 26px rgba(13, 148, 136, 0.32) !important;
    transition: transform 0.15s ease, box-shadow 0.15s ease !important;
    margin-top: 10px !important;
}}
button[kind="primary"]:hover {{
    transform: translateY(-2px) !important;
    box-shadow: 0 14px 32px rgba(13, 148, 136, 0.42) !important;
}}

/* Right Artboard Glass Card */
.artboard-card {{
    position: relative;
    min-height: 640px;
    width: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    background: linear-gradient(150deg, rgba(255, 255, 255, 0.88) 0%, rgba(240, 253, 250, 0.80) 50%, rgba(230, 248, 245, 0.82) 100%);
    border-radius: 36px;
    border: 1.8px solid rgba(255, 255, 255, 0.95);
    padding: 46px 36px;
    text-align: center;
    backdrop-filter: blur(14px);
    -webkit-backdrop-filter: blur(14px);
    box-shadow: 0 28px 65px rgba(13, 148, 136, 0.12);
}}

.chip-heat {{
    position: absolute;
    top: 26px;
    left: 28px;
    background: rgba(255, 245, 242, 0.95);
    border: 1.5px solid #FDBA9B;
    color: #C2410C;
    padding: 8px 18px;
    border-radius: 20px;
    font-size: 0.82rem;
    font-weight: 800;
    box-shadow: 0 4px 14px rgba(194, 65, 12, 0.12);
}}

.trust-footer {{
    margin-top: 36px;
    padding-top: 22px;
    border-top: 1px solid rgba(204, 235, 227, 0.85);
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 16px;
}}
.trust-pill {{
    display: flex;
    align-items: center;
    gap: 12px;
    background: rgba(255, 255, 255, 0.82);
    padding: 6px 14px;
    border-radius: 20px;
    backdrop-filter: blur(8px);
    border: 1px solid rgba(203, 213, 225, 0.6);
}}
.trust-icon-circle {{
    width: 38px;
    height: 38px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.1rem;
}}
.trust-text-title {{
    font-size: 0.85rem;
    font-weight: 800;
    color: #0B2B26;
    line-height: 1.1;
}}
.trust-text-sub {{
    font-size: 0.72rem;
    font-weight: 600;
    color: #2D6A5F;
}}
</style>
""",
        unsafe_allow_html=True,
    )

    col_h1, col_h2 = st.columns([5, 1.4])
    with col_h1:
        st.markdown(
            """
            <div style="display:flex; align-items:center; gap:12px; margin-bottom:18px;">
                <svg width="40" height="40" viewBox="0 0 100 100" fill="none">
                    <path d="M50 12 L84 28 V60 C84 76 68 88 50 94 C32 88 16 76 16 60 V28 L50 12 Z" fill="#0D9488"/>
                    <path d="M50 24 L74 36 V58 C74 70 62 79 50 84 C38 79 26 70 26 58 V36 L50 24 Z" fill="#38BDF8"/>
                    <path d="M38 52 L45 52 L48 44 L53 60 L57 48 L59 52 L64 52" stroke="#FFFFFF" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                <div>
                    <div style="font-size:1.5rem; font-weight:900; color:#0A352C; line-height:1.1;">HeatShield <span style="color:#0284C7;">India</span></div>
                    <div style="font-size:0.68rem; font-weight:800; color:#0D9488; letter-spacing:0.12em;">PEOPLE SAFER. A HEALTHIER TOMORROW.</div>
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    with col_h2:
        current_mode = st.session_state.get("theme", "light")
        sel_theme = st.selectbox(
            "Theme",
            ["Light Mode", "Dark Mode"],
            index=0 if current_mode == "light" else 1,
            key="login_theme_selector",
            label_visibility="collapsed",
        )
        mode = "light" if "Light" in sel_theme else "dark"
        if mode != st.session_state.get("theme"):
            st.session_state["theme"] = mode
            st.rerun()

    col_left, col_mid, col_right = st.columns([1.25, 0.06, 1.35])

    with col_left:
        st.markdown(
            f"""
            <div class="exact-heading">Sign In / Register</div>
            <div class="exact-subheading">Localized Human Thermal Stress Early Warning Decision Engine</div>
            """,
            unsafe_allow_html=True,
        )

        st.markdown("<p class='step-header'>1. SELECT IDENTITY TYPE</p>", unsafe_allow_html=True)
        user_type = st.radio(
            "Identity",
            ["👤 Citizen", "🏛️ Authority"],
            horizontal=True,
            key="auth_user_type_sel",
            label_visibility="collapsed",
        )
        is_authority = "Authority" in user_type

        full_name = ""
        user_email = ""
        phone = ""
        password = ""
        gender = None
        occupation = None

        if is_authority:
            st.markdown("<p class='step-header'>OFFICER NAME</p>", unsafe_allow_html=True)
            full_name = st.text_input("Name", placeholder="👤 Enter your full name...", key="auth_officer_name", label_visibility="collapsed")

            st.markdown("<p class='step-header'>OFFICIAL EMAIL ID</p>", unsafe_allow_html=True)
            user_email = st.text_input("Email", placeholder="✉️ officer@health.gov.in", key="auth_officer_email", label_visibility="collapsed")

        else:
            st.markdown("<p class='step-header'>2. SELECT GENDER / CATEGORY</p>", unsafe_allow_html=True)
            gender_choice = st.radio(
                "Gender",
                ["♂️ Male", "♀️ Female"],
                horizontal=True,
                key="auth_gender_sel",
                label_visibility="collapsed",
            )
            gender = "Male" if "Male" in gender_choice else "Female"

            st.markdown("<p class='step-header'>3. SELECT ACTIVITY / ROLE PROFILE</p>", unsafe_allow_html=True)
            if gender == "Male":
                occupation = st.selectbox(
                    "Role",
                    [
                        "🎓 Student",
                        "💼 Employee",
                        "👷 Outdoor Worker",
                        "🩺 Medical Staff",
                        "👴 Senior Citizen",
                        "🏠 Unemployed",
                    ],
                    key="auth_male_occ_sel",
                    label_visibility="collapsed",
                )
            else:
                occupation = st.selectbox(
                    "Role",
                    [
                        "🎓 Student",
                        "🤰 Pregnant Women",
                        "👵 Senior Citizen",
                        "💼 Employee",
                        "👷 Outdoor Worker",
                        "🩺 Medical Staff",
                        "🏠 Unemployed",
                    ],
                    key="auth_female_occ_sel",
                    label_visibility="collapsed",
                )

            st.markdown("<p class='step-header'>FULL NAME</p>", unsafe_allow_html=True)
            full_name = st.text_input("Name", placeholder="👤 Enter your full name...", key="auth_citizen_name_input", label_visibility="collapsed")

        st.markdown("<p class='step-header'>PHONE NUMBER (10 DIGITS)</p>", unsafe_allow_html=True)
        phone = st.text_input("Phone", placeholder="📞 9876543210", max_chars=10, key="auth_phone_input", label_visibility="collapsed")

        st.markdown("<p class='step-header'>PASSWORD</p>", unsafe_allow_html=True)
        password = st.text_input("Password", type="password", placeholder="🔒 Enter your secure password...", key="auth_pass_input", label_visibility="collapsed")

        st.write("")
        if st.button("Confirm & Enter Dashboard  ➔", key="btn_confirm_login", use_container_width=True, type="primary"):
            if not full_name.strip():
                st.error("Please enter your name.")
                return False

            clean_phone = re.sub(r"\D", "", phone)
            if len(clean_phone) != 10:
                st.error("Please enter a valid 10-digit phone number.")
                return False

            if len(password.strip()) < 4:
                st.error("Password must be at least 4 characters long.")
                return False

            if is_authority:
                if not _is_valid_email(user_email):
                    st.error("Please enter a valid official email address.")
                    return False
                assigned_role = "Authority"
            else:
                raw_occ = occupation.replace("🎓 ", "").replace("💼 ", "").replace("👷 ", "").replace("🩺 ", "").replace("👴 ", "").replace("👵 ", "").replace("🤰 ", "").replace("🏠 ", "").strip()
                if raw_occ == "Senior Citizen":
                    assigned_role = "Senior Citizen"
                elif raw_occ == "Pregnant Women":
                    assigned_role = "Pregnant Women"
                elif raw_occ == "Outdoor Worker":
                    assigned_role = "Outdoor Worker"
                elif raw_occ == "Medical Staff":
                    assigned_role = "Medical Staff"
                elif raw_occ == "Student":
                    assigned_role = "Student"
                elif raw_occ == "Employee":
                    assigned_role = "Employer"
                else:
                    assigned_role = "Unemployed"

            st.session_state["authenticated"] = True
            st.session_state["user_profile"] = {
                "name": full_name.strip(),
                "phone": clean_phone,
                "email": user_email.strip() if is_authority else None,
                "user_type": "Authority" if is_authority else "Citizen",
                "gender": gender,
                "occupation": occupation,
                "role": assigned_role,
            }
            st.session_state["selected_role"] = assigned_role

            if is_authority:
                st.session_state["page"] = "Authority Dashboard"
            else:
                st.session_state["page"] = "Dashboard"

            st.rerun()

        st.markdown(
            """
            <div style="text-align:center; font-size:0.75rem; color:#2D6A5F; margin-top:14px;">
                By registering, you agree to our <a href="#" style="color:#0284C7; text-decoration:underline; font-weight:700;">Privacy Policy</a> and <a href="#" style="color:#0284C7; text-decoration:underline; font-weight:700;">Terms of Service</a>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with col_right:
        # Aqua-Blue & Teal Glow SVG Shield directly mirroring bg.png
        crystal_shield_svg = (
            '<svg width="330" height="300" viewBox="0 0 280 250" fill="none" xmlns="http://www.w3.org/2000/svg">'
            '<style>'
            '@keyframes floatShieldAqua { 0%, 100% { transform: translateY(0px); } 50% { transform: translateY(-14px); } }'
            '@keyframes pulseAquaCore { 0%, 100% { transform: scale(1); opacity: 0.95; } 50% { transform: scale(1.14); opacity: 0.7; } }'
            '@keyframes radarSpinAqua { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }'
            '.floating-shield-group { animation: floatShieldAqua 4.2s ease-in-out infinite; transform-origin: center; }'
            '.pulsing-aqua-core { animation: pulseAquaCore 2.6s ease-in-out infinite; transform-origin: 140px 118px; }'
            '.radar-ring-aqua { animation: radarSpinAqua 14s linear infinite; transform-origin: 140px 122px; }'
            '</style>'
            '<g class="radar-ring-aqua">'
            '<circle cx="140" cy="122" r="95" stroke="url(#aquaHaloGrad)" stroke-width="1.8" stroke-dasharray="6 8" opacity="0.7"/>'
            '</g>'
            '<path d="M40 85 C 20 120, 20 150, 40 180" stroke="#38BDF8" stroke-width="3" stroke-linecap="round" opacity="0.6" stroke-dasharray="4 6"/>'
            '<path d="M25 65 C -2 115, -2 165, 25 200" stroke="#0D9488" stroke-width="2.5" stroke-linecap="round" opacity="0.45" stroke-dasharray="6 6"/>'
            '<g class="floating-shield-group">'
            '<path d="M140 26 L220 62 V126 C220 182 184 222 140 238 C96 222 60 182 60 126 V62 L140 26 Z" fill="url(#aquaShieldGrad)" stroke="#38BDF8" stroke-width="3"/>'
            '<path d="M140 42 L200 70 V122 C200 164 174 198 140 212 C106 198 80 164 80 122 V70 L140 42 Z" fill="url(#aquaInnerGrad)" opacity="0.94" stroke="rgba(255,255,255,0.75)" stroke-width="1.5"/>'
            '<circle class="pulsing-aqua-core" cx="140" cy="118" r="28" fill="url(#aquaCoreGrad)"/>'
            '<line x1="140" y1="88" x2="140" y2="68" stroke="#38BDF8" stroke-width="2.5" stroke-linecap="round"/>'
            '<line x1="140" y1="148" x2="140" y2="168" stroke="#38BDF8" stroke-width="2.5" stroke-linecap="round"/>'
            '<line x1="110" y1="118" x2="90" y2="118" stroke="#38BDF8" stroke-width="2.5" stroke-linecap="round"/>'
            '<line x1="170" y1="118" x2="190" y2="118" stroke="#38BDF8" stroke-width="2.5" stroke-linecap="round"/>'
            '<path d="M127 118 L133 118 L137 110 L141 126 L145 113 L148 118 L153 118" stroke="#FFFFFF" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>'
            '</g>'
            '<defs>'
            '<linearGradient id="aquaShieldGrad" x1="60" y1="26" x2="220" y2="238" gradientUnits="userSpaceOnUse">'
            '<stop offset="0%" stop-color="#38BDF8"/>'
            '<stop offset="50%" stop-color="#0284C7"/>'
            '<stop offset="100%" stop-color="#0F766E"/>'
            '</linearGradient>'
            '<linearGradient id="aquaInnerGrad" x1="80" y1="42" x2="200" y2="212" gradientUnits="userSpaceOnUse">'
            '<stop offset="0%" stop-color="#7DD3FC"/>'
            '<stop offset="100%" stop-color="#0D9488"/>'
            '</linearGradient>'
            '<radialGradient id="aquaCoreGrad" cx="50%" cy="50%" r="50%">'
            '<stop offset="0%" stop-color="#FFFFFF"/>'
            '<stop offset="45%" stop-color="#38BDF8"/>'
            '<stop offset="100%" stop-color="#0369A1"/>'
            '</radialGradient>'
            '<linearGradient id="aquaHaloGrad" x1="40" y1="27" x2="240" y2="217" gradientUnits="userSpaceOnUse">'
            '<stop offset="0%" stop-color="#38BDF8"/>'
            '<stop offset="50%" stop-color="#0D9488"/>'
            '<stop offset="100%" stop-color="#0284C7"/>'
            '</linearGradient>'
            '</defs>'
            '</svg>'
        )

        hero_html = (
            f'<div class="artboard-card">'
            f'<div class="chip-heat">🔥 Heat Stress: 43.8°C</div>'
            f'<div style="margin-top:20px; margin-bottom:10px;">{crystal_shield_svg}</div>'
            f'<div style="font-size:1.6rem; font-weight:900; color:{text_primary}; letter-spacing:-0.02em; margin-top:8px;">HeatShield Neural Grid</div>'
            f'<div style="font-size:0.95rem; color:{text_secondary}; margin-top:10px; line-height:1.6; max-width:380px;">Dynamic microclimate vulnerability tracking, biological stress mitigation & thermal defense analytics.</div>'
            f'<div style="display:flex; justify-content:center; gap:12px; margin-top:24px; flex-wrap:wrap;">'
            f'<div style="display:inline-flex; align-items:center; gap:8px; padding:9px 20px; border-radius:22px; background:rgba(2, 132, 199, 0.12); font-size:0.82rem; color:#0369A1; font-weight:800; border:1.4px solid rgba(2, 132, 199, 0.35);">'
            f'<span style="width:9px; height:9px; border-radius:50%; background:#0284C7; display:inline-block;"></span>Autonomous Climate Core</div>'
            f'<div style="display:inline-flex; align-items:center; gap:8px; padding:9px 20px; border-radius:22px; background:rgba(13, 148, 136, 0.12); font-size:0.82rem; color:#0F766E; font-weight:800; border:1.4px solid rgba(13, 148, 136, 0.30);">'
            f'⚡ Neural Shield: Active</div>'
            f'</div>'
            f'</div>'
        )

        st.markdown(hero_html, unsafe_allow_html=True)

    st.markdown(
        """
        <div class="trust-footer">
            <div class="trust-pill">
                <div class="trust-icon-circle" style="background:#ECFDF5; color:#059669;">🛡️</div>
                <div>
                    <div class="trust-text-title">100%</div>
                    <div class="trust-text-sub">Data Secure</div>
                </div>
            </div>
            <div class="trust-pill">
                <div class="trust-icon-circle" style="background:#E0F2FE; color:#0284C7;">📊</div>
                <div>
                    <div class="trust-text-title">Real-Time</div>
                    <div class="trust-text-sub">Heat Alerts</div>
                </div>
            </div>
            <div class="trust-pill">
                <div class="trust-icon-circle" style="background:#F0FDFA; color:#0D9488;">👥</div>
                <div>
                    <div class="trust-text-title">Safer</div>
                    <div class="trust-text-sub">Communities</div>
                </div>
            </div>
            <div class="trust-pill">
                <div class="trust-icon-circle" style="background:#F0FDF4; color:#16A34A;">🌱</div>
                <div>
                    <div class="trust-text-title">Healthier</div>
                    <div class="trust-text-sub">Tomorrows</div>
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    return st.session_state.get("authenticated", False)