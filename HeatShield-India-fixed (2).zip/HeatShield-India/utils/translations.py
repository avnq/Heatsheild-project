"""
utils/translations.py

Centralized translation dictionary. English and Hindi are fully
implemented; other languages listed in constants.LANGUAGES fall back
to English automatically (see get_text()) so the UI never breaks.
"""

from __future__ import annotations

TRANSLATIONS: dict[str, dict[str, str]] = {
    "app_title": {"en": "HeatShield India", "hi": "हीटशील्ड इंडिया"},
    "app_tagline": {
        "en": "Human Thermal Stress & Heat Health Early Warning System",
        "hi": "मानव तापीय तनाव एवं गर्मी-स्वास्थ्य पूर्व चेतावनी प्रणाली",
    },
    "hero_headline_1": {"en": "HEAT IS NOT JUST A TEMPERATURE.", "hi": "गर्मी सिर्फ़ तापमान नहीं है।"},
    "hero_headline_2": {"en": "IT'S A HUMAN HEALTH RISK.", "hi": "यह एक मानव स्वास्थ्य जोखिम है।"},
    "hero_sub": {
        "en": "HeatShield India transforms weather forecasts into localized, vulnerability-aware heat-health warnings.",
        "hi": "हीटशील्ड इंडिया मौसम पूर्वानुमान को स्थानीयकृत, संवेदनशीलता-आधारित गर्मी-स्वास्थ्य चेतावनियों में बदलता है।",
    },
    "explore_live_risk": {"en": "EXPLORE LIVE RISK", "hi": "लाइव जोखिम देखें"},
    "dashboard": {"en": "Dashboard", "hi": "डैशबोर्ड"},
    "risk_map": {"en": "Risk Map", "hi": "जोखिम मानचित्र"},
    "location_analysis": {"en": "Location Analysis", "hi": "स्थान विश्लेषण"},
    "forecast": {"en": "Forecast", "hi": "पूर्वानुमान"},
    "vulnerability": {"en": "Vulnerability", "hi": "संवेदनशीलता"},
    "alerts": {"en": "Alerts", "hi": "चेतावनियाँ"},
    "precautions": {"en": "Precautions", "hi": "सावधानियाँ"},
    "authority_dashboard": {"en": "Authority Dashboard", "hi": "प्राधिकरण डैशबोर्ड"},
    "methodology": {"en": "Methodology", "hi": "कार्यप्रणाली"},
    "about": {"en": "About", "hi": "परिचय"},
    "current_heat_risk": {"en": "Current Heat Risk", "hi": "वर्तमान गर्मी जोखिम"},
    "thermal_stress": {"en": "Thermal Stress", "hi": "तापीय तनाव"},
    "high_risk_areas": {"en": "High-Risk Areas", "hi": "उच्च-जोखिम क्षेत्र"},
    "peak_risk": {"en": "Peak Risk", "hi": "चरम जोखिम"},
    "vulnerable_population": {"en": "Vulnerable Population", "hi": "संवेदनशील जनसंख्या"},
    "districts": {"en": "DISTRICTS", "hi": "ज़िले"},
    "people": {"en": "PEOPLE", "hi": "लोग"},
    "today": {"en": "TODAY", "hi": "आज"},
    "live_forecast_status": {"en": "LIVE FORECAST STATUS", "hi": "लाइव पूर्वानुमान स्थिति"},
    "run_extreme_scenario": {"en": "RUN EXTREME HEAT SCENARIO", "hi": "अत्यधिक गर्मी परिदृश्य चलाएँ"},
    "why_is_this_risk_high": {"en": "WHY IS THIS RISK HIGH?", "hi": "यह जोखिम इतना अधिक क्यों है?"},
    "primary_risk_drivers": {"en": "PRIMARY RISK DRIVERS", "hi": "मुख्य जोखिम कारक"},
    "select_location": {"en": "Select Location", "hi": "स्थान चुनें"},
    "select_role": {"en": "I am a...", "hi": "मैं हूँ..."},
    "select_language": {"en": "Language", "hi": "भाषा"},
    "recommended_action": {"en": "RECOMMENDED ACTION", "hi": "अनुशंसित कार्रवाई"},
    "forecast_confidence": {"en": "FORECAST CONFIDENCE", "hi": "पूर्वानुमान विश्वास स्तर"},
    "health_risk": {"en": "Health Risk", "hi": "स्वास्थ्य जोखिम"},
    "peak_exposure_window": {"en": "Peak exposure window", "hi": "चरम जोखिम अवधि"},
    "main_drivers": {"en": "Main drivers", "hi": "मुख्य कारण"},
    "temperature": {"en": "Temperature", "hi": "तापमान"},
    "humidity": {"en": "Humidity", "hi": "आर्द्रता"},
    "wind": {"en": "Wind", "hi": "हवा की गति"},
    "solar_radiation": {"en": "Solar Radiation", "hi": "सौर विकिरण"},
    "no_action_required": {"en": "No special heat-health action required.", "hi": "किसी विशेष गर्मी-स्वास्थ्य कार्रवाई की आवश्यकता नहीं है।"},
    "extreme_heat": {
        "en": "Activate emergency heat-health response.",
        "hi": "आपातकालीन गर्मी-स्वास्थ्य प्रतिक्रिया सक्रिय करें।",
    },
    "avoid_sun_citizen": {
        "en": "Avoid direct sun between 12 PM and 4 PM. Drink water frequently. Use shade or cool indoor spaces.",
        "hi": "दोपहर 12 बजे से शाम 4 बजे के बीच सीधी धूप से बचें। बार-बार पानी पिएँ। छाया या ठंडी जगह का उपयोग करें।",
    },
    "outdoor_worker_advice": {
        "en": "Shift heavy work away from peak heat. Provide water, shade and regular rest breaks. Monitor workers for heat illness.",
        "hi": "भारी काम को चरम गर्मी के समय से हटाएँ। पानी, छाया और नियमित विश्राम प्रदान करें। श्रमिकों में गर्मी से बीमारी के लक्षणों पर नज़र रखें।",
    },
    "demo_mode_banner": {
        "en": "DEMO MODE — Using simulated forecast and vulnerability data for demonstration purposes. Live weather integration is optional and falls back automatically to this dataset if unavailable.",
        "hi": "डेमो मोड — प्रदर्शन प्रयोजनों के लिए सिम्युलेटेड पूर्वानुमान और संवेदनशीलता डेटा का उपयोग किया जा रहा है। लाइव मौसम एकीकरण वैकल्पिक है और अनुपलब्ध होने पर स्वतः इस डेटासेट पर वापस आ जाता है।",
    },
    "system_ready": {"en": "SYSTEM READY", "hi": "सिस्टम तैयार है"},
    "temperature_alone_not_enough": {
        "en": "Temperature alone does not tell the whole story.",
        "hi": "अकेला तापमान पूरी कहानी नहीं बताता।",
    },
}


def get_text(key: str, lang: str = "en") -> str:
    """Return translated string for key/lang, falling back to English,
    then to the key itself if nothing is found."""
    entry = TRANSLATIONS.get(key)
    if not entry:
        return key
    return entry.get(lang) or entry.get("en") or key
