"""
utils/validators.py

Data quality engine: validates incoming weather / location records and
reports a human-readable confidence score + issue list. Never raises
uncaught exceptions into the UI layer — always returns a structured
result the frontend can render safely.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ValidationResult:
    is_valid: bool
    cleaned: dict[str, Any]
    issues: list[str] = field(default_factory=list)
    completeness: float = 1.0  # 0.0 - 1.0


REQUIRED_WEATHER_FIELDS = {
    "temperature_c": (-10.0, 60.0),
    "humidity_pct": (0.0, 100.0),
    "wind_ms": (0.0, 40.0),
    "solar_radiation_wm2": (0.0, 1400.0),
}


def validate_weather_record(record: dict[str, Any]) -> ValidationResult:
    """Validate a single weather record (one location/timestamp)."""
    issues: list[str] = []
    cleaned = dict(record)
    valid_fields = 0

    for field_name, (lo, hi) in REQUIRED_WEATHER_FIELDS.items():
        value = record.get(field_name)
        if value is None:
            issues.append(f"Missing {field_name.replace('_', ' ')}.")
            continue
        try:
            value = float(value)
        except (TypeError, ValueError):
            issues.append(f"Invalid (non-numeric) {field_name.replace('_', ' ')}.")
            continue
        if not (lo <= value <= hi):
            issues.append(
                f"{field_name.replace('_', ' ').title()} out of plausible range "
                f"({value})."
            )
            # Clip to range rather than discard, so the app can keep functioning.
            value = max(lo, min(hi, value))
        cleaned[field_name] = value
        valid_fields += 1

    completeness = valid_fields / len(REQUIRED_WEATHER_FIELDS)

    timestamp = record.get("timestamp")
    if not timestamp:
        issues.append("Missing timestamp.")

    lat, lon = record.get("lat"), record.get("lon")
    if lat is None or lon is None:
        issues.append("Missing coordinates.")
    else:
        try:
            lat_f, lon_f = float(lat), float(lon)
            if not (6.0 <= lat_f <= 38.0 and 68.0 <= lon_f <= 98.0):
                issues.append("Coordinates fall outside expected India bounding box.")
        except (TypeError, ValueError):
            issues.append("Invalid coordinates.")

    is_valid = completeness >= 0.5  # at least half the core fields usable

    return ValidationResult(
        is_valid=is_valid,
        cleaned=cleaned,
        issues=issues,
        completeness=round(completeness, 2),
    )


def validate_location_id(location_id: str | None, known_ids: list[str]) -> tuple[bool, str]:
    """Validate a requested location id against the known set."""
    if not location_id:
        return False, "No location specified."
    if location_id not in known_ids:
        return False, f"Unknown location '{location_id}'."
    return True, ""


def compute_confidence_score(
    completeness: float,
    forecast_days_available: int,
    forecast_days_expected: int,
    data_consistency: float = 1.0,
) -> int:
    """
    Prototype confidence score (0-100) combining:
      - data completeness (validated fields present)
      - forecast horizon availability
      - internal consistency of the series (e.g. no wild jumps)

    NOTE: This is a heuristic prototype, not a statistically validated
    probability estimate.
    """
    horizon_ratio = 1.0
    if forecast_days_expected > 0:
        horizon_ratio = min(1.0, forecast_days_available / forecast_days_expected)

    score = (0.5 * completeness) + (0.3 * horizon_ratio) + (0.2 * data_consistency)
    return int(round(max(0.0, min(1.0, score)) * 100))
