"""
backend/geocoding_service.py

Turns raw lat/lon into a human-readable, specific place name (e.g.
"Dwarka, Delhi" instead of just "Delhi"), and lets a user search for
any place in India by name and get back coordinates — used both for
labeling the live GPS marker and for the manual "search a location"
override.

Uses OpenStreetMap's free Nominatim API (no key required). Best-effort
only: every function returns None / [] on any failure instead of
raising, so a geocoding outage never breaks the rest of the app.
"""

from __future__ import annotations

from urllib.parse import quote

import streamlit as st

_HEADERS = {"User-Agent": "HeatShieldIndia/1.0 (hackathon prototype)"}


@st.cache_data(show_spinner=False, ttl=3600)
def reverse_geocode(lat: float, lon: float) -> str | None:
    """Return a specific, short place label for a lat/lon, e.g.
    "Dwarka, Delhi" or "Koramangala, Bengaluru". Returns None on
    failure so the caller can fall back to a generic label.
    """
    import requests

    try:
        url = (
            "https://nominatim.openstreetmap.org/reverse"
            f"?format=json&lat={lat}&lon={lon}&zoom=16&addressdetails=1"
        )
        resp = requests.get(url, headers=_HEADERS, timeout=5)
        resp.raise_for_status()
        addr = resp.json().get("address", {})

        # Most specific first: neighbourhood/suburb, then the city, then state.
        area = (
            addr.get("suburb") or addr.get("neighbourhood") or addr.get("quarter")
            or addr.get("residential") or addr.get("city_district")
        )
        city = (
            addr.get("city") or addr.get("town") or addr.get("municipality")
            or addr.get("county")
        )
        state = addr.get("state")

        parts = [p for p in [area, city] if p]
        if not parts and state:
            parts = [state]
        elif not area and city and state and city != state:
            parts.append(state)

        label = ", ".join(dict.fromkeys(parts))  # dedupe, keep order
        return label or None
    except Exception as exc:
        print(f"[HeatShield] reverse_geocode failed for ({lat}, {lon}): {type(exc).__name__}: {exc}")
        return None


@st.cache_data(show_spinner=False, ttl=3600)
def search_places(query: str, limit: int = 5) -> list[dict]:
    """Search for a place by name (restricted to India) and return up
    to `limit` matches as [{"label": str, "lat": float, "lon": float}].
    Returns [] on failure or no matches.
    """
    import requests

    query = (query or "").strip()
    if not query:
        return []

    try:
        url = (
            "https://nominatim.openstreetmap.org/search"
            f"?format=json&q={quote(query)}&countrycodes=in"
            f"&limit={limit}&addressdetails=1"
        )
        resp = requests.get(url, headers=_HEADERS, timeout=5)
        resp.raise_for_status()
        results = []
        for item in resp.json():
            addr = item.get("address", {})
            area = (
                addr.get("suburb") or addr.get("neighbourhood") or addr.get("city_district")
                or addr.get("town") or addr.get("village")
            )
            city = addr.get("city") or addr.get("county")
            state = addr.get("state")
            parts = [p for p in [area, city, state] if p]
            label = ", ".join(dict.fromkeys(parts)) if parts else item.get("display_name", query)
            results.append({
                "label": label,
                "lat": float(item["lat"]),
                "lon": float(item["lon"]),
            })
        return results
    except Exception:
        return []
