"""
frontend/animations.py

Reusable animation building blocks supporting dynamic Light and Dark themes:
startup loading sequence, animated KPI counters (0 -> value), animated circular
gauges, and the animated pipeline.
"""

from __future__ import annotations

import time
import uuid
import streamlit as st
import streamlit.components.v1 as components
from frontend.styles import THEMES, get_current_theme


def _tokens() -> dict:
    """Helper to fetch design tokens for active theme."""
    mode = get_current_theme()
    return THEMES.get(mode, THEMES["dark"])


def run_startup_sequence(container=None) -> None:
    """Displays the animated boot sequence once per session."""
    target = container or st
    t = _tokens()
    steps = [
        "Loading weather data...",
        "Calculating thermal stress...",
        "Analyzing vulnerability...",
        "Generating health-risk forecast...",
    ]
    placeholder = target.empty()
    for i, step in enumerate(steps):
        pct = int(((i + 1) / len(steps)) * 100)
        placeholder.markdown(
            f"""
            <div class="hs-card hs-fade-in" style="text-align:center; padding:40px;">
                <div style="font-size:2rem; font-weight:800; letter-spacing:0.05em; color:{t['text_primary']};">HEATSHIELD INDIA</div>
                <div style="color:{t['text_muted']}; margin:10px 0 22px 0;">Initializing heat-health intelligence...</div>
                <div style="height:8px; width:100%; background:{t['chip_bg']}; border-radius:6px; overflow:hidden;">
                    <div style="height:100%; width:{pct}%; background:linear-gradient(90deg,{t['accent']},{t['accent_2']}); transition:width 0.3s ease;"></div>
                </div>
                <div style="margin-top:16px; font-weight:600; color:{t['text_primary']};">{step}</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        time.sleep(0.35)
    placeholder.markdown(
        f"""
        <div class="hs-card hs-fade-in" style="text-align:center; padding:40px;">
            <div style="font-size:2rem; font-weight:800; color:{t['text_primary']};">HEATSHIELD INDIA</div>
            <div style="color:#2ECC71; margin-top:14px; font-weight:700; letter-spacing:0.08em;">✓ SYSTEM READY</div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    time.sleep(0.4)
    placeholder.empty()


def animated_counter(
    label: str,
    value: float,
    suffix: str = "",
    sub: str = "",
    color: str | None = None,
    decimals: int = 0,
    height: int = 148,
) -> None:
    """Render a card with a JS-animated 0 -> value counter matching theme."""
    t = _tokens()
    val_color = color if color is not None else t["text_primary"]
    uid = f"cnt_{uuid.uuid4().hex[:8]}"

    components.html(
        f"""
        <div style="font-family:'Inter',sans-serif; background:{t['panel_bg']};
                    border:1px solid {t['border_color']}; border-radius:18px; padding:20px 22px;
                    box-shadow:{t['card_shadow']}; color:{t['text_primary']};">
            <div style="font-size:0.72rem; letter-spacing:0.10em; text-transform:uppercase;
                        color:{t['text_muted']}; font-weight:600; margin-bottom:6px;">{label}</div>
            <div id="{uid}" style="font-size:2.3rem; font-weight:800; color:{val_color}; font-variant-numeric:tabular-nums;">0{suffix}</div>
            <div style="font-size:0.78rem; color:{t['text_muted']}; margin-top:4px; font-weight:600; letter-spacing:0.04em;">{sub}</div>
        </div>
        <script>
            (function() {{
                const el = document.getElementById("{uid}");
                const target = {value};
                const decimals = {decimals};
                const duration = 900;
                const start = performance.now();
                function step(now) {{
                    const progress = Math.min(1, (now - start) / duration);
                    const eased = 1 - Math.pow(1 - progress, 3);
                    const current = (target * eased).toFixed(decimals);
                    el.textContent = current + "{suffix}";
                    if (progress < 1) requestAnimationFrame(step);
                }}
                requestAnimationFrame(step);
            }})();
        </script>
        """,
        height=height,
    )


def animated_gauge(
    label: str,
    value: float,
    max_value: float = 100,
    status_label: str = "",
    color: str = "#E67E22",
    height: int = 230,
) -> None:
    """Render an animated SVG circular gauge (0 -> value)."""
    t = _tokens()
    is_light = get_current_theme() == "light"
    ring_bg = "rgba(15, 23, 42, 0.08)" if is_light else "rgba(255, 255, 255, 0.08)"

    uid = f"gauge_{uuid.uuid4().hex[:8]}"
    radius = 54
    circumference = 2 * 3.14159265 * radius
    pct = max(0.0, min(1.0, value / max_value))
    offset_target = circumference * (1 - pct)

    components.html(
        f"""
        <div style="font-family:'Inter',sans-serif; text-align:center; color:{t['text_primary']};">
            <div style="font-size:0.75rem; letter-spacing:0.10em; text-transform:uppercase;
                        color:{t['text_muted']}; font-weight:700; margin-bottom:6px;">{label}</div>
            <svg width="140" height="140" viewBox="0 0 140 140">
                <circle cx="70" cy="70" r="{radius}" stroke="{ring_bg}" stroke-width="12" fill="none"/>
                <circle id="{uid}" cx="70" cy="70" r="{radius}" stroke="{color}" stroke-width="12" fill="none"
                        stroke-linecap="round" stroke-dasharray="{circumference}" stroke-dashoffset="{circumference}"
                        transform="rotate(-90 70 70)" style="transition: stroke-dashoffset 1s cubic-bezier(.22,.9,.33,1);"/>
                <text id="{uid}_text" x="70" y="66" text-anchor="middle" font-size="24" font-weight="800" fill="{t['text_primary']}">0</text>
                <text x="70" y="86" text-anchor="middle" font-size="11" fill="{t['text_muted']}">/ {int(max_value)}</text>
            </svg>
            <div style="font-weight:700; color:{color}; letter-spacing:0.04em; margin-top:4px;">{status_label}</div>
        </div>
        <script>
            requestAnimationFrame(function() {{
                const circle = document.getElementById("{uid}");
                if (circle) circle.style.strokeDashoffset = "{offset_target}";
            }});
            (function() {{
                const textEl = document.getElementById("{uid}_text");
                const target = {value};
                const duration = 1000;
                const start = performance.now();
                function step(now) {{
                    const progress = Math.min(1, (now - start) / duration);
                    const eased = 1 - Math.pow(1 - progress, 3);
                    textEl.textContent = Math.round(target * eased);
                    if (progress < 1) requestAnimationFrame(step);
                }}
                requestAnimationFrame(step);
            }})();
        </script>
        """,
        height=height,
    )


def animated_pipeline(active_stage: int = 5) -> None:
    """Animated Weather -> Alert pipeline with moving arrows."""
    t = _tokens()
    stages = [
        "WEATHER",
        "THERMAL STRESS",
        "VULNERABILITY",
        "HEALTH RISK",
        "ALERT",
    ]
    icons = ["🌡️", "🔥", "🧭", "❤️‍🔥", "🚨"]

    stages_html = ""
    for i, (stage, icon) in enumerate(zip(stages, icons)):
        opacity = "1" if i < active_stage else "0.35"
        delay = i * 0.15
        stages_html += f"""
        <div class="stage" style="opacity:{opacity}; animation-delay:{delay}s;">
            <div class="icon">{icon}</div>
            <div class="label">{stage}</div>
        </div>
        """
        if i < len(stages) - 1:
            stages_html += """
            <div class="connector">
                <div class="line"></div>
                <div class="arrow">➜</div>
            </div>
            """

    html = f"""
<!DOCTYPE html>
<html>
<head>
<style>
* {{ box-sizing: border-box; }}
body {{
    margin: 0;
    padding: 10px;
    background: transparent;
    font-family: 'Inter', Arial, sans-serif;
    overflow: hidden;
}}
.pipeline {{
    width: 100%;
    min-height: 120px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0;
}}
.stage {{
    width: 125px;
    flex-shrink: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    animation: stageAppear 0.7s ease both;
}}
.icon {{
    font-size: 30px;
    line-height: 1;
    margin-bottom: 10px;
}}
.label {{
    color: {t['text_primary']};
    font-size: 12px;
    font-weight: 800;
    letter-spacing: 1px;
    text-align: center;
}}
.connector {{
    width: 90px;
    height: 35px;
    flex-shrink: 1;
    position: relative;
    display: flex;
    align-items: center;
}}
.line {{
    width: 100%;
    height: 2px;
    background: linear-gradient(90deg, {t['accent']}, {t['accent_2']});
    opacity: 0.65;
    border-radius: 10px;
}}
.arrow {{
    position: absolute;
    left: 0;
    top: 50%;
    transform: translateY(-50%);
    color: {t['accent_2']};
    font-size: 22px;
    font-weight: 900;
    text-shadow: 0 0 6px rgba(2, 132, 199, 0.45);
    animation: arrowMove 1.4s linear infinite;
}}
@keyframes arrowMove {{
    0% {{ left: 0%; opacity: 0; }}
    15% {{ opacity: 1; }}
    80% {{ opacity: 1; }}
    100% {{ left: 90%; opacity: 0; }}
}}
@keyframes stageAppear {{
    from {{ opacity: 0; transform: translateY(12px); }}
    to {{ opacity: 1; transform: translateY(0); }}
}}
</style>
</head>
<body>
<div class="pipeline">
    {stages_html}
</div>
</body>
</html>
"""

    components.html(html, height=140, scrolling=False)


def pulsing_alert_banner(text: str, color: str = "#E74C3C", icon: str = "🔴") -> None:
    t = _tokens()
    st.markdown(
        f"""
        <div class="hs-pulse" style="background:{color}18; border:1px solid {color}; border-radius:14px;
                    padding:14px 20px; font-weight:700; color:{t['text_primary']}; display:flex; align-items:center; gap:10px;">
            <span style="font-size:1.1rem;">{icon}</span> {text}
        </div>
        """,
        unsafe_allow_html=True,
    )