"""
backend/recommendation_engine.py

Role-specific and language-aware recommendations, derived from the
current risk level. Keeps all role-specific copy centralized so the
frontend never hardcodes advice text.
"""

from __future__ import annotations

from utils.translations import get_text

_ROLE_ADVICE_EN = {
    "Citizen": {
        "green": "Enjoy normal outdoor activities. Stay hydrated as a general precaution.",
        "yellow": "Avoid direct sun between 12 PM and 4 PM. Drink water frequently. Use shade or cool indoor spaces.",
        "orange": "Limit outdoor activity during peak hours. Wear light clothing and carry water.",
        "red": "Avoid non-essential outdoor activity during peak hours. Check on elderly neighbours and relatives.",
        "extreme": "Stay indoors during peak hours. Seek a cooling centre if your home lacks cooling. Seek medical help for dizziness, cramps, or confusion.",
    },
    "Outdoor Worker": {
        "green": "Normal work schedule. Keep water accessible.",
        "yellow": "Take short shade breaks during the hottest hours. Stay hydrated.",
        "orange": "Shift heavy work away from peak heat. Provide water, shade and regular rest breaks.",
        "red": "Reschedule strenuous outdoor tasks to early morning or evening. Provide water, shade and rest breaks. Monitor workers for heat illness.",
        "extreme": "Suspend non-essential outdoor work during peak hours. Mandatory rest/shade/water cycles. Have emergency response ready on site.",
    },
    "Hospital": {
        "green": "Standard operations. No special heat-preparedness action needed.",
        "yellow": "Monitor incoming cases for early heat-stress symptoms.",
        "orange": "Review heat-illness triage protocols with staff.",
        "red": "Prepare heat-illness response capacity. Review emergency staffing and IV fluid / cooling supplies.",
        "extreme": "Activate heat-emergency protocol. Increase staffing for heat-stroke triage and ensure cooling equipment is ready.",
    },
    "School": {
        "green": "Normal outdoor activities and sports permitted.",
        "yellow": "Provide extra water breaks during outdoor activities.",
        "orange": "Limit strenuous outdoor sports during midday hours.",
        "red": "Avoid outdoor sports and strenuous outdoor activity during peak-risk periods. Move assemblies indoors.",
        "extreme": "Suspend all outdoor activity. Consider adjusted school hours if extreme heat continues.",
    },
    "Authority": {
        "green": "No special measures required. Continue routine monitoring.",
        "yellow": "Issue public advisory for vulnerable groups.",
        "orange": "Activate public messaging campaign. Ensure water points are operational.",
        "red": "Open cooling centres. Deploy water points. Prioritize high-risk wards. Notify outdoor employers.",
        "extreme": "Activate emergency heat-health response. Open all cooling centres, deploy water tankers, prepare hospitals, and issue multilingual public alerts.",
    },
    "Employer": {
        "green": "Normal operating schedule.",
        "yellow": "Remind staff to stay hydrated; ensure drinking water is available.",
        "orange": "Adjust outdoor work schedules to avoid peak heat hours.",
        "red": "Modify outdoor work hours. Provide shaded rest areas and water. Train supervisors to recognize heat illness.",
        "extreme": "Suspend non-essential outdoor work. Provide cooled rest areas. Activate emergency contact procedures.",
    },
}

_HINDI_KEY_MAP = {
    ("Citizen", "yellow"): "avoid_sun_citizen",
    ("Outdoor Worker", "orange"): "outdoor_worker_advice",
    ("Outdoor Worker", "red"): "outdoor_worker_advice",
}


def get_recommendation(role: str, level_key: str, language: str = "en") -> str:
    """
    Return role + level specific recommendation text.
    Falls back gracefully to Citizen advice if role unknown, and to
    English if the language isn't in the (partial) Hindi map.
    """
    role_table = _ROLE_ADVICE_EN.get(role, _ROLE_ADVICE_EN["Citizen"])
    english_text = role_table.get(level_key, role_table["yellow"])

    if language == "en":
        return english_text

    translation_key = _HINDI_KEY_MAP.get((role, level_key))
    if translation_key:
        return get_text(translation_key, language)

    # Generic fallback: use the extreme-heat generic translation, else English text.
    if level_key == "extreme":
        return get_text("extreme_heat", language)
    if level_key == "green":
        return get_text("no_action_required", language)

    return english_text  # architecture supports more languages; extend map above


ALL_ROLES = list(_ROLE_ADVICE_EN.keys())
