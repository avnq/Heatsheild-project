"""
frontend/styles.py

Centralized custom CSS:
- Main Page: Original Rich Mint-Sage Canvas
- Sidebar: Formal Light Crisp Palette
- Custom Role Selector Card (Rounded Pill with Icon Badge)
- Solid Jet-Black Sidebar Expand Chevron (>>) via direct DOM & Filter Injection
"""

from __future__ import annotations

import streamlit as st
import streamlit.components.v1 as components

THEMES = {
    "dark": {
        "primary_bg": "#0B0F19",
        "bg_gradient": "radial-gradient(circle at 10% 0%, #14203a 0%, #0B0F19 45%) fixed",
        "sidebar_bg": "linear-gradient(180deg, #0D1220 0%, #0A0E17 100%)",
        "panel_bg": "#131A2A",
        "panel_bg_alt": "#161F33",
        "border_color": "rgba(255, 255, 255, 0.08)",
        "border_hover": "rgba(255, 255, 255, 0.20)",
        "text_primary": "#F4F6FB",
        "text_secondary": "#C9D6EA",
        "text_muted": "#9AA5B8",
        "accent": "#FF6B4A",
        "accent_hover": "#FF8A5C",
        "accent_2": "#33C6F4",
        "card_shadow": "0 8px 24px rgba(0, 0, 0, 0.32)",
        "card_shadow_hover": "0 14px 34px rgba(0, 0, 0, 0.45)",
        "chip_bg": "rgba(255, 255, 255, 0.05)",
        "input_bg": "#161F33",
        "input_text": "#F4F6FB",
        "table_bg": "#131A2A",
        "table_header": "#161F33",
        "btn_gradient": "linear-gradient(135deg, #1E293B 0%, #334155 100%)",
        "btn_text": "#F4F6FB",
        "btn_border": "rgba(255, 255, 255, 0.12)",
        "btn_shadow": "0 4px 14px rgba(0, 0, 0, 0.25)",
    },
    "light": {
        "primary_bg": "#DCECE3",
        "bg_gradient": "radial-gradient(circle at 12% 0%, #CDE4D6 0%, #DCECE3 55%, #CFE5D8 100%) fixed",
        "panel_bg": "#F4FAF6",
        "panel_bg_alt": "#E9F5EE",
        "border_color": "rgba(13, 148, 136, 0.30)",
        "border_hover": "rgba(13, 148, 136, 0.55)",
        "text_primary": "#0A352C",
        "text_secondary": "#0F463A",
        "text_muted": "#3A6357",
        "accent": "#0D9488",
        "accent_hover": "#0F766E",
        "accent_2": "#0284C7",
        "card_shadow": "0 8px 22px rgba(10, 53, 44, 0.09)",
        "card_shadow_hover": "0 14px 28px rgba(10, 53, 44, 0.16)",
        "chip_bg": "rgba(13, 148, 136, 0.12)",
        "table_bg": "#FCFBF7",
        "table_header": "#F4EFE6",
        "sidebar_bg": "linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%)",
        "sidebar_border": "rgba(15, 23, 42, 0.08)",
        "input_bg": "#FCFBF7",
        "input_text": "#0A352C",
        "btn_gradient": "linear-gradient(135deg, #FFFFFF 0%, #F1F5F9 100%)",
        "btn_text": "#0F172A",
        "btn_border": "rgba(15, 23, 42, 0.15)",
        "btn_shadow": "0 4px 12px rgba(15, 23, 42, 0.05)",
    },
}


def get_current_theme() -> str:
    return st.session_state.get("theme", "light")


def inject_global_css() -> None:
    current_mode = get_current_theme()
    t = THEMES.get(current_mode, THEMES["light"])

    # JS DOM Injector to force black styling into parent document
    components.html(
        """
        <script>
        function forceBlackToggle() {
            try {
                const doc = window.parent.document;
                const controls = doc.querySelectorAll('[data-testid="stSidebarCollapsedControl"], [data-testid="collapsedControl"], div[data-testid="stSidebarCollapseButton"]');
                controls.forEach(ctrl => {
                    ctrl.style.setProperty('visibility', 'visible', 'important');
                    ctrl.style.setProperty('opacity', '1', 'important');
                    const svgs = ctrl.querySelectorAll('svg');
                    svgs.forEach(svg => {
                        svg.style.setProperty('filter', 'brightness(0)', 'important');
                        svg.style.setProperty('color', '#000000', 'important');
                        svg.style.setProperty('fill', '#000000', 'important');
                        svg.querySelectorAll('*').forEach(el => {
                            el.style.setProperty('fill', '#000000', 'important');
                            el.style.setProperty('stroke', '#000000', 'important');
                        });
                    });
                });
            } catch(e) {}
        }
        setInterval(forceBlackToggle, 200);
        </script>
        """,
        height=0,
        width=0,
    )

    st.markdown(
        f"""
        <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;600&display=swap');

        :root {{
            --background-color: {t['primary_bg']} !important;
            --secondary-background-color: {t['panel_bg']} !important;
            --text-color: {t['text_primary']} !important;
            --font: 'Inter', sans-serif !important;
        }}

        html, body, [class*="css"] {{
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        }}

        .stApp {{
            background: {t['bg_gradient']};
            color: {t['text_primary']};
            transition: background 0.3s ease, color 0.3s ease;
        }}

        #MainMenu {{ display: none !important; }}
        footer {{ display: none !important; }}
        div[data-testid="stDecoration"] {{ display: none !important; }}

        header[data-testid="stHeader"] {{
            background: transparent !important;
            visibility: visible !important;
        }}

        /* ------------------------------------------------------------------ */
        /* SOLID JET-BLACK SIDEBAR EXPAND TOGGLE (>>)                         */
        /* ------------------------------------------------------------------ */
        [data-testid="stSidebarCollapsedControl"],
        [data-testid="collapsedControl"],
        div[data-testid="stSidebarCollapseButton"] {{
            visibility: visible !important;
            display: flex !important;
            opacity: 1 !important;
            z-index: 999999 !important;
        }}

        [data-testid="stSidebarCollapsedControl"] svg,
        [data-testid="stSidebarCollapsedControl"] svg *,
        [data-testid="collapsedControl"] svg,
        [data-testid="collapsedControl"] svg *,
        div[data-testid="stSidebarCollapseButton"] svg,
        div[data-testid="stSidebarCollapseButton"] svg * {{
            filter: brightness(0) !important;
            fill: #000000 !important;
            stroke: #000000 !important;
            color: #000000 !important;
            opacity: 1 !important;
        }}

        [data-testid="stSidebarCollapsedControl"] button,
        [data-testid="collapsedControl"] button,
        div[data-testid="stSidebarCollapseButton"] button {{
            background: transparent !important;
            border: none !important;
            box-shadow: none !important;
            cursor: pointer !important;
            opacity: 1 !important;
        }}

        /* Sidebar Styling */
        section[data-testid="stSidebar"] {{
            background: {t['sidebar_bg']} !important;
            border-right: 1.5px solid {t.get('sidebar_border', t['border_color'])} !important;
        }}
        section[data-testid="stSidebar"] * {{
            color: {"#0F172A" if current_mode == "light" else t['text_primary']} !important;
        }}

        h1, h2, h3, h4 {{
            font-weight: 800 !important;
            letter-spacing: -0.02em;
            color: {t['text_primary']} !important;
        }}
        p, span, label, .stMarkdown {{
            color: {t['text_primary']};
        }}

        /* Standard Select box Trigger */
        .stSelectbox,
        [data-testid="stSelectbox"],
        [data-testid="stSelectbox"] > div,
        [data-testid="stSelectbox"] > div > div,
        div[data-baseweb="select"],
        div[data-baseweb="select"] > div,
        div[data-baseweb="select"] input,
        div[data-baseweb="select"] [class*="ValueContainer"],
        div[role="combobox"] {{
            background-color: {"#FFFFFF" if current_mode == "light" else t['input_bg']} !important;
            background: {"#FFFFFF" if current_mode == "light" else t['input_bg']} !important;
            color: {"#0F172A" if current_mode == "light" else t['input_text']} !important;
            border-color: {"#CBD5E1" if current_mode == "light" else t['border_color']} !important;
            border-radius: 14px !important;
        }}

        div[data-baseweb="select"] > div {{
            border: 1.5px solid {"#CBD5E1" if current_mode == "light" else t['border_color']} !important;
            box-shadow: {"0 2px 8px rgba(0, 0, 0, 0.04)" if current_mode == "light" else "0 2px 10px rgba(0, 0, 0, 0.35)"} !important;
            min-height: 46px !important;
        }}

        [data-testid="stSelectbox"] span,
        [data-testid="stSelectbox"] p,
        [data-testid="stSelectbox"] div,
        div[data-baseweb="select"] span {{
            color: {"#0F172A" if current_mode == "light" else t['input_text']} !important;
            -webkit-text-fill-color: {"#0F172A" if current_mode == "light" else t['input_text']} !important;
            font-weight: 600 !important;
        }}

        div[data-baseweb="select"] svg {{
            fill: {"#0F172A" if current_mode == "light" else t['input_text']} !important;
            color: {"#0F172A" if current_mode == "light" else t['input_text']} !important;
        }}

        /* ------------------------------------------------------------------ */
        /* TEXT INPUT (e.g. sidebar "Search Location") — same theme-aware fix */
        /* as the selectbox above, since Streamlit's dark base theme forces a */
        /* black input background even when the app is switched to light mode */
        /* ------------------------------------------------------------------ */
        .stTextInput,
        [data-testid="stTextInput"],
        [data-testid="stTextInput"] > div,
        [data-testid="stTextInput"] > div > div,
        [data-testid="stTextInput"] input,
        .stTextArea,
        [data-testid="stTextArea"],
        [data-testid="stTextArea"] > div,
        [data-testid="stTextArea"] textarea {{
            background-color: {"#FFFFFF" if current_mode == "light" else t['input_bg']} !important;
            background: {"#FFFFFF" if current_mode == "light" else t['input_bg']} !important;
            color: {"#0F172A" if current_mode == "light" else t['input_text']} !important;
            -webkit-text-fill-color: {"#0F172A" if current_mode == "light" else t['input_text']} !important;
            border-color: {"#CBD5E1" if current_mode == "light" else t['border_color']} !important;
            border-radius: 14px !important;
        }}

        [data-testid="stTextInput"] > div,
        [data-testid="stTextArea"] > div {{
            border: 1.5px solid {"#CBD5E1" if current_mode == "light" else t['border_color']} !important;
            box-shadow: {"0 2px 8px rgba(0, 0, 0, 0.04)" if current_mode == "light" else "0 2px 10px rgba(0, 0, 0, 0.35)"} !important;
        }}

        [data-testid="stTextInput"] input::placeholder,
        [data-testid="stTextArea"] textarea::placeholder {{
            color: {"#94A3B8" if current_mode == "light" else "#7C8698"} !important;
            -webkit-text-fill-color: {"#94A3B8" if current_mode == "light" else "#7C8698"} !important;
            opacity: 1 !important;
        }}

        /* ------------------------------------------------------------------ */
        /* CUSTOM ROLE SELECTOR (MATCHING IMAGE 1 EXACTLY)                   */
        /* ------------------------------------------------------------------ */
        .hs-role-pill-label {{
            font-size: 1.25rem !important;
            font-weight: 800 !important;
            color: #0A352C !important;
            margin-bottom: 10px !important;
            display: block !important;
            letter-spacing: -0.01em !important;
        }}

        div[data-testid="stSelectbox"]:has(#role_selector_widget),
        div[data-testid="stSelectbox"]:has(#role_selector_widget) > div,
        div[data-testid="stSelectbox"]:has(#role_selector_widget) > div > div,
        div[data-testid="stSelectbox"]:has(#role_selector_widget) div[data-baseweb="select"],
        div[data-testid="stSelectbox"]:has(#role_selector_widget) div[data-baseweb="select"] > div {{
            background-color: #FFFFFF !important;
            background: #FFFFFF !important;
            border: 2px solid #10B981 !important;
            border-radius: 26px !important;
            min-height: 58px !important;
            box-shadow: 0 4px 14px rgba(16, 185, 129, 0.08) !important;
        }}

        div[data-testid="stSelectbox"]:has(#role_selector_widget) div[data-baseweb="select"] > div {{
            padding: 4px 16px !important;
            border: 2px solid #10B981 !important;
            border-radius: 26px !important;
            display: flex !important;
            align-items: center !important;
        }}

        div[data-testid="stSelectbox"]:has(#role_selector_widget) [class*="ValueContainer"] span {{
            font-size: 1.20rem !important;
            font-weight: 700 !important;
            color: #0F172A !important;
            -webkit-text-fill-color: #0F172A !important;
            display: flex !important;
            align-items: center !important;
            gap: 12px !important;
        }}

        div[data-testid="stSelectbox"]:has(#role_selector_widget) svg {{
            fill: #0D9488 !important;
            color: #0D9488 !important;
            width: 26px !important;
            height: 26px !important;
        }}

        /* Dropdown Popovers */
        div[data-baseweb="popover"], 
        div[data-baseweb="popover"] > div,
        div[data-baseweb="menu"],
        ul[role="listbox"],
        ul[data-baseweb="menu"] {{
            background-color: {"#FFFFFF" if current_mode == "light" else t['panel_bg_alt']} !important;
            background: {"#FFFFFF" if current_mode == "light" else t['panel_bg_alt']} !important;
            border: 1.5px solid {"#CBD5E1" if current_mode == "light" else t['border_color']} !important;
            border-radius: 14px !important;
            box-shadow: {"0 16px 36px rgba(15, 23, 42, 0.12)" if current_mode == "light" else "0 16px 36px rgba(0, 0, 0, 0.5)"} !important;
            padding: 6px !important;
        }}

        li[role="option"],
        li[data-baseweb="menu-item"] {{
            background-color: {"#FFFFFF" if current_mode == "light" else t['panel_bg_alt']} !important;
            background: {"#FFFFFF" if current_mode == "light" else t['panel_bg_alt']} !important;
            color: {"#0F172A" if current_mode == "light" else t['text_primary']} !important;
            -webkit-text-fill-color: {"#0F172A" if current_mode == "light" else t['text_primary']} !important;
            font-size: 0.95rem !important;
            font-weight: 700 !important;
            padding: 10px 14px !important;
            border-radius: 10px !important;
            margin: 2px 0 !important;
            transition: all 0.15s ease !important;
        }}

        li[role="option"] *,
        li[data-baseweb="menu-item"] * {{
            color: {"#0F172A" if current_mode == "light" else t['text_primary']} !important;
            -webkit-text-fill-color: {"#0F172A" if current_mode == "light" else t['text_primary']} !important;
            font-weight: 700 !important;
        }}

        li[role="option"]:hover,
        li[role="option"][aria-selected="true"],
        li[data-baseweb="menu-item"]:hover {{
            background-color: {"#F1F5F9" if current_mode == "light" else t['chip_bg']} !important;
            background: {"#F1F5F9" if current_mode == "light" else t['chip_bg']} !important;
            color: {"#0F172A" if current_mode == "light" else t['text_primary']} !important;
            -webkit-text-fill-color: {"#0F172A" if current_mode == "light" else t['text_primary']} !important;
        }}

        /* Sidebar Buttons */
        section[data-testid="stSidebar"] .stButton > button {{
            background: {t['btn_gradient']} !important;
            color: {t['btn_text']} !important;
            border: 1.5px solid {t['btn_border']} !important;
            border-radius: 14px !important;
            padding: 0.65rem 1.1rem !important;
            font-weight: 700 !important;
            letter-spacing: 0.02em !important;
            font-size: 0.93rem !important;
            box-shadow: {t['btn_shadow']} !important;
            transition: all 0.2s ease-in-out !important;
            display: flex !important;
            justify-content: center !important;
            align-items: center !important;
        }}

        section[data-testid="stSidebar"] .stButton > button:hover {{
            transform: translateY(-2px) !important;
            background: #E2E8F0 !important;
            border-color: #0F172A !important;
            box-shadow: 0 6px 16px rgba(15, 23, 42, 0.10) !important;
        }}

        .stButton > button, .stDownloadButton > button {{
            background: {t['btn_gradient']} !important;
            color: {t['btn_text']} !important;
            border: 1px solid {t['btn_border']} !important;
            border-radius: 12px !important;
            font-weight: 700 !important;
            letter-spacing: 0.03em !important;
            box-shadow: {t['btn_shadow']} !important;
            transition: transform 0.15s ease, box-shadow 0.15s ease !important;
        }}

        .hs-card {{
            background: {t['panel_bg']};
            border: 1.5px solid {t['border_color']};
            border-radius: 16px;
            padding: 22px 24px;
            box-shadow: {t['card_shadow']};
            transition: transform 0.25s ease, box-shadow 0.25s ease, border-color 0.25s ease;
            animation: hsFadeInUp 0.6s ease both;
        }}

        /* ------------------------------------------------------------------ */
        /* PRECAUTION ACCORDIONS (st.expander) — themed to look like cards     */
        /* instead of the plain default Streamlit expander.                   */
        /* ------------------------------------------------------------------ */
        [data-testid="stExpander"] {{
            background: {t['panel_bg']} !important;
            border: 1.5px solid {t['border_color']} !important;
            border-radius: 16px !important;
            box-shadow: {t['card_shadow']} !important;
            margin-bottom: 14px !important;
            overflow: hidden !important;
        }}
        [data-testid="stExpander"] summary {{
            background: {t['panel_bg']} !important;
            color: {t['text_primary']} !important;
            padding: 14px 18px !important;
            font-weight: 800 !important;
            font-size: 0.95rem !important;
        }}
        [data-testid="stExpander"] summary p {{
            color: {t['text_primary']} !important;
        }}
        [data-testid="stExpander"] summary:hover {{
            background: {"rgba(16, 185, 129, 0.06)" if current_mode == "light" else "rgba(255,255,255,0.04)"} !important;
        }}
        [data-testid="stExpander"] summary svg {{
            fill: {t['text_primary']} !important;
        }}
        [data-testid="stExpanderDetails"] {{
            background: {t['panel_bg']} !important;
            color: {t['text_primary']} !important;
            padding: 4px 18px 18px 18px !important;
        }}

        .hs-kpi-label {{
            font-size: 0.72rem;
            letter-spacing: 0.10em;
            text-transform: uppercase;
            color: {t['text_muted']};
            font-weight: 700;
            margin-bottom: 6px;
        }}
        .hs-kpi-value {{
            font-size: 2.3rem;
            font-weight: 800;
            line-height: 1.05;
            color: {t['text_primary']};
            font-variant-numeric: tabular-nums;
        }}
        .hs-kpi-sub {{
            font-size: 0.78rem;
            color: {t['text_muted']};
            margin-top: 4px;
            font-weight: 600;
            letter-spacing: 0.03em;
        }}

        .hs-hero-title {{
            font-size: clamp(2.0rem, 5vw, 3.4rem);
            font-weight: 800;
            line-height: 1.08;
            letter-spacing: -0.03em;
            color: {t['text_primary']} !important;
        }}
        .hs-hero-title.accent {{
            background: linear-gradient(90deg, {t['accent']} 0%, {t['accent_2']} 100%);
            -webkit-background-clip: text;
            background-clip: text;
            -webkit-text-fill-color: transparent;
        }}
        .hs-hero-sub {{
            font-size: 1.05rem;
            color: {t['text_muted']};
            max-width: 640px;
            line-height: 1.55;
        }}

        .hs-divider {{
            height: 1px;
            background: linear-gradient(90deg, transparent, {t['border_color']}, transparent);
            margin: 1.4rem 0;
            border: none;
        }}

        .hs-pill-row {{
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }}

        .hs-driver-chip {{
            background: {t['chip_bg']};
            border: 1px solid {t['border_color']};
            border-radius: 10px;
            padding: 8px 12px;
            font-size: 0.85rem;
            font-weight: 600;
            color: {t['text_primary']};
            display: flex;
            align-items: center;
            gap: 8px;
        }}

        .hs-section-title {{
            font-size: 0.78rem;
            letter-spacing: 0.14em;
            text-transform: uppercase;
            color: {t['text_muted']};
            font-weight: 700;
            margin-bottom: 10px;
        }}

        @keyframes hsFadeInUp {{
            from {{ opacity: 0; transform: translateY(12px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}
        .hs-fade-in {{
            animation: hsFadeInUp 0.6s ease both;
        }}
        </style>
        """,
        unsafe_allow_html=True,
    )