"""
backend/forecast_service.py

Loads the hourly forecast dataset and computes derived HTSS / Health
Risk series for a location, plus peak-risk window detection and a
prototype confidence score.
"""

from __future__ import annotations

import os

import pandas as pd
import streamlit as st

from backend.thermal_engine import calculate_htss
from backend.risk_engine import calculate_health_risk, find_peak_risk_window
from backend.vulnerability_engine import calculate_vulnerability
from backend.weather_service import get_live_hourly_forecast
from utils.validators import compute_confidence_score
from utils.constants import FORECAST_HORIZON_DAYS

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")


@st.cache_data(show_spinner=False)
def _load_forecast_raw() -> pd.DataFrame:
    return pd.read_csv(os.path.join(DATA_DIR, "forecast.csv"))


@st.cache_data(show_spinner=False)
def _load_locations() -> pd.DataFrame:
    return pd.read_csv(os.path.join(DATA_DIR, "locations.csv"))


def _compute_htss_risk(df: pd.DataFrame, vuln_score: float) -> pd.DataFrame:
    """Attach htss/health_risk/category/level columns to a raw weather df."""
    htss_vals, risk_vals, categories, levels = [], [], [], []
    for _, row in df.iterrows():
        thermal = calculate_htss(
            temperature_c=row["temperature_c"],
            humidity_pct=row["humidity_pct"],
            wind_ms=row["wind_ms"],
            solar_radiation_wm2=row["solar_radiation_wm2"],
            consecutive_hot_days=int(row["consecutive_hot_days"]),
        )
        risk = calculate_health_risk(thermal.htss, vuln_score)
        htss_vals.append(thermal.htss)
        risk_vals.append(risk.score)
        categories.append(thermal.category["label"])
        levels.append(risk.level["label"])

    df = df.copy()
    df["htss"] = htss_vals
    df["health_risk"] = risk_vals
    df["htss_category"] = categories
    df["risk_level"] = levels
    return df


def _get_vulnerability_score(location_id: str):
    loc_row = _load_locations()
    loc_row = loc_row[loc_row["location_id"] == location_id]
    if loc_row.empty:
        return None
    loc = loc_row.iloc[0]
    return calculate_vulnerability(
        elderly_pct=loc["elderly_pct"],
        population_density=loc["population_density"],
        outdoor_worker_pct=loc["outdoor_worker_pct"],
        green_cover_pct=loc["green_cover_pct"],
        healthcare_access_score=loc["healthcare_access_score"],
    ).score


def get_forecast(location_id: str, hours: int = 120, use_live: bool = True) -> pd.DataFrame:
    """
    Return an hourly forecast dataframe for a location with HTSS and
    Health Risk computed per hour. `hours` truncates the horizon
    (e.g. 24, 48, 72, 120).

    If `use_live` is True, tries to fetch a genuine Open-Meteo hourly
    forecast (matching real internet data, including rainfall) for the
    location's lat/lon first. On ANY failure (offline, API error, etc.)
    it transparently falls back to the bundled offline demo dataset, so
    the app never crashes for lack of network. The returned dataframe
    always carries a `data_source` column ("live" or "demo") so the UI
    can be honest about which one is showing.
    """
    vuln_score = _get_vulnerability_score(location_id)
    if vuln_score is None:
        return pd.DataFrame()

    if use_live:
        loc_row = _load_locations()
        loc_row = loc_row[loc_row["location_id"] == location_id]
        if not loc_row.empty:
            lat, lon = float(loc_row.iloc[0]["lat"]), float(loc_row.iloc[0]["lon"])
            live_df = get_live_hourly_forecast(lat, lon, hours=hours)
            if live_df is not None and not live_df.empty:
                return _compute_htss_risk(live_df, vuln_score)

    raw = _load_forecast_raw()
    df = raw[raw["location_id"] == location_id].sort_values("hour_index").head(hours).copy()
    if df.empty:
        return df
    df["data_source"] = "demo"
    df["rainfall_mm"] = None
    df["precip_probability"] = None
    df["weather_code"] = None
    return _compute_htss_risk(df, vuln_score)


def get_peak_risk_summary(location_id: str, hours: int = 120) -> dict:
    df = get_forecast(location_id, hours=hours)
    if df.empty:
        return {"start": None, "end": None, "peak_score": None}
    day0 = df[df["day_index"] == 0]
    if day0.empty:
        day0 = df
    pairs = [(f"{int(h):02d}:00", v) for h, v in zip(day0["hour_of_day"], day0["health_risk"])]
    return find_peak_risk_window(pairs)


def get_forecast_confidence(location_id: str) -> int:
    df = get_forecast(location_id, hours=FORECAST_HORIZON_DAYS * 24)
    if df.empty:
        return 0
    expected_hours = FORECAST_HORIZON_DAYS * 24
    available_hours = len(df)
    # Consistency heuristic: penalize wild hour-to-hour temperature jumps (>6C)
    temp_diffs = df["temperature_c"].diff().abs().dropna()
    jump_ratio = (temp_diffs > 6).sum() / max(1, len(temp_diffs))
    consistency = max(0.0, 1.0 - jump_ratio)

    return compute_confidence_score(
        completeness=1.0,  # forecast.csv fields are pre-validated at generation time
        forecast_days_available=available_hours // 24,
        forecast_days_expected=FORECAST_HORIZON_DAYS,
        data_consistency=consistency,
    )

