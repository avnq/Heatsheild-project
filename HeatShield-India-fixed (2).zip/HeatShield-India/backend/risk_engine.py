"""
backend/risk_engine.py

Combines Thermal Stress + Vulnerability into a single Heat Health Risk
score (0-100) and resolves it to an actionable risk level.

PRIMARY prototype model (used throughout the demo):
    Heat Health Risk = 0.65 * Thermal Stress + 0.35 * Vulnerability

An EXTENDED model is documented in utils/constants.py for future use
but is not mixed with the primary model at runtime (see ACTIVE_RISK_MODEL).
"""

from __future__ import annotations

from dataclasses import dataclass, field

from utils.constants import (
    RISK_MODEL_PRIMARY,
    RISK_MODEL_EXTENDED,
    ACTIVE_RISK_MODEL,
    RISK_LEVELS,
)
from utils.helpers import clamp, category_for_score


@dataclass
class HealthRiskResult:
    score: float
    level: dict
    breakdown: dict = field(default_factory=dict)
    model_used: str = ACTIVE_RISK_MODEL


def calculate_health_risk(
    thermal_stress_score: float,
    vulnerability_score: float,
    exposure_score: float | None = None,
    urban_heat_island_score: float | None = None,
    healthcare_accessibility_risk_score: float | None = None,
) -> HealthRiskResult:
    """
    Compute the Heat Health Risk score.

    If ACTIVE_RISK_MODEL == "extended" and the additional optional
    scores are provided, the extended weighting is used. Otherwise the
    primary two-factor model is always used (and any missing extended
    inputs safely fall back to the primary model, never a crash).
    """
    use_extended = (
        ACTIVE_RISK_MODEL == "extended"
        and exposure_score is not None
        and urban_heat_island_score is not None
        and healthcare_accessibility_risk_score is not None
    )

    if use_extended:
        weights = RISK_MODEL_EXTENDED
        breakdown = {
            "thermal_stress": round(weights["thermal_stress"] * thermal_stress_score, 1),
            "population_vulnerability": round(weights["population_vulnerability"] * vulnerability_score, 1),
            "exposure": round(weights["exposure"] * exposure_score, 1),
            "urban_heat_island": round(weights["urban_heat_island"] * urban_heat_island_score, 1),
            "healthcare_accessibility_risk": round(
                weights["healthcare_accessibility_risk"] * healthcare_accessibility_risk_score, 1
            ),
        }
        model_used = "extended"
    else:
        weights = RISK_MODEL_PRIMARY
        breakdown = {
            "thermal_stress": round(weights["thermal_stress"] * thermal_stress_score, 1),
            "vulnerability": round(weights["vulnerability"] * vulnerability_score, 1),
        }
        model_used = "primary"

    score = clamp(sum(breakdown.values()))
    level = category_for_score(score, RISK_LEVELS)

    return HealthRiskResult(score=round(score, 1), level=level, breakdown=breakdown, model_used=model_used)


def find_peak_risk_window(hourly_risk: list[tuple[str, float]]) -> dict:
    """
    Given a list of (label, risk_score) tuples across a day, identify
    the contiguous peak-risk window (highest scoring band, >=70% of max).
    """
    if not hourly_risk:
        return {"start": None, "end": None, "peak_score": None}

    max_score = max(v for _, v in hourly_risk)
    threshold = max_score * 0.85

    in_window = [label for label, v in hourly_risk if v >= threshold]
    if not in_window:
        return {"start": None, "end": None, "peak_score": max_score}

    return {"start": in_window[0], "end": in_window[-1], "peak_score": round(max_score, 1)}
