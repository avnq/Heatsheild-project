"""
frontend/ui_helpers.py

Session-state management, sidebar navigation, live GPS location tracking,
gender-aware role filtering, and Data Saver mode.
"""

from __future__ import annotations

import math
import pandas as pd
import streamlit as st

from utils.constants import (
    APP_NAME,
    APP_TAGLINE,
    NAV_PAGES,
    DEMO_LOCATIONS,
    LANGUAGES,
    DEFAULT_LOCATION,
)
from utils.translations import get_text
from frontend.styles import get_current_theme
from backend.geocoding_service import search_places, reverse_geocode
from backend.weather_service import get_weather_by_coords

try:
    from streamlit_js_eval import get_geolocation, streamlit_js_eval
    JS_EVAL_AVAILABLE = True
except ImportError:
    JS_EVAL_AVAILABLE = False

# NOTE ON ACCURACY: the get_geolocation() helper above calls
# navigator.geolocation.getCurrentPosition() with no options object, so the
# browser defaults to enableHighAccuracy=false and can return a cell-tower/
# Wi-Fi based fix instead of a real GPS fix -- which is why "TRACKING ACTIVE"
# could show a location several km off even though reverse-geocoding itself
# worked fine on whatever coords it was given.
#
# We do NOT auto-run a custom high-accuracy JS call on every render: an
# eval() call that isn't tied to a real user click (a) doesn't reliably
# trigger the browser's permission prompt inside Streamlit's component
# iframe on some browsers, and (b) streamlit_js_eval has an open upstream
# bug where firing it automatically can force the whole page to reset before
# the location Promise ever resolves -- which is what produced the "GPS
# WAITING FOR PERMISSION" stuck state. Instead, the default low-effort fix
# above runs automatically (as before, proven to work), and a manual
# "Get precise GPS fix" button (tied to an actual click = user gesture) below
# re-asks with enableHighAccuracy:true for whoever needs a tighter fix.
_HIGH_ACCURACY_GEO_JS = """
await new Promise((resolve) => {
    if (!("geolocation" in navigator)) {
        resolve({error: "Geolocation not supported by this browser"});
        return;
    }
    navigator.geolocation.getCurrentPosition(
        (position) => {
            resolve({
                coords: {
                    latitude: position.coords.latitude,
                    longitude: position.coords.longitude,
                    accuracy: position.coords.accuracy,
                    altitude: position.coords.altitude,
                    altitudeAccuracy: position.coords.altitudeAccuracy,
                    heading: position.coords.heading,
                    speed: position.coords.speed
                },
                timestamp: position.timestamp

            });
        },
        (error) => {
            resolve({error: error.message, code: error.code});
        },
        {
            enableHighAccuracy: true,
            timeout: 15000,
            maximumAge: 0
        }
    );
});
"""


def get_precise_geolocation(retry_count: int = 0):
    """Manually-triggered (click-only) high-accuracy geolocation request.
    Only call this from inside an `if st.button(...):` block so the browser
    sees it as a genuine user gesture -- see the note above this JS block.
    """
    return streamlit_js_eval(
        js_expressions=_HIGH_ACCURACY_GEO_JS,
        key=f"hs_precise_geo_{retry_count}",
    )


# ---------------------------------------------------------------------------
# LOCALITY MAPPING HELPER
# ---------------------------------------------------------------------------
REAL_LOCALITY_MAP = {
    "delhi": ["Connaught Place", "Rohini Sector 10", "Karol Bagh", "Dwarka Sector 6", "Lajpat Nagar", "Chandni Chowk", "Pitampura", "Saket"],
    "nagpur": ["Sitabuldi", "Dharampeth", "Sadar", "Ramdaspeth", "Wardhaman Nagar", "Manish Nagar", "Civil Lines", "Gandhibagh"],
    "ahmedabad": ["Navrangpura", "Maninagar", "Vastrapur", "Satellite", "Bopal", "Paldi", "Ghatlodia", "Ellisbridge"],
    "mumbai": ["Dharavi", "Bandra West", "Andheri East", "Colaba", "Dadra Parel", "Borivali West", "Kurla", "Ghatkopar"],
    "kolkata": ["Park Street", "Salt Lake Sector 5", "Howrah Station", "Gariahat", "New Town", "Shyambazar", "Ballygunge", "Alipore"],
    "chennai": ["T. Nagar", "Adyar", "Mylapore", "Anna Nagar", "Velachery", "George Town", "Guindy", "Royapettah"],
    "hyderabad": ["Banjara Hills", "Secunderabad", "Gachibowli", "Charminar", "Kukatpally", "Madhapur", "Ameerpet", "Begumpet"],
    "jaipur": ["Malviya Nagar", "Vaishali Nagar", "C-Scheme", "Mansarovar", "Sanganer", "Jhotwara", "Bani Park", "Amer"],
}


def get_clean_area_name(city: str, ward_raw_name: str, index: int = 0) -> str:
    c_key = str(city).strip().lower()
    raw = str(ward_raw_name).strip()

    if "ward" in raw.lower() and c_key in REAL_LOCALITY_MAP:
        names = REAL_LOCALITY_MAP[c_key]
        num_part = "".join(filter(str.isdigit, raw))
        if num_part:
            idx = (int(num_part) - 1) % len(names)
            return names[idx]
        return names[index % len(names)]
    return raw


def find_nearest_location(lat: float, lon: float, locations_df: pd.DataFrame) -> dict | None:
    if locations_df is None or locations_df.empty:
        return None

    lat_col = next((c for c in locations_df.columns if c.lower() in ("latitude", "lat")), None)
    lon_col = next((c for c in locations_df.columns if c.lower() in ("longitude", "lon", "lng")), None)

    if not lat_col or not lon_col:
        return None

    def haversine(lat1, lon1, lat2, lon2):
        r = 6371.0
        dlat = math.radians(lat2 - lat1)
        dlon = math.radians(lon2 - lon1)
        a = (
            math.sin(dlat / 2) ** 2
            + math.cos(math.radians(lat1))
            * math.cos(math.radians(lat2))
            * math.sin(dlon / 2) ** 2
        )
        return 2 * r * math.atan2(math.sqrt(a), math.sqrt(1 - a))

    try:
        distances = locations_df.apply(
            lambda row: haversine(
                float(lat),
                float(lon),
                float(row[lat_col]),
                float(row[lon_col]),
            ),
            axis=1,
        )
        nearest_idx = distances.idxmin()
        nearest_row = locations_df.loc[nearest_idx].to_dict()
        nearest_row["distance_km"] = round(float(distances.min()), 1)
        return nearest_row
    except Exception:
        return None


ROLES_BY_GENDER = {
    "Male": [
        "Student",
        "Outdoor Worker",
        "Medical Staff",
        "Employer",
        "Senior Citizen",
        "Unemployed",
    ],
    "Female": [
        "Student",
        "Outdoor Worker",
        "Medical Staff",
        "Employer",
        "Pregnant Women",
        "Senior Citizen",
        "Infants",
        "Unemployed",
    ],
}


PAGE_NAME_TO_KEY = {
    "Dashboard": "dashboard",
    "Risk Map": "risk_map",
    "Location Analysis": "location_analysis",
    "Forecast": "forecast",
    "Vulnerability": "vulnerability",
    "Alerts": "alerts",
    "Precautions": "precautions",
    "Authority Dashboard": "authority_dashboard",
    "Methodology": "methodology",
    "About": "about",
}


def init_session_state() -> None:
    defaults = {
        "booted": False,
        "page": "Dashboard",
        "selected_city": DEFAULT_LOCATION,
        "selected_ward": None,
        "selected_role": "Student",
        "selected_language_label": "English",
        "scenario_active": False,
        "forecast_range": "5 DAYS",
        "user_gps": None,
        "use_live_gps": False,
        "data_saver": False,
        "location_search_results": [],
        "location_search_selected": None,
        "location_search_weather": None,
    }

    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def current_lang_code() -> str:
    return LANGUAGES.get(
        st.session_state.get("selected_language_label", "English"),
        "en",
    )


def t(key: str) -> str:
    return get_text(key, current_lang_code())


def build_local_place_index(locations_df: pd.DataFrame) -> list[dict]:
    """
    Every locality we actually have simulated HTSS/forecast data for —
    one entry per (city, ward) row in locations.csv, labeled with its
    real-sounding locality name (via REAL_LOCALITY_MAP) instead of the
    generic 'Ward N'. This is what location search should match against
    first, since selecting one of these can genuinely switch the whole
    dashboard's data (unlike an arbitrary live-geocoded place).
    """
    if locations_df is None or locations_df.empty:
        return []

    entries = []
    for _, row in locations_df.iterrows():
        city = str(row.get("city", "")).strip()
        ward = str(row.get("ward_name", "")).strip()
        if not city or not ward:
            continue
        locality = get_clean_area_name(city, ward)
        entries.append({
            "label": f"{locality}, {city}",
            "city": city,
            "ward_name": ward,
            "location_id": row.get("location_id"),
            "lat": row.get("lat"),
            "lon": row.get("lon"),
            "source": "local",
        })
    return entries


def search_local_places(query: str, locations_df: pd.DataFrame, limit: int = 8) -> list[dict]:
    q = (query or "").strip().lower()
    if not q:
        return []
    matches = [
        e for e in build_local_place_index(locations_df)
        if q in e["label"].lower() or q in e["city"].lower()
    ]
    return matches[:limit]


def render_location_search(is_dark: bool = False, locations_df: pd.DataFrame | None = None) -> None:
    """
    Sidebar widget: search for a place. Localities that belong to one of
    our supported demo cities (Nagpur, Delhi, Ahmedabad, Chennai,
    Hyderabad, Jaipur, ...) are matched against our own locations.csv
    first — picking one of those actually switches the whole app's
    active city/ward, so every page (dashboard, forecast, risk map,
    precautions) updates to that place's real simulated data.

    Anywhere else in India can still be searched (via Nominatim) for a
    quick live-weather-only preview, but since we don't have historical
    HTSS/forecast data simulated for arbitrary places, that preview
    can't drive the full dashboard — this is called out in the UI.
    """
    st.markdown("**🔍 SEARCH LOCATION**")

    query = st.text_input(
        "Search any place",
        placeholder="e.g. Sadar, Dwarka, Gachibowli, Jaipur...",
        key="location_search_query",
        label_visibility="collapsed",
    )

    col_search, col_clear = st.columns([3, 1])
    do_search = col_search.button("Search", key="location_search_btn", use_container_width=True)
    do_clear = col_clear.button("✕", key="location_search_clear_btn", use_container_width=True, help="Clear search")

    if do_clear:
        st.session_state["location_search_results"] = []
        st.session_state["location_search_selected"] = None
        st.session_state["location_search_weather"] = None
        st.rerun()

    if do_search:
        st.session_state["location_search_weather"] = None
        if query and query.strip():
            local_matches = search_local_places(query.strip(), locations_df)
            with st.spinner("Searching..."):
                live_matches = search_places(query.strip())
            # De-dupe: don't show a live result for a city we already
            # matched locally under the same name.
            local_labels = {m["label"].lower() for m in local_matches}
            live_matches = [
                {**m, "source": "live"} for m in live_matches
                if m["label"].lower() not in local_labels
            ]
            st.session_state["location_search_results"] = local_matches + live_matches
            if not st.session_state["location_search_results"]:
                st.warning("No matching places found. Try a different name.")
        else:
            st.session_state["location_search_results"] = []

    results = st.session_state.get("location_search_results") or []

    if results:
        def _display(r: dict) -> str:
            return f"🏠 {r['label']} (demo data)" if r["source"] == "local" else f"🌐 {r['label']} (live only)"

        chosen_display = st.selectbox(
            "Matching places",
            [_display(r) for r in results],
            key="location_search_pick",
            label_visibility="collapsed",
        )
        chosen = next((r for r in results if _display(r) == chosen_display), None)

        if chosen and chosen["source"] == "local":
            st.caption("This locality has full simulated forecast & risk data.")
            if st.button("📍 Switch dashboard to this location", key="location_search_switch_btn", use_container_width=True):
                st.session_state["selected_city"] = chosen["city"]
                st.session_state["city_selector_widget"] = chosen["city"]
                st.session_state["selected_ward"] = chosen["ward_name"]
                st.session_state["location_search_selected"] = chosen
                st.session_state["location_search_weather"] = None
                st.session_state["use_live_gps"] = False
                st.rerun()
        elif chosen:
            st.caption("Outside our supported demo cities — showing live weather only, not the full risk dashboard.")
            if st.button("📡 Get live weather", key="location_search_fetch_btn", use_container_width=True):
                st.session_state["location_search_selected"] = chosen
                with st.spinner("Fetching live weather..."):
                    fetched = get_weather_by_coords(chosen["lat"], chosen["lon"])
                st.session_state["location_search_weather"] = fetched
                if fetched is None:
                    st.warning("Couldn't fetch live weather for this place right now. Try again in a moment.")

    weather = st.session_state.get("location_search_weather")
    selected = st.session_state.get("location_search_selected")

    if selected and weather and selected.get("source") != "local":
        card_bg = "rgba(59, 130, 246, 0.12)"
        border_color = "#3B82F6"
        heading_color = "#93C5FD" if is_dark else "#1D4ED8"
        text_color = "#F4F6FB" if is_dark else "#0A2540"

        feels_like = weather.get("feels_like_c")
        feels_like_html = (
            f"<div style='font-size:0.75rem; color:{text_color}; margin-top:2px;'>"
            f"🌡️ Feels like: <b>{feels_like:.1f}°C</b></div>"
            if feels_like is not None else ""
        )

        st.markdown(
            f"""
            <div style="background:{card_bg}; border:1.5px solid {border_color};
                        border-radius:12px; padding:12px 14px; margin-top:10px;">
                <div style="font-weight:800; font-size:0.82rem; color:{heading_color};">
                    📍 {selected['label']}
                </div>
                <div style="font-size:0.8rem; font-weight:700; margin-top:6px; color:{text_color};">
                    🌡️ Temperature: <b>{weather['temperature_c']:.1f}°C</b>
                </div>
                <div style="font-size:0.8rem; font-weight:700; margin-top:3px; color:{text_color};">
                    💧 Humidity: <b>{weather['humidity_pct']:.0f}%</b>
                </div>
                <div style="font-size:0.8rem; font-weight:700; margin-top:3px; color:{text_color};">
                    💨 Wind: <b>{weather['wind_ms']:.1f} m/s</b>
                </div>
                <div style="font-size:0.8rem; font-weight:700; margin-top:3px; color:{text_color};">
                    ☀️ Solar Radiation: <b>{weather['solar_radiation_wm2']:.0f} W/m²</b>
                </div>
                {feels_like_html}
                <div style="font-size:0.68rem; color:#94A3B8; margin-top:6px;">
                    Live data · Open-Meteo
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )


def render_sidebar(locations_df) -> None:
    is_dark = get_current_theme() == "dark"

    with st.sidebar:
        st.markdown(
            f"""
            <div style="padding: 8px 0 16px 0;">
                <div style="font-size:1.3rem; font-weight:800;">
                    🛡️ {APP_NAME}
                </div>
                <div style="font-size:0.75rem; color:#9AA5B8; margin-top:2px;">
                    {APP_TAGLINE}
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        st.markdown("**⚡ DATA SAVER MODE**")
        st.toggle(
            "Low-Bandwidth Mode",
            key="data_saver",
            help="ON disables heavy WebGL animations, live Folium maps, and Plotly charts for 2G/low-bandwidth conditions.",
        )
        if st.session_state.get("data_saver", False):
            st.markdown(
                '<div style="font-size:.75rem; font-weight:800; color:#10B981; margin-top:-6px; margin-bottom:12px;">'
                '✓ ACTIVE · LIGHTWEIGHT TEXT & CARDS</div>',
                unsafe_allow_html=True,
            )
        else:
            st.markdown(
                '<div style="font-size:.75rem; font-weight:700; color:#94A3B8; margin-top:-6px; margin-bottom:12px;">'
                'FULL GRAPHICS & INTERACTIVE MAPS</div>',
                unsafe_allow_html=True,
            )

        st.markdown("<hr class='hs-divider' style='margin:4px 0 12px 0;'/>", unsafe_allow_html=True)

        st.markdown("**📍 LIVE GPS STATUS**")

        if JS_EVAL_AVAILABLE:
            loc_data = get_geolocation()

            if loc_data and "coords" in loc_data:
                coords = loc_data["coords"]
                lat = coords.get("latitude")
                lon = coords.get("longitude")
                accuracy = coords.get("accuracy", 0)

                if lat is not None and lon is not None:
                    prev_gps = st.session_state.get("user_gps")
                    if not prev_gps or prev_gps.get("latitude") != lat or prev_gps.get("longitude") != lon:
                        nearest = find_nearest_location(lat, lon, locations_df)
                        st.session_state["user_gps"] = {
                            "latitude": lat,
                            "longitude": lon,
                            "accuracy_m": accuracy,
                            "nearest": nearest,
                        }
                        st.session_state["use_live_gps"] = True

                        if nearest and nearest.get("city") in DEMO_LOCATIONS:
                            st.session_state["selected_city"] = nearest["city"]
                            # The city dropdown further down is a widget
                            # bound to its OWN key ("city_selector_widget").
                            # Once that widget has been instantiated once,
                            # it "owns" its key going forward, so updating
                            # "selected_city" alone gets silently shadowed
                            # by the widget's remembered value on the next
                            # render -- this was the reason GPS-detected
                            # locations (e.g. Paschim Vihar East, Delhi)
                            # never actually stuck and the app kept falling
                            # back to the default city (Nagpur). Writing
                            # to the widget's key here too forces it to
                            # pick up the GPS-resolved city immediately.
                            st.session_state["city_selector_widget"] = nearest["city"]
                            if nearest.get("ward_name"):
                                st.session_state["selected_ward"] = nearest["ward_name"]
            elif loc_data and "error" in loc_data:
                # Surface the REAL browser error instead of silently falling
                # through to a generic "waiting for permission" message --
                # that generic message used to show up for every failure
                # mode (denied, blocked by iframe policy, insecure origin,
                # timeout, unsupported browser...), which made this
                # impossible to debug from the outside.
                st.session_state["gps_last_error"] = loc_data["error"]

            gps_info = st.session_state.get("user_gps")
            if gps_info:
                lat = gps_info["latitude"]
                lon = gps_info["longitude"]
                nearest = gps_info.get("nearest")
                
                raw_ward = nearest.get("ward_name", "Ward 1") if nearest else "Ward 1"
                c_name = nearest.get("city", "Delhi") if nearest else "Delhi"

                # Prefer the REAL locality for these exact coordinates (via
                # reverse geocoding) over the nearest-demo-ward's fake mapped
                # name. The fake mapping only depends on which of a handful
                # of demo ward points is closest, so users in genuinely
                # different neighbourhoods (e.g. Mahavir Enclave, Shalimar
                # Bagh, Paschim Vihar) were all shown the same 1-2 recycled
                # names (Karol Bagh / Rohini) regardless of where they
                # actually were. Reverse geocoding reads the true lat/lon,
                # so it correctly distinguishes them. Falls back to the old
                # fake name only if the geocoding API is unreachable.
                real_loc = reverse_geocode(lat, lon)
                clean_loc = real_loc if real_loc else get_clean_area_name(c_name, raw_ward)

                nearest_name = clean_loc if (nearest and real_loc) else (f"{clean_loc}, {c_name}" if nearest else "Analyzing area...")
                acc_m = gps_info.get("accuracy_m", 0) or 0
                source_tag = f"📡 live geocoded · ±{acc_m:.0f}m accuracy" if real_loc else "≈ estimated (fallback)"
                dist = f"({nearest['distance_km']} km away)" if nearest else ""
                low_accuracy = acc_m and acc_m > 500

                tracking_heading_color = "#34D399" if is_dark else "#059669"
                tracking_coords_color = "#F4F6FB" if is_dark else "#0A352C"
                tracking_location_color = "#C9D6EA" if is_dark else "#3A6357"

                st.markdown(
                    f"""
                    <div style="background: rgba(16, 185, 129, 0.12); border: 1.5px solid #10B981;
                                border-radius: 12px; padding: 12px 14px; margin-bottom: 12px;">
                        <div style="display:flex; align-items:center; gap:8px; font-weight:800; font-size:0.82rem; color:{tracking_heading_color};">
                            <span style="width:9px; height:9px; border-radius:50%; background:#10B981; display:inline-block;" class="hs-pulse"></span>
                            TRACKING ACTIVE
                        </div>
                        <div style="font-size:0.80rem; font-weight:700; margin-top:6px; color:{tracking_coords_color};">
                            📍 Coords: {lat:.4f}, {lon:.4f}
                        </div>
                        <div style="font-size:0.75rem; color:{tracking_location_color}; margin-top:3px; font-weight:600;">
                            Location: <b>{nearest_name}</b> {dist}
                        </div>
                        <div style="font-size:0.68rem; color:{tracking_location_color}; margin-top:2px; opacity:0.75;">
                            {source_tag}
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )
                if low_accuracy:
                    st.markdown(
                        '<div style="font-size:.72rem; font-weight:600; color:#D97706; margin-top:-8px; margin-bottom:12px;">'
                        '⚠️ Low-precision fix (Wi-Fi/network based, not GPS). Phone me Location mode ko '
                        '<b>"High accuracy" / "Precise location"</b> par set karein, phir neeche button dabayein.'
                        '</div>',
                        unsafe_allow_html=True,
                    )
                    if st.button("🎯 Get a more precise GPS fix", key="hs_gps_precise_btn"):
                        st.session_state["hs_geo_retry_count"] = st.session_state.get("hs_geo_retry_count", 0) + 1
                        result = get_precise_geolocation(st.session_state["hs_geo_retry_count"])
                        if result and "coords" in result:
                            c = result["coords"]
                            rlat, rlon = c.get("latitude"), c.get("longitude")
                            if rlat is not None and rlon is not None:
                                nearest = find_nearest_location(rlat, rlon, locations_df)
                                st.session_state["user_gps"] = {
                                    "latitude": rlat,
                                    "longitude": rlon,
                                    "accuracy_m": c.get("accuracy", 0),
                                    "nearest": nearest,
                                }
                                st.rerun()
                        elif result and "error" in result:
                            st.caption(f"Browser ne mana kiya: {result['error']}")
            else:
                waiting_heading_color = "#FCD34D" if is_dark else "#D97706"
                waiting_body_color = "#FDE9C8" if is_dark else "#78350F"
                last_err = st.session_state.get("gps_last_error")

                if last_err:
                    st.markdown(
                        f"""
                        <div style="background: rgba(245, 158, 11, 0.12); border: 1.5px solid #F59E0B;
                                    border-radius: 12px; padding: 10px 14px; margin-bottom: 12px;">
                            <div style="font-weight:700; font-size:0.80rem; color:{waiting_heading_color};">
                                ⚠️ GPS ERROR
                            </div>
                            <div style="font-size:0.75rem; color:{waiting_body_color}; margin-top:4px;">
                                Browser ne bola: <b>{last_err}</b><br/>
                                Agar koi popup hi nahi aaya to Browser URL bar me <b>Lock icon (🔒)</b> par click
                                karke Location: Allow karein, phir neeche button dabayein.
                            </div>
                        </div>
                        """,
                        unsafe_allow_html=True,
                    )
                else:
                    st.markdown(
                        f"""
                        <div style="background: rgba(245, 158, 11, 0.12); border: 1.5px solid #F59E0B;
                                    border-radius: 12px; padding: 10px 14px; margin-bottom: 12px;">
                            <div style="font-weight:700; font-size:0.80rem; color:{waiting_heading_color};">
                                ⚠️ GPS WAITING FOR PERMISSION
                            </div>
                            <div style="font-size:0.75rem; color:{waiting_body_color}; margin-top:4px;">
                                Browser URL bar me <b>Lock icon (🔒)</b> par click karke Location: Allow karein.
                                Uske baad neeche button dabayein.
                            </div>
                        </div>
                        """,
                        unsafe_allow_html=True,
                    )

                # Manual, click-triggered retry. Tied directly to a real
                # user gesture (the click itself) instead of firing
                # automatically on every rerun -- this is both what the
                # browser needs to reliably show the permission prompt and
                # what avoids streamlit_js_eval's page-reset bug when it's
                # auto-triggered outside a click handler.
                if st.button("📍 Enable / Retry Location", key="hs_gps_retry_btn"):
                    st.session_state["hs_geo_retry_count"] = st.session_state.get("hs_geo_retry_count", 0) + 1
                    result = get_precise_geolocation(st.session_state["hs_geo_retry_count"])
                    if result and "coords" in result:
                        c = result["coords"]
                        rlat, rlon = c.get("latitude"), c.get("longitude")
                        if rlat is not None and rlon is not None:
                            nearest = find_nearest_location(rlat, rlon, locations_df)
                            st.session_state["user_gps"] = {
                                "latitude": rlat,
                                "longitude": rlon,
                                "accuracy_m": c.get("accuracy", 0),
                                "nearest": nearest,
                            }
                            st.session_state["use_live_gps"] = True
                            st.session_state["gps_last_error"] = None
                            st.rerun()
                    elif result and "error" in result:
                        st.session_state["gps_last_error"] = result["error"]
                        st.rerun()
                    else:
                        st.caption("Browser se abhi tak koi response nahi aaya — button dubara dabayein.")
        else:
            st.caption("GPS tracking module inactive.")

        st.markdown("<hr class='hs-divider'/>", unsafe_allow_html=True)

        render_location_search(is_dark, locations_df)

        st.markdown("<hr class='hs-divider'/>", unsafe_allow_html=True)

        st.markdown("**NAVIGATION**")

        user_type = st.session_state.get("user_profile", {}).get("user_type", "Citizen")

        if user_type == "Authority":
            allowed_pages = [
                ("🏛️", "Authority Dashboard"),
                ("🏠", "Dashboard"),
                ("🗺️", "Risk Map"),
                ("📈", "Forecast"),
                ("🧭", "Vulnerability"),
                ("🚨", "Alerts"),
            ]
        else:
            allowed_pages = [
                item for item in NAV_PAGES 
                if item[1] not in ("Authority Dashboard", "Methodology", "SMS Alerts")
            ]

        for icon, page_name in allowed_pages:
            is_active = st.session_state["page"] == page_name
            nav_label = t(page_name.strip().lower().replace(" ", "_"))

            if st.button(
                f"{icon}  {nav_label}",
                key=f"nav_{page_name}",
                use_container_width=True,
                type="primary" if is_active else "secondary",
            ):
                st.session_state["page"] = page_name
                st.rerun()

        st.markdown("<hr class='hs-divider'/>", unsafe_allow_html=True)

        st.markdown("**FILTERS**")

        # NOTE: this widget deliberately uses its OWN key
        # ("city_selector_widget") instead of "selected_city" directly.
        # "selected_city" is the logical, app-wide source of truth that
        # GPS detection and location search also write to. If this widget
        # used key="selected_city" itself, Streamlit would treat that key
        # as owned by the widget from then on, and any GPS-driven update
        # (e.g. a real Paschim Vihar East, Delhi fix) would get silently
        # shadowed on the very next rerun, snapping the app back to the
        # default city (Nagpur) -- which was exactly the bug being fixed.
        city = st.selectbox(
            t("select_location"),
            DEMO_LOCATIONS,
            index=(
                DEMO_LOCATIONS.index(st.session_state["selected_city"])
                if st.session_state["selected_city"] in DEMO_LOCATIONS
                else 0
            ),
            key="city_selector_widget",
        )

        if city != st.session_state.get("selected_city"):
            # A manual pick from the dropdown should win over GPS from
            # here on, otherwise the next GPS-triggered rerun would just
            # snap the dropdown straight back to the GPS-matched city.
            st.session_state["use_live_gps"] = False

        st.session_state["selected_city"] = city

        if (
            locations_df is not None
            and not locations_df.empty
            and "city" in locations_df.columns
            and "ward_name" in locations_df.columns
        ):
            wards = (
                locations_df[locations_df["city"] == city]["ward_name"]
                .dropna()
                .astype(str)
                .unique()
                .tolist()
            )
            # Only reset the ward when the current one isn't valid for this
            # city (e.g. after a manual city change). This preserves the
            # ward that live GPS tracking already matched above, instead of
            # always overwriting it back to the city's first ward.
            if wards:
                if st.session_state.get("selected_ward") not in wards:
                    st.session_state["selected_ward"] = wards[0]
            else:
                st.session_state["selected_ward"] = None
        else:
            st.session_state["selected_ward"] = None

        st.selectbox(
            t("select_language"),
            list(LANGUAGES.keys()),
            key="selected_language_label",
        )

        st.markdown("<hr class='hs-divider'/>", unsafe_allow_html=True)
        st.markdown("**DEMO CONTROLS**")

        if st.button("🔥 " + t("run_extreme_scenario"), use_container_width=True):
            st.session_state["scenario_active"] = not st.session_state["scenario_active"]
            st.rerun()

        if st.session_state["scenario_active"]:
            st.markdown(
                """
                <div style="background:rgba(231,76,60,0.15); border:1px solid #E74C3C;
                            border-radius:10px; padding:8px 12px; font-size:0.8rem; margin-top:8px;">
                    ⚠️ Extreme Heat Scenario ACTIVE
                </div>
                """,
                unsafe_allow_html=True,
            )

        st.markdown("<hr class='hs-divider'/>", unsafe_allow_html=True)
        st.caption("Prototype decision-support system. Not an official government alert service.")


def render_role_selector() -> None:
    user_info = st.session_state.get("user_profile", {})
    user_gender = str(user_info.get("gender", "Female")).capitalize()
    
    if user_gender not in ROLES_BY_GENDER:
        user_gender = "Female"

    allowed_roles = ROLES_BY_GENDER[user_gender]

    if st.session_state.get("selected_role") not in allowed_roles:
        st.session_state["selected_role"] = allowed_roles[0]

    role_label = t("select_role")
    st.markdown(f'<div class="hs-role-pill-label">{role_label}</div>', unsafe_allow_html=True)

    selected = st.selectbox(
        role_label,
        allowed_roles,
        index=allowed_roles.index(st.session_state["selected_role"]),
        format_func=lambda x: f"👤   {x}",
        key="role_selector_widget",
        label_visibility="collapsed",
    )
    st.session_state["selected_role"] = selected


def get_selected_location_id(locations_df) -> str:
    city = str(st.session_state.get("selected_city", "")).strip().lower()
    ward = str(st.session_state.get("selected_ward", "")).strip().lower() if st.session_state.get("selected_ward") else None

    if locations_df is None or locations_df.empty:
        return ""

    df_clean = locations_df.copy()
    if "city" in df_clean.columns:
        df_clean["city_norm"] = df_clean["city"].astype(str).str.strip().str.lower()
    if "ward_name" in df_clean.columns:
        df_clean["ward_norm"] = df_clean["ward_name"].astype(str).str.strip().str.lower()

    if ward and "ward_norm" in df_clean.columns:
        match = df_clean[(df_clean["city_norm"] == city) & (df_clean["ward_norm"] == ward)]
    else:
        match = df_clean[df_clean["city_norm"] == city]

    if not match.empty and "location_id" in match.columns:
        return str(match.iloc[0]["location_id"])

    return str(locations_df.iloc[0]["location_id"])


def scenario_boost() -> float:
    return 1.0 if st.session_state.get("scenario_active") else 0.0