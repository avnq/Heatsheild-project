"""
frontend/maps.py

Interactive Folium risk map builder using Google Maps tiles and live user GPS pin.
Includes reliable layer toggles, responsive click popups, and marker clustering
for Hospitals, Cooling Centres, and Water Points with real landmark names.
"""

from __future__ import annotations

import folium
import pandas as pd
from folium.plugins import MarkerCluster
import streamlit as st


# Bundled real landmark directory (No generic Ward 1, Ward 2 labels)
DEFAULT_CITY_HOSPITALS: dict[str, list[dict]] = {
    "delhi": [
        {"hospital_name": "AIIMS Emergency Heat & Trauma Ward", "beds": 450, "latitude": 28.5672, "longitude": 77.2100},
        {"hospital_name": "Safdarjung Multi-Speciality Heat Care", "beds": 380, "latitude": 28.5701, "longitude": 77.2079},
        {"hospital_name": "Deen Dayal Upadhyay Hospital (DDU)", "beds": 280, "latitude": 28.6289, "longitude": 77.1124},
        {"hospital_name": "Indira Gandhi Super Speciality Hospital Dwarka", "beds": 310, "latitude": 28.5810, "longitude": 77.0650},
        {"hospital_name": "Maharaja Agrasen Hospital Punjabi Bagh", "beds": 190, "latitude": 28.5921, "longitude": 77.0865},
        {"hospital_name": "Ram Manohar Lohia (RML) Dedicated Heat Clinic", "beds": 240, "latitude": 28.6234, "longitude": 77.2005},
        {"hospital_name": "Lok Nayak Jai Prakash (LNJP) Hospital", "beds": 350, "latitude": 28.6369, "longitude": 77.2410},
    ],
    "nagpur": [
        {"hospital_name": "Government Medical College & Hospital (GMCH)", "beds": 350, "latitude": 21.1450, "longitude": 79.0366},
        {"hospital_name": "Fortis Multispeciality Heat Ward Nagpur", "beds": 237, "latitude": 21.1236, "longitude": 79.1487},
        {"hospital_name": "Alexis Multispeciality Hospital Mankapur", "beds": 235, "latitude": 21.1160, "longitude": 79.0632},
        {"hospital_name": "Wockhardt Super Speciality Hospital Shankar Nagar", "beds": 180, "latitude": 21.1084, "longitude": 79.0599},
        {"hospital_name": "Orange City Hospital & Research Institute", "beds": 87, "latitude": 21.1321, "longitude": 79.1158},
        {"hospital_name": "Kingsway Hospitals Dharampeth", "beds": 21, "latitude": 21.1449, "longitude": 79.0408},
    ]
}

DEFAULT_COOLING_CENTRES: dict[str, list[dict]] = {
    "delhi": [
        {"name": "Janakpuri District Centre AC Public Hall", "type": "Municipal AC Shelter", "capacity": "250 Persons", "latitude": 28.6285, "longitude": 77.0815},
        {"name": "Dwarka Sector 10 Metro Interchange Cool Zone", "type": "Transit Cooling Hub", "capacity": "350 Persons", "latitude": 28.5811, "longitude": 77.0580},
        {"name": "Rajiv Chowk Underpass Central Relief Shelter", "type": "Civic Cooling Pavilion", "capacity": "500 Persons", "latitude": 28.6328, "longitude": 77.2197},
        {"name": "Uttam Nagar Terminal Air-Cooled Relief Camp", "type": "Public AC Shelter", "capacity": "180 Persons", "latitude": 28.6212, "longitude": 77.0520},
        {"name": "Lajpat Nagar Central Market Community AC Hub", "type": "Commercial Shelter Partner", "capacity": "200 Persons", "latitude": 28.5680, "longitude": 77.2435},
        {"name": "Kashmere Gate ISBT Shaded Air-Cooled Transit Zone", "type": "Transit Terminal Shelter", "capacity": "450 Persons", "latitude": 28.6675, "longitude": 77.2285},
    ],
    "nagpur": [
        {"name": "Sitabuldi Metro Interchange AC Relief Hub", "type": "Public Cooling Centre", "capacity": "250 Persons", "latitude": 21.1458, "longitude": 79.0820},
        {"name": "Dharampeth Public AC Community Shelter", "type": "Municipal AC Shelter", "capacity": "150 Persons", "latitude": 21.1390, "longitude": 79.0610},
        {"name": "Gandhibagh Municipal Town Hall AC Shelter", "type": "Civic Cooling Pavilion", "capacity": "300 Persons", "latitude": 21.1512, "longitude": 79.1023},
        {"name": "Reshimbagh Indoor Sports Complex Cooling Ward", "type": "Emergency AC Hall", "capacity": "400 Persons", "latitude": 21.1275, "longitude": 79.1090},
    ]
}

DEFAULT_WATER_POINTS: dict[str, list[dict]] = {
    "delhi": [
        {"name": "Delhi Jal Board RO Kiosk - Janakpuri B-Block", "type": "Chilled RO Water Kiosk", "latitude": 28.6250, "longitude": 77.0910},
        {"name": "Palam Flyover Solar-Powered Water ATM", "type": "24x7 Water ATM", "latitude": 28.5910, "longitude": 77.0920},
        {"name": "Connaught Place Radial-2 Municipal Water Fountain", "type": "Filtered Chilled Dispenser", "latitude": 28.6315, "longitude": 77.2185},
        {"name": "Dwarka Mor High-Capacity Cold Water Booth", "type": "High Discharge RO Booth", "latitude": 28.6180, "longitude": 77.0340},
        {"name": "Chandni Chowk Heritage Water Piao Station", "type": "Traditional Public Piao", "latitude": 28.6560, "longitude": 77.2305},
        {"name": "Nehru Place Bus Terminal Water ATM", "type": "Chilled Public Kiosk", "latitude": 28.5495, "longitude": 77.2530},
    ],
    "nagpur": [
        {"name": "Nagpur Municipal Chilled RO Kiosk - Civil Lines", "type": "Chilled RO Water", "latitude": 21.1520, "longitude": 79.0720},
        {"name": "Medical Square 24x7 Drinking Water ATM", "type": "24x7 Water ATM", "latitude": 21.1340, "longitude": 79.0960},
        {"name": "Reshimbagh Ground Solar Cold Water Fountain", "type": "Solar Chilled Dispenser", "latitude": 21.1275, "longitude": 79.1090},
        {"name": "Nagpur Railway Station West Gate Water Booth", "type": "Rapid RO Dispenser", "latitude": 21.1525, "longitude": 79.0885},
    ]
}


def _get_map_theme_tokens() -> dict:
    is_light = st.session_state.get("theme", "light") == "light"
    if is_light:
        return {
            "popup_bg": "#FFFFFF",
            "popup_text": "#0F172A",
            "popup_sub": "#64748B",
            "popup_border": "rgba(15, 23, 42, 0.10)",
        }
    return {
        "popup_bg": "#131A2A",
        "popup_text": "#F4F6FB",
        "popup_sub": "#9AA5B8",
        "popup_border": "rgba(255, 255, 255, 0.12)",
    }


def _find_col(df: pd.DataFrame, names: list[str]) -> str | None:
    if df is None or df.empty:
        return None
    normalized = {str(c).strip().lower(): c for c in df.columns}
    for name in names:
        if name.lower() in normalized:
            return normalized[name.lower()]
    for col in df.columns:
        low = str(col).strip().lower()
        for name in names:
            if name.lower() in low:
                return col
    return None


def _number(value, default=0.0) -> float:
    try:
        if pd.isna(value):
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def _lat_lon(row):
    lat_col = _find_col(row.to_frame().T, ["latitude", "lat"])
    lon_col = _find_col(row.to_frame().T, ["longitude", "lon", "lng"])
    if lat_col is None or lon_col is None:
        return None, None
    lat = _number(row[lat_col], None)
    lon = _number(row[lon_col], None)
    if lat is None or lon is None:
        return None, None
    return lat, lon


def _risk_color(risk) -> str:
    value = _number(risk)
    if value >= 80:
        return "#E74C3C"
    if value >= 60:
        return "#E67E22"
    if value >= 40:
        return "#F39C12"
    return "#2ECC71"


def build_risk_map(
    map_df: pd.DataFrame | None,
    center_city: str = "Delhi",
    show_hospitals: bool = True,
    hospitals_df: pd.DataFrame | None = None,
    show_cooling: bool = True,
    cooling_df: pd.DataFrame | None = None,
    show_water: bool = True,
    water_df: pd.DataFrame | None = None,
) -> folium.Map:
    """Build the HeatShield India interactive risk map using Google Maps basemap and GPS tracking."""
    city_centers = {
        "delhi": (28.6139, 77.1500),
        "new delhi": (28.6139, 77.2090),
        "nagpur": (21.1458, 79.0882),
        "mumbai": (19.0760, 72.8777),
        "kolkata": (22.5726, 88.3639),
        "chennai": (13.0827, 80.2707),
        "bengaluru": (12.9716, 77.5946),
        "hyderabad": (17.3850, 78.4867),
        "ahmedabad": (23.0225, 72.5714),
        "jaipur": (26.9124, 75.7873),
        "lucknow": (26.8467, 80.9462),
        "pune": (18.5204, 73.8567),
    }

    user_gps = st.session_state.get("user_gps")
    city_key = str(center_city or "Delhi").strip().lower()

    if user_gps and "latitude" in user_gps and "longitude" in user_gps:
        center = (user_gps["latitude"], user_gps["longitude"])
        zoom_level = 13
    else:
        center = city_centers.get(city_key, (28.6139, 77.1500))
        zoom_level = 12

    theme = _get_map_theme_tokens()

    fmap = folium.Map(
        location=center,
        zoom_start=zoom_level,
        control_scale=True,
        tiles=None,
    )

    # Google Maps standard roadmap tiles
    folium.TileLayer(
        tiles="https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}",
        attr="Google Maps",
        name="Google Maps",
        control=True,
        max_zoom=20,
    ).add_to(fmap)

    # Google Maps Terrain tiles
    folium.TileLayer(
        tiles="https://mt1.google.com/vt/lyrs=p&x={x}&y={y}&z={z}",
        attr="Google Maps Terrain",
        name="Google Terrain",
        control=True,
        max_zoom=20,
    ).add_to(fmap)

    # -------------------------
    # Heat Risk Layer
    # -------------------------
    risk_layer = folium.FeatureGroup(name="Heat Risk", show=True)
    if map_df is not None and not map_df.empty:
        for _, row in map_df.iterrows():
            lat, lon = _lat_lon(row)
            if lat is None or lon is None:
                continue

            ward_col = _find_col(map_df, ["ward", "ward_name", "name", "location", "area"])
            risk_col = _find_col(map_df, ["risk", "risk_score", "heat_risk", "score", "risk_index"])
            temp_col = _find_col(map_df, ["temperature", "temp", "temperature_c", "temp_c"])

            ward = str(row[ward_col]) if ward_col else "Area"
            risk = _number(row[risk_col]) if risk_col else 0
            temp = _number(row[temp_col]) if temp_col else None

            temp_text = (
                f"<div style='color:{theme['popup_sub']}; font-size:12px; margin-top:2px;'>"
                f"<b>Temp:</b> {temp:.1f} °C</div>"
                if temp is not None
                else ""
            )

            color = _risk_color(risk)
            popup_html = f"""
            <div style="font-family:'Inter',sans-serif; min-width:180px; padding:6px; color:#0F172A;">
                <div style="font-weight:800; font-size:14px; margin-bottom:4px;">{ward}</div>
                <div style="font-size:12px; margin-top:2px;"><b>Heat Risk:</b> <span style="color:{color}; font-weight:800;">{risk:.1f}</span></div>
                {temp_text}
            </div>
            """

            folium.CircleMarker(
                location=[lat, lon],
                radius=10,
                color=color,
                fill=True,
                fill_color=color,
                fill_opacity=0.75,
                weight=2,
                popup=folium.Popup(popup_html, max_width=280),
                tooltip=f"{ward} — Risk {risk:.1f}",
            ).add_to(risk_layer)

    risk_layer.add_to(fmap)

    # -------------------------
    # User Live Location Pin
    # -------------------------
    if user_gps and "latitude" in user_gps and "longitude" in user_gps:
        u_lat = user_gps["latitude"]
        u_lon = user_gps["longitude"]
        accuracy = user_gps.get("accuracy_m", 400)

        user_marker = folium.FeatureGroup(name="My Live Location", show=True)
        folium.Circle(
            location=[u_lat, u_lon],
            radius=max(150, float(accuracy)),
            color="#0284C7",
            fill=True,
            fill_color="#38BDF8",
            fill_opacity=0.20,
            weight=1.5,
        ).add_to(user_marker)

        folium.Marker(
            location=[u_lat, u_lon],
            tooltip="📍 You are here",
            popup=folium.Popup(
                """
                <div style="font-family:'Inter',sans-serif; padding:4px 6px; color:#0F172A;">
                    <b>Your Live Location</b><br/>
                    <span style="font-size:11px; color:#64748B;">GPS tracking active</span>
                </div>
                """,
                max_width=220,
            ),
            icon=folium.Icon(color="blue", icon="info-sign"),
        ).add_to(user_marker)
        user_marker.add_to(fmap)

    # -------------------------
    # 1. Hospitals Layer
    # -------------------------
    if show_hospitals:
        target_hosp_df = hospitals_df
        if target_hosp_df is None or target_hosp_df.empty:
            records = DEFAULT_CITY_HOSPITALS.get(city_key, DEFAULT_CITY_HOSPITALS.get("delhi", []))
            target_hosp_df = pd.DataFrame(records)

        hospital_layer = MarkerCluster(name="Hospitals", overlay=True, control=True)
        for _, row in target_hosp_df.iterrows():
            lat, lon = _lat_lon(row)
            if lat is None or lon is None:
                continue

            name_col = _find_col(target_hosp_df, ["hospital name", "name", "hospital", "facility"])
            beds_col = _find_col(target_hosp_df, ["beds", "dedicated heat ward", "capacity"])

            name = str(row[name_col]) if name_col else "Hospital"
            beds = str(row[beds_col]) if beds_col and beds_col in row else "Available"

            popup_html = f"""
            <div style="font-family:'Inter',sans-serif; min-width:210px; padding:6px; color:#0F172A;">
                <div style="font-size:14px; font-weight:800; color:#DC2626;">🏥 {name}</div>
                <div style="font-size:12px; color:#0D9488; font-weight:700; margin-top:3px;">Emergency Facility</div>
                <div style="font-size:12px; color:#334155; margin-top:3px;"><b>🛏️ Dedicated Heat Beds:</b> {beds}</div>
                <div style="font-size:12px; color:#334155; margin-top:2px;"><b>📞 Helpline:</b> 102 / 108</div>
                <div style="font-size:11px; color:#64748B; margin-top:4px;">📍 {lat:.5f}, {lon:.5f}</div>
            </div>
            """

            icon_html = """
            <div style="background-color:#EF4444; width:26px; height:26px; border-radius:50%;
                        display:flex; align-items:center; justify-content:center;
                        border:2px solid #FFFFFF; box-shadow:0 3px 8px rgba(0,0,0,0.35); color:#FFFFFF; 
                        font-size:17px; font-weight:900; line-height:1; user-select:none; cursor:pointer;">
                +
            </div>
            """

            folium.Marker(
                location=[lat, lon],
                tooltip=f"🏥 {name} ({beds} beds)",
                popup=folium.Popup(popup_html, max_width=270),
                icon=folium.DivIcon(html=icon_html, icon_size=(26, 26), icon_anchor=(13, 13)),
            ).add_to(hospital_layer)

        hospital_layer.add_to(fmap)

    # -------------------------
    # 2. Cooling Centres Layer
    # -------------------------
    if show_cooling:
        target_cooling_df = cooling_df
        if target_cooling_df is None or target_cooling_df.empty:
            records = DEFAULT_COOLING_CENTRES.get(city_key, DEFAULT_COOLING_CENTRES.get("delhi", []))
            target_cooling_df = pd.DataFrame(records)

        cooling_layer = MarkerCluster(name="Cooling Centres", overlay=True, control=True)
        for _, row in target_cooling_df.iterrows():
            lat, lon = _lat_lon(row)
            if lat is None or lon is None:
                continue

            name_col = _find_col(target_cooling_df, ["name", "centre", "center", "cooling_centre"])
            cap_col = _find_col(target_cooling_df, ["capacity", "persons", "type"])

            name = str(row[name_col]) if name_col else "Public Cooling Centre"
            cap = str(row[cap_col]) if cap_col and cap_col in row else "Open Access AC"

            popup_html = f"""
            <div style="font-family:'Inter',sans-serif; min-width:210px; padding:6px; color:#0F172A;">
                <div style="font-size:14px; font-weight:800; color:#0284C7;">❄️ {name}</div>
                <div style="font-size:12px; color:#0D9488; font-weight:700; margin-top:3px;">Air-Conditioned Relief Zone</div>
                <div style="font-size:12px; color:#334155; margin-top:3px;"><b>👥 Capacity:</b> {cap}</div>
                <div style="font-size:12px; color:#16A34A; margin-top:2px;"><b>💧 Services:</b> ORS Packets & Cold Water</div>
                <div style="font-size:11px; color:#64748B; margin-top:4px;">📍 {lat:.5f}, {lon:.5f}</div>
            </div>
            """

            icon_html = """
            <div style="background-color:#0284C7; width:26px; height:26px; border-radius:50%;
                        display:flex; align-items:center; justify-content:center;
                        border:2px solid #FFFFFF; box-shadow:0 3px 8px rgba(0,0,0,0.35); color:#FFFFFF; 
                        font-size:14px; font-weight:900; line-height:1; user-select:none; cursor:pointer;">
                ❄
            </div>
            """

            folium.Marker(
                location=[lat, lon],
                tooltip=f"❄️ {name}",
                popup=folium.Popup(popup_html, max_width=270),
                icon=folium.DivIcon(html=icon_html, icon_size=(26, 26), icon_anchor=(13, 13)),
            ).add_to(cooling_layer)

        cooling_layer.add_to(fmap)

    # -------------------------
    # 3. Water Points Layer
    # -------------------------
    if show_water:
        target_water_df = water_df
        if target_water_df is None or target_water_df.empty:
            records = DEFAULT_WATER_POINTS.get(city_key, DEFAULT_WATER_POINTS.get("delhi", []))
            target_water_df = pd.DataFrame(records)

        water_layer = MarkerCluster(name="Water Points", overlay=True, control=True)
        for _, row in target_water_df.iterrows():
            lat, lon = _lat_lon(row)
            if lat is None or lon is None:
                continue

            name_col = _find_col(target_water_df, ["name", "water_point", "location", "facility"])
            type_col = _find_col(target_water_df, ["type", "facility type", "status"])

            name = str(row[name_col]) if name_col else "Drinking Water Point"
            w_type = str(row[type_col]) if type_col and type_col in row else "Chilled Drinking Water"

            popup_html = f"""
            <div style="font-family:'Inter',sans-serif; min-width:200px; padding:6px; color:#0F172A;">
                <div style="font-size:14px; font-weight:800; color:#0D9488;">💧 {name}</div>
                <div style="font-size:12px; color:#0284C7; font-weight:700; margin-top:3px;">Hydration Station</div>
                <div style="font-size:12px; color:#334155; margin-top:3px;"><b>🚰 Type:</b> {w_type}</div>
                <div style="font-size:11px; color:#64748B; margin-top:4px;">📍 {lat:.5f}, {lon:.5f}</div>
            </div>
            """

            icon_html = """
            <div style="background-color:#0D9488; width:26px; height:26px; border-radius:50%;
                        display:flex; align-items:center; justify-content:center;
                        border:2px solid #FFFFFF; box-shadow:0 3px 8px rgba(0,0,0,0.35); color:#FFFFFF; 
                        font-size:14px; font-weight:900; line-height:1; user-select:none; cursor:pointer;">
                💧
            </div>
            """

            folium.Marker(
                location=[lat, lon],
                tooltip=f"💧 {name}",
                popup=folium.Popup(popup_html, max_width=270),
                icon=folium.DivIcon(html=icon_html, icon_size=(26, 26), icon_anchor=(13, 13)),
            ).add_to(water_layer)

        water_layer.add_to(fmap)

    folium.LayerControl(collapsed=False).add_to(fmap)
    return fmap