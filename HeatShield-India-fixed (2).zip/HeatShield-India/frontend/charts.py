"""
frontend/charts.py

Plotly chart builders supporting both dynamic Light and Dark themes.
Includes clean typography, high-contrast tooltips, and peak-risk highlighting.
"""

from __future__ import annotations

import pandas as pd
import plotly.graph_objects as go
import streamlit as st


def _get_theme_chart_tokens() -> dict:
    """Return Plotly visual tokens based on current active Streamlit theme."""
    is_light = st.session_state.get("theme", "dark") == "light"

    if is_light:
        return {
            "template": "plotly_white",
            "paper_bg": "rgba(0,0,0,0)",
            "plot_bg": "rgba(0,0,0,0)",
            "grid_color": "rgba(15, 23, 42, 0.08)",
            "font_color": "#0F172A",
            "muted_color": "#64748B",
            "donut_track": "rgba(15, 23, 42, 0.07)",
            "peak_highlight": "rgba(142, 68, 173, 0.15)",
            "fill_red": "rgba(231, 76, 60, 0.10)",
        }
    return {
        "template": "plotly_dark",
        "paper_bg": "rgba(0,0,0,0)",
        "plot_bg": "rgba(0,0,0,0)",
        "grid_color": "rgba(255,255,255,0.08)",
        "font_color": "#F4F6FB",
        "muted_color": "#9AA5B8",
        "donut_track": "rgba(255,255,255,0.06)",
        "peak_highlight": "rgba(142, 68, 173, 0.22)",
        "fill_red": "rgba(231, 76, 60, 0.12)",
    }


def _base_layout(
    fig: go.Figure,
    title: str = "",
    height: int = 360,
) -> go.Figure:
    """Apply the shared HeatShield India Plotly layout dynamically."""
    tokens = _get_theme_chart_tokens()

    fig.update_layout(
        template=tokens["template"],
        paper_bgcolor=tokens["paper_bg"],
        plot_bgcolor=tokens["plot_bg"],
        font=dict(
            color=tokens["font_color"],
            family="Inter, -apple-system, sans-serif",
        ),
        title=dict(
            text=title,
            font=dict(
                size=15,
                color=tokens["font_color"],
                weight=700,
            ),
        ),
        margin=dict(
            l=10,
            r=10,
            t=45 if title else 15,
            b=10,
        ),
        height=height,
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1,
            font=dict(color=tokens["font_color"]),
        ),
        hoverlabel=dict(
            font_family="Inter, sans-serif",
            font_size=12,
        ),
        hovermode="x unified",
    )

    fig.update_xaxes(
        gridcolor=tokens["grid_color"],
        zeroline=False,
        tickfont=dict(color=tokens["muted_color"]),
        title_font=dict(color=tokens["font_color"]),
    )

    fig.update_yaxes(
        gridcolor=tokens["grid_color"],
        zeroline=False,
        tickfont=dict(color=tokens["muted_color"]),
        title_font=dict(color=tokens["font_color"]),
    )

    return fig


def risk_timeline_chart(
    df: pd.DataFrame,
    peak_start: str | None = None,
    peak_end: str | None = None,
) -> go.Figure:
    """Time -> Health Risk line chart with optional peak-window highlight."""
    tokens = _get_theme_chart_tokens()
    fig = go.Figure()

    if df is None or df.empty:
        return _base_layout(fig, "Health Risk Over Time")

    fig.add_trace(
        go.Scatter(
            x=df["hour_index"],
            y=df["health_risk"],
            mode="lines",
            name="Health Risk",
            line=dict(
                color="#E74C3C",
                width=3,
            ),
            fill="tozeroy",
            fillcolor=tokens["fill_red"],
            hovertemplate=(
                "Hour %{x}<br>"
                "Health Risk: %{y:.0f}"
                "<extra></extra>"
            ),
        )
    )

    if peak_start and peak_end:
        try:
            start_h = df.loc[
                df["hour_of_day"] == int(peak_start.split(":")[0]),
                "hour_index",
            ].min()

            end_h = df.loc[
                df["hour_of_day"] == int(peak_end.split(":")[0]),
                "hour_index",
            ].max()

            if pd.notna(start_h) and pd.notna(end_h):
                fig.add_vrect(
                    x0=start_h,
                    x1=end_h,
                    fillcolor="#8E44AD",
                    opacity=0.18,
                    line_width=0,
                    annotation_text="PEAK RISK",
                    annotation_position="top left",
                    annotation_font_color=tokens["font_color"],
                )
        except Exception:
            pass

    return _base_layout(fig, "Health Risk Over Time")


def thermal_stress_timeline_chart(df: pd.DataFrame) -> go.Figure:
    """HTSS thermal-stress timeline."""
    fig = go.Figure()

    if df is None or df.empty:
        return _base_layout(fig, "Thermal Stress (HTSS) Over Time")

    fig.add_trace(
        go.Scatter(
            x=df["hour_index"],
            y=df["htss"],
            mode="lines",
            name="HTSS",
            line=dict(
                color="#FF6B4A",
                width=3,
            ),
            hovertemplate=(
                "Hour %{x}<br>"
                "HTSS: %{y:.0f}"
                "<extra></extra>"
            ),
        )
    )

    return _base_layout(
        fig,
        "Thermal Stress (HTSS) Over Time",
    )


def multi_variable_chart(df: pd.DataFrame) -> go.Figure:
    """Temperature and humidity chart using two y-axes."""
    fig = go.Figure()

    if df is None or df.empty:
        return _base_layout(fig, "Temperature vs Humidity")

    fig.add_trace(
        go.Scatter(
            x=df["hour_index"],
            y=df["temperature_c"],
            name="Temperature (°C)",
            line=dict(color="#E74C3C", width=2.5),
        )
    )

    fig.add_trace(
        go.Scatter(
            x=df["hour_index"],
            y=df["humidity_pct"],
            name="Humidity (%)",
            line=dict(color="#0284C7", width=2.5),
            yaxis="y2",
        )
    )

    fig.update_layout(
        yaxis=dict(
            title="Temperature (°C)",
        ),
        yaxis2=dict(
            title="Humidity (%)",
            overlaying="y",
            side="right",
            showgrid=False,
        ),
    )

    return _base_layout(
        fig,
        "Temperature vs Humidity",
    )


def wind_radiation_chart(df: pd.DataFrame) -> go.Figure:
    """Wind speed and solar radiation chart."""
    fig = go.Figure()

    if df is None or df.empty:
        return _base_layout(fig, "Wind & Solar Radiation")

    fig.add_trace(
        go.Scatter(
            x=df["hour_index"],
            y=df["wind_ms"],
            name="Wind (m/s)",
            line=dict(color="#0284C7", width=2.5),
        )
    )

    fig.add_trace(
        go.Scatter(
            x=df["hour_index"],
            y=df["solar_radiation_wm2"] / 10,
            name="Radiation (÷10 W/m²)",
            line=dict(color="#EAB308", width=2.5),
        )
    )

    return _base_layout(
        fig,
        "Wind & Solar Radiation",
    )


def risk_component_breakdown_chart(
    components: dict,
) -> go.Figure:
    """Horizontal bar chart showing HTSS component contributions."""
    labels = {
        "temperature_contribution": "Temperature",
        "humidity_contribution": "Humidity",
        "radiation_contribution": "Radiation",
        "wind_contribution": "Low Wind",
        "duration_contribution": "Duration",
    }

    if not components:
        return _base_layout(
            go.Figure(),
            "Risk Component Breakdown",
            height=300,
        )

    names = [
        labels[key]
        for key in components
        if key in labels
    ]

    values = [
        components[key]
        for key in components
        if key in labels
    ]

    colors = [
        "#E74C3C",
        "#0284C7",
        "#EAB308",
        "#8E44AD",
        "#10B981",
    ]

    fig = go.Figure(
        go.Bar(
            x=values,
            y=names,
            orientation="h",
            marker_color=colors[:len(names)],
            hovertemplate=(
                "%{y}: %{x:.1f} pts"
                "<extra></extra>"
            ),
        )
    )

    fig.update_xaxes(
        title="Contribution to HTSS"
    )

    return _base_layout(
        fig,
        "Risk Component Breakdown",
        height=300,
    )


def five_day_forecast_chart(df: pd.DataFrame) -> go.Figure:
    """Five-day peak health-risk and temperature forecast."""
    fig = go.Figure()

    if df is None or df.empty:
        return _base_layout(
            fig,
            "5-Day Risk Forecast",
        )

    daily = (
        df.groupby("day_index")
        .agg(
            health_risk=("health_risk", "max"),
            htss=("htss", "max"),
            temperature_c=("temperature_c", "max"),
        )
        .reset_index()
    )

    daily["day_label"] = daily["day_index"].apply(
        lambda day: f"Day {day + 1}"
    )

    fig.add_trace(
        go.Bar(
            x=daily["day_label"],
            y=daily["health_risk"],
            name="Peak Health Risk",
            marker_color="#E74C3C",
        )
    )

    fig.add_trace(
        go.Scatter(
            x=daily["day_label"],
            y=daily["temperature_c"],
            name="Peak Temp (°C)",
            yaxis="y2",
            line=dict(
                color="#EAB308",
                width=3,
            ),
        )
    )

    fig.update_layout(
        yaxis2=dict(
            title="Temperature (°C)",
            overlaying="y",
            side="right",
            showgrid=False,
        )
    )

    return _base_layout(
        fig,
        "5-Day Risk Forecast",
    )


def vulnerability_comparison_chart(
    df: pd.DataFrame,
) -> go.Figure:
    """Average vulnerability score comparison across cities."""
    fig = go.Figure()

    if df is None or df.empty:
        return _base_layout(
            fig,
            "Vulnerability Comparison Across Cities",
            height=320,
        )

    grouped = (
        df.groupby("city")["vulnerability"]
        .mean()
        .reset_index()
        .sort_values(
            "vulnerability",
            ascending=True,
        )
    )

    fig = go.Figure(
        go.Bar(
            x=grouped["vulnerability"],
            y=grouped["city"],
            orientation="h",
            marker=dict(
                color=grouped["vulnerability"],
                colorscale="OrRd",
            ),
            hovertemplate=(
                "%{y}: %{x:.0f}"
                "<extra></extra>"
            ),
        )
    )

    fig.update_xaxes(
        title="Avg. Vulnerability Score",
        range=[0, 100],
    )

    return _base_layout(
        fig,
        "Vulnerability Comparison Across Cities",
        height=320,
    )


def risk_gauge_donut(
    score: float,
    color: str,
) -> go.Figure:
    """Create a circular risk gauge adapting to light and dark backgrounds."""
    tokens = _get_theme_chart_tokens()
    score = max(0.0, min(100.0, float(score)))

    fig = go.Figure(
        go.Pie(
            values=[
                score,
                100 - score,
            ],
            hole=0.75,
            marker=dict(
                colors=[
                    color,
                    tokens["donut_track"],
                ]
            ),
            textinfo="none",
            sort=False,
            direction="clockwise",
        )
    )

    fig.update_layout(
        showlegend=False,
        paper_bgcolor=tokens["paper_bg"],
        annotations=[
            dict(
                text=f"{score:.0f}",
                x=0.5,
                y=0.5,
                font_size=28,
                font_color=color,
                showarrow=False,
                font_family="Inter, sans-serif",
            )
        ],
        margin=dict(
            l=0,
            r=0,
            t=0,
            b=0,
        ),
        height=180,
    )

    return fig