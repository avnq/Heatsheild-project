"""
backend/alert_engine.py

Converts a Health Risk score/level into an actionable alert object,
including drivers, peak window, and headline action text.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from backend.thermal_engine import ThermalStressResult, top_drivers
from backend.risk_engine import HealthRiskResult


@dataclass
class Alert:
    location_name: str
    ward_name: str | None
    level_key: str
    level_label: str
    color: str
    icon: str
    headline: str
    description: str
    action: str
    drivers: list[str] = field(default_factory=list)
    peak_start: str | None = None
    peak_end: str | None = None
    generated_at: str = ""
    health_risk_score: float = 0.0
    thermal_stress_score: float = 0.0


def generate_alert(
    location_name: str,
    health_risk: HealthRiskResult,
    thermal: ThermalStressResult,
    ward_name: str | None = None,
    peak_start: str | None = None,
    peak_end: str | None = None,
) -> Alert:
    level = health_risk.level
    drivers = top_drivers(thermal)

    headline = f"{level['icon']} {level['label']} HEAT-HEALTH RISK"

    return Alert(
        location_name=location_name,
        ward_name=ward_name,
        level_key=level["key"],
        level_label=level["label"],
        color=level["color"],
        icon=level["icon"],
        headline=headline,
        description=level["description"],
        action=level["action"],
        drivers=drivers,
        peak_start=peak_start,
        peak_end=peak_end,
        generated_at=datetime.utcnow().isoformat(),
        health_risk_score=health_risk.score,
        thermal_stress_score=thermal.htss,
    )


def generate_alerts_for_locations(location_rows: list[dict]) -> list[Alert]:
    """
    Bulk alert generation. Each row must contain the pre-computed
    health_risk (HealthRiskResult), thermal (ThermalStressResult),
    location_name, and optionally ward_name/peak_start/peak_end.
    """
    alerts = []
    for row in location_rows:
        alerts.append(
            generate_alert(
                location_name=row["location_name"],
                health_risk=row["health_risk"],
                thermal=row["thermal"],
                ward_name=row.get("ward_name"),
                peak_start=row.get("peak_start"),
                peak_end=row.get("peak_end"),
            )
        )
    # Sort most severe first
    order = {"extreme": 4, "red": 3, "orange": 2, "yellow": 1, "green": 0}
    alerts.sort(key=lambda a: order.get(a.level_key, 0), reverse=True)
    return alerts
