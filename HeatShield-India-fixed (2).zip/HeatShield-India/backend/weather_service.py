"""
backend/weather_service.py

Offline-first weather provider architecture.

    WeatherProvider (interface)
        |
        +-- MockWeatherProvider        (reads bundled CSV demo data)
        +-- OpenMeteoWeatherProvider   (optional live API, best-effort)

A failed live API NEVER crashes the app: get_weather() always falls
back to the mock/demo provider and clearly flags the data source.
"""

from __future__ import annotations

import os
from abc import ABC, abstractmethod
from dataclasses import dataclass

import pandas as pd
import streamlit as st

from utils.validators import validate_weather_record

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")


@dataclass
class WeatherObservation:
    location_id: str
    temperature_c: float
    humidity_pct: float
    wind_ms: float
    solar_radiation_wm2: float
    consecutive_hot_days: int
    night_recovery_temp_c: float | None
    source: str  # "demo" or "live"
    issues: list


class WeatherProvider(ABC):
    name: str = "base"

    @abstractmethod
    def get_current(self, location_id: str) -> WeatherObservation | None:
        ...

    @abstractmethod
    def get_all_current(self) -> pd.DataFrame:
        ...


class MockWeatherProvider(WeatherProvider):
    """Offline demo provider — always available, no network required."""

    name = "demo"

    def __init__(self, data_dir: str = DATA_DIR):
        self.data_dir = data_dir
        self._df = None

    def _load(self) -> pd.DataFrame:
        if self._df is None:
            path = os.path.join(self.data_dir, "weather.csv")
            self._df = pd.read_csv(path)
        return self._df

    def get_current(self, location_id: str) -> WeatherObservation | None:
        df = self._load()
        row = df[df["location_id"] == location_id]
        if row.empty:
            return None
        r = row.iloc[0].to_dict()
        result = validate_weather_record({**r, "lat": None, "lon": None, "timestamp": "demo"})
        cleaned = result.cleaned
        return WeatherObservation(
            location_id=location_id,
            temperature_c=cleaned["temperature_c"],
            humidity_pct=cleaned["humidity_pct"],
            wind_ms=cleaned["wind_ms"],
            solar_radiation_wm2=cleaned["solar_radiation_wm2"],
            consecutive_hot_days=int(r.get("consecutive_hot_days", 1)),
            night_recovery_temp_c=r.get("night_recovery_temp_c"),
            source=self.name,
            issues=result.issues,
        )

    def get_all_current(self) -> pd.DataFrame:
        return self._load().copy()


@st.cache_data(show_spinner=False, ttl=300)
def _fetch_live_current_cached(lat: float, lon: float):
    """
    Cached (5 min) fetch of live current weather for one lat/lon.
    Cached so that re-running the Streamlit script (which happens on
    every widget interaction) does NOT hit the network again for a
    location whose weather we already fetched recently — this is what
    keeps single-location pages (Dashboard, Alerts) fast.
    Returns (cleaned_dict, issues_list) or (None, []) on failure.
    """
    import requests

    try:
        url = (
            "https://api.open-meteo.com/v1/forecast"
            f"?latitude={lat}&longitude={lon}"
            "&current=temperature_2m,relative_humidity_2m,wind_speed_10m,shortwave_radiation"
            "&timezone=Asia%2FKolkata"
        )
        resp = requests.get(url, timeout=4)
        resp.raise_for_status()
        payload = resp.json().get("current", {})

        record = {
            "temperature_c": payload.get("temperature_2m"),
            "humidity_pct": payload.get("relative_humidity_2m"),
            "wind_ms": payload.get("wind_speed_10m"),
            "solar_radiation_wm2": payload.get("shortwave_radiation", 500),
            "lat": lat,
            "lon": lon,
            "timestamp": payload.get("time"),
        }
        result = validate_weather_record(record)
        return result.cleaned, result.issues
    except Exception:
        return None, []


class OpenMeteoWeatherProvider(WeatherProvider):
    """
    Optional LIVE provider. Requires network + `requests`. If anything
    fails (network, parsing, missing coords) this raises internally and
    the calling code in get_weather() falls back to MockWeatherProvider.
    This class is intentionally best-effort and not required for the
    offline-first demo to function.
    """

    name = "live"

    def __init__(self, locations_df: pd.DataFrame):
        self.locations_df = locations_df

    def get_current(self, location_id: str) -> WeatherObservation | None:
        row = self.locations_df[self.locations_df["location_id"] == location_id]
        if row.empty:
            return None
        lat, lon = float(row.iloc[0]["lat"]), float(row.iloc[0]["lon"])

        cleaned, issues = _fetch_live_current_cached(lat, lon)
        if cleaned is None:
            return None

        return WeatherObservation(
            location_id=location_id,
            temperature_c=cleaned["temperature_c"],
            humidity_pct=cleaned["humidity_pct"],
            wind_ms=cleaned["wind_ms"],
            solar_radiation_wm2=cleaned["solar_radiation_wm2"],
            consecutive_hot_days=3,
            night_recovery_temp_c=None,
            source=self.name,
            issues=issues,
        )

    def get_all_current(self) -> pd.DataFrame:
        raise NotImplementedError("Bulk live fetch not implemented in prototype.")


@st.cache_data(show_spinner=False)
def _load_locations() -> pd.DataFrame:
    return pd.read_csv(os.path.join(DATA_DIR, "locations.csv"))


# Open-Meteo weather codes -> (condition label, emoji). Used so the hourly
# matrix can show a real sky/rain icon instead of guessing from solar
# radiation alone (which was the demo-only fallback).
_WMO_CODE_MAP = {
    0: ("Clear", "☀️"), 1: ("Mainly Clear", "🌤️"), 2: ("Partly Cloudy", "⛅"),
    3: ("Overcast", "☁️"),
    45: ("Fog", "🌫️"), 48: ("Fog", "🌫️"),
    51: ("Light Drizzle", "🌦️"), 53: ("Drizzle", "🌦️"), 55: ("Heavy Drizzle", "🌦️"),
    61: ("Light Rain", "🌧️"), 63: ("Rain", "🌧️"), 65: ("Heavy Rain", "🌧️"),
    66: ("Freezing Rain", "🌧️"), 67: ("Freezing Rain", "🌧️"),
    71: ("Light Snow", "🌨️"), 73: ("Snow", "🌨️"), 75: ("Heavy Snow", "🌨️"),
    80: ("Rain Showers", "🌦️"), 81: ("Rain Showers", "🌦️"), 82: ("Violent Showers", "⛈️"),
    95: ("Thunderstorm", "⛈️"), 96: ("Thunderstorm + Hail", "⛈️"), 99: ("Thunderstorm + Hail", "⛈️"),
}


def weather_code_to_condition(code: int | None) -> tuple[str, str]:
    if code is None:
        return "Unknown", "—"
    return _WMO_CODE_MAP.get(int(code), ("Unknown", "—"))


@st.cache_data(show_spinner=False, ttl=600)
def get_live_hourly_forecast(lat: float, lon: float, hours: int = 120) -> pd.DataFrame | None:
    """
    Fetch a genuine multi-day hourly forecast from Open-Meteo for the given
    coordinates (temperature, humidity, wind, solar radiation, rainfall,
    rain probability, weather code). Returns a DataFrame shaped like
    forecast.csv (plus rainfall_mm / precip_probability / weather_code /
    condition_icon columns) so downstream HTSS/health-risk code can run on
    it unchanged. Returns None on ANY failure (network, parsing, etc.) so
    callers can fall back to the offline demo dataset.
    """
    import requests

    forecast_days = max(1, min(16, (hours // 24) + 2))

    try:
        url = (
            "https://api.open-meteo.com/v1/forecast"
            f"?latitude={lat}&longitude={lon}"
            "&hourly=temperature_2m,relative_humidity_2m,wind_speed_10m,"
            "shortwave_radiation,precipitation,precipitation_probability,weather_code"
            "&daily=temperature_2m_max"
            f"&forecast_days={forecast_days}&past_days=3"
            "&timezone=Asia%2FKolkata"
        )
        resp = requests.get(url, timeout=6)
        resp.raise_for_status()
        payload = resp.json()

        hourly = payload.get("hourly", {})
        times = hourly.get("time", [])
        if not times:
            return None

        df = pd.DataFrame({
            "timestamp": pd.to_datetime(times),
            "temperature_c": hourly.get("temperature_2m"),
            "humidity_pct": hourly.get("relative_humidity_2m"),
            "wind_ms": hourly.get("wind_speed_10m"),
            "solar_radiation_wm2": hourly.get("shortwave_radiation"),
            "rainfall_mm": hourly.get("precipitation"),
            "precip_probability": hourly.get("precipitation_probability"),
            "weather_code": hourly.get("weather_code"),
        })

        # Drop the "past_days" rows before "now" so day_index 0 == today,
        # matching how the rest of the app slices day0_df for the current day.
        now = pd.Timestamp.now(tz=None).floor("h")
        df = df[df["timestamp"] >= now].reset_index(drop=True)
        if df.empty:
            return None

        df["hour_index"] = range(len(df))
        df["day_index"] = df["hour_index"] // 24
        df["hour_of_day"] = df["timestamp"].dt.hour

        # Consecutive hot days: count back from today over daily max temps.
        daily = payload.get("daily", {})
        daily_max = daily.get("temperature_2m_max", [])
        consecutive = 0
        for v in reversed(daily_max):
            if v is not None and v >= 40:
                consecutive += 1
            else:
                break
        consecutive = max(1, consecutive)
        df["consecutive_hot_days"] = consecutive

        for col in ("temperature_c", "humidity_pct", "wind_ms", "solar_radiation_wm2"):
            df[col] = df[col].astype(float)
        df = df.dropna(subset=["temperature_c", "humidity_pct"]).reset_index(drop=True)
        if df.empty:
            return None

        df["data_source"] = "live"
        return df.head(hours)
    except Exception:
        return None


def get_weather(location_id: str, use_live: bool = False) -> WeatherObservation:
    """
    Primary entry point used by the rest of the backend.
    Tries the live provider only if explicitly requested; always falls
    back to the offline demo provider on any failure.
    """
    mock_provider = MockWeatherProvider()

    if use_live:
        try:
            locations_df = _load_locations()
            live_provider = OpenMeteoWeatherProvider(locations_df)
            obs = live_provider.get_current(location_id)
            if obs is not None:
                return obs
        except Exception:
            # LIVE API UNAVAILABLE -> USE DEMO DATA -> CONTINUE APPLICATION
            pass

    obs = mock_provider.get_current(location_id)
    if obs is None:
        raise ValueError(f"Unknown location_id: {location_id}")
    return obs


def get_all_current_weather() -> pd.DataFrame:
    return MockWeatherProvider().get_all_current()


def get_weather_at_coords(lat: float, lon: float) -> WeatherObservation | None:
    """
    Fetch live weather for the EXACT given coordinates — not a demo ward's
    centroid. Used when live GPS tracking is on, so temperature/humidity/
    wind/radiation reflect the user's real position instead of whichever
    demo ward centroid happens to be geographically nearest. Returns None
    on any failure so the caller can keep the ward-based weather it
    already has (never crashes the app).
    """
    cleaned, issues = _fetch_live_current_cached(lat, lon)
    if cleaned is None:
        return None
    return WeatherObservation(
        location_id="EXACT_GPS",
        temperature_c=cleaned["temperature_c"],
        humidity_pct=cleaned["humidity_pct"],
        wind_ms=cleaned["wind_ms"],
        solar_radiation_wm2=cleaned["solar_radiation_wm2"],
        consecutive_hot_days=3,
        night_recovery_temp_c=None,
        source="live_exact",
        issues=issues,
    )


@st.cache_data(show_spinner=False, ttl=600)
def get_weather_by_coords(lat: float, lon: float) -> dict | None:
    """
    Fetch live current weather for ANY arbitrary lat/lon (not just the
    demo location_ids in locations.csv) — used by the sidebar's manual
    "search a location" feature. Hits Open-Meteo directly.

    Returns a plain dict (not WeatherObservation, since there's no
    location_id to attach) or None on any failure so the UI can show a
    friendly "couldn't fetch" message instead of crashing.
    """
    import requests

    try:
        url = (
            "https://api.open-meteo.com/v1/forecast"
            f"?latitude={lat}&longitude={lon}"
            "&current=temperature_2m,relative_humidity_2m,wind_speed_10m,"
            "shortwave_radiation,apparent_temperature"
            "&timezone=Asia%2FKolkata"
        )
        resp = requests.get(url, timeout=5)
        resp.raise_for_status()
        payload = resp.json().get("current", {})

        record = {
            "temperature_c": payload.get("temperature_2m"),
            "humidity_pct": payload.get("relative_humidity_2m"),
            "wind_ms": payload.get("wind_speed_10m"),
            "solar_radiation_wm2": payload.get("shortwave_radiation", 500),
            "lat": lat,
            "lon": lon,
            "timestamp": payload.get("time"),
        }
        result = validate_weather_record(record)
        cleaned = result.cleaned

        return {
            "temperature_c": cleaned["temperature_c"],
            "humidity_pct": cleaned["humidity_pct"],
            "wind_ms": cleaned["wind_ms"],
            "solar_radiation_wm2": cleaned["solar_radiation_wm2"],
            "feels_like_c": payload.get("apparent_temperature"),
            "timestamp": payload.get("time"),
            "source": "live",
            "issues": result.issues,
        }
    except Exception:
        return None
